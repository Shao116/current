"""Same 24 previous inputs; actual numeric differences, not accuracy claims."""
from pathlib import Path
import sys,json,time,csv,statistics
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from engine import evaluate
from algorithms.component_evidence import CATALOG
OUT=ROOT/'reports/fusion'
def main():
 d=json.loads((ROOT/'private/data.json').read_text());d['premiseIndex']={p['id']:p for p in d['premises']};d['circuitIndex']={p['id']:p for p in d['circuits']}
 previous=json.loads((ROOT/'reports/v21/24-scenarios.json').read_text());rows=[];results=[]
 for case in previous:
  raw=case['case']['scenario'];t=time.perf_counter();r=evaluate(raw,d);elapsed=(time.perf_counter()-t)*1000;t=time.perf_counter();evaluate(raw,d);warm=(time.perf_counter()-t)*1000;old=case['result'];i=r['impact'];e=r['ert'];a=i['expectedAffectedPercentage'];b=old['impact']['expectedAffectedPercentage'];evidence=[w for sch in e.get('schedules',[]) for w in sch.get('laborEvidence',[])];specs=[x for w in evidence for x in w.get('components',[]) if x.get('rateSource',{} ) and 'kvaPerUnit' in x.get('rateSource',{})]
  row={'case':case['case']['id'],'type':case['case']['type'],'oldExpectedAffectedPct':b,'newExpectedAffectedPct':a,'deltaPercentagePoints':None if a is None or b is None else a-b,'oldERTLow':old['ert']['low'],'oldERTHigh':old['ert']['high'],'newERTLow':e['low'],'newERTHigh':e['high'],'elapsedMs':elapsed,'cachedMs':warm,'exactTransformerSpecTasks':len(specs),'truthOutagePct':None,'truthERT':None,'accuracyImprovement':None,'reliability':'Engineering scenario; no local outcome validation'}
  rows.append(row);results.append({'case':case['case'],'metrics':row,'riskAssessment':r.get('riskAssessment'),'ertEvidence':evidence});print(row['case'],round(elapsed,1),a,e['low'],e['high'],flush=True)
 (OUT/'24-scenario-comparison.json').write_text(json.dumps(results,indent=2))
 with (OUT/'24-scenario-comparison.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 summary={'cases':len(rows),'newMedianMs':statistics.median(r['elapsedMs'] for r in rows),'newMedianCacheMs':statistics.median(r['cachedMs'] for r in rows),'numericOutputCases':sum(r['newExpectedAffectedPct'] is not None for r in rows),'impactChangedCases':sum(abs(r['deltaPercentagePoints'] or 0)>1e-10 for r in rows),'ertChangedCases':sum(r['oldERTLow']!=r['newERTLow'] or r['oldERTHigh']!=r['newERTHigh'] for r in rows),'actualOutcomeBacktests':0,'accuracyImprovement':None,'runtimeComparisonCaveat':'One current uncached + one cached call; previous persisted v2.1 outputs are same-input prediction references, not fresh speed baselines.'}
 (OUT/'summary.json').write_text(json.dumps(summary,indent=2));print(summary)
 coverage=json.loads((OUT/'data-coverage.json').read_text());text='# 数据融合改进 / Data fusion improvements\n\n'
 text+='已核对用户提供目录的 106 个文件；四项核心输入哈希均与现有系统一致。ZIP 和解压副本不重复计数。并非全部字段都能转成有效的概率参数。\n\nAudited 106 source files. All four core source hashes match current ingestion. Duplicate archives/extractions are not independent observations. Ingestion is not calibrated numerical use.\n\n'
 text+='## 已实现 / Implemented\n\n- 从五张 AEP 工时工作表生成带行号、哈希的运行时目录。95 connector CU codes, 14 material categories, 3 pole-size groups, 12 transformer size rows, 11 labor adders, 17 CU descriptions, workbook ILM.\n- 变压器按明确指定或 GIS 各相 kVA 选择精确工时行；多相全更换是明确的维修情景，非确认损坏。没有精确匹配时保留显式默认，不做最近规格插值。Actual per-phase kVA selects exact workbook rows; full-bank replacement is a declared scenario.\n- 挖掘附加工时要求输入 cubic_feet 数量，缺失工时项拒绝计算；受限通行附加避免重复。Explicit units, no invented missing rates, no duplicate legacy access adder.\n- 使用架空主线两端已核验位置标识和 10m 几何检查计算迎风角；支持几何反向，不创造供电边。Both endpoint bearings, reversed geometries supported, no fabricated connectivity.\n- 九页结构图可指定参考页，但不推断真实装配或自动生成受损部件。All nine drawing references selectable; no invented asset-specific bill of materials.\n- API 返回 dataFusion 使用范围；地图图层来源面板提供数据使用与缺口清单。API and UI expose actual use and gaps.\n\n'
 text+='## 实测 / Actual tests\n\n'+json.dumps(summary,indent=2)+'\n\n'
 text+='|情景 / Case|旧影响% / Old impact|新影响% / New impact|旧维修h / Old repair|新维修h / New repair|运行ms / Runtime|\n|---|---:|---:|---|---|---:|\n'
 for r in rows:text+=f"|{r['case']}|{r['oldExpectedAffectedPct']}|{r['newExpectedAffectedPct']}|{r['oldERTLow']}–{r['oldERTHigh']}|{r['newERTLow']}–{r['newERTHigh']}|{r['elapsedMs']:.2f}|\n"
 text+='\n预测发生变化不代表误差改善；没有真实结果，因此不报告准确率。Changed predictions are not demonstrated accuracy improvements; no outcome truth is available.\n\n## PINN 判断 / PINN decision\n\n目前没有部署 PINN。PINN 需要明确物理方程、边界/初始条件和可识别参数；用模拟曲线训练网络只能证明它复现模拟，不能证明当地停电预测准确。现有解析脆弱性计算没有必要用神经网络近似。\n\nPINN is not deployed. Reproducing a physics simulator with a network does not validate local outage probabilities. Add a PINN only for a well-defined physical subproblem and compare against its numerical solver and observed outcomes.\n\n'
 text+='Research: [Misyris et al., PINNs for power systems](https://arxiv.org/abs/1911.03737) studies rotor-angle/frequency dynamics; this is not validation of storm outage probabilities. [Watson et al. 2024](https://doi.org/10.1109/ACCESS.2024.3396414) supports structural-vulnerability + ML integration, distinct from requiring PINN. [NHESS 2023](https://nhess.copernicus.org/articles/23/1665/2023/index.html) discusses outage prediction and uncertainty/extrapolation limitations.\n\n## 尚不能解决 / Remaining gaps\n\n'
 for role in coverage['roles']:text+=f"- **{role['source']} [{role['status']}]**: {role['use']}\n"
 text+='\n仍缺完整的设备×风暴事件暴露表、可靠未损坏样本、小时级客户停复电真值、覆冰厚度/土壤参数、设备机械状态及验证过的备用电源容量/保护数据。More complex models cannot manufacture these missing measurements. No claim of fully fused calibrated probability, highest accuracy, or official AEP estimates.\n'
 (OUT/'Fusion-中英文.md').write_text(text)
if __name__=='__main__':main()
