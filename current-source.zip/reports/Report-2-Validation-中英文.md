# Report 2 · 20 组实际运行与验证 / Twenty measured runs and validation

Generated UTC: 2026-10-25T01:36:23.169174+00:00 · Python 3.12.14 · macOS-14.8.9-arm64-arm-64bit

## 中文：先说明能证明什么

这是实际执行代码得到的 20 组结果，不是示意表。**8 组真实历史背景回放 + 12 组合成天气/故障场景；真实客户停电结果回测为 0 组。** 历史组使用真实损坏报告和当日再分析天气，但最近设备的身份未经确认，因此故障节点也只作为明确的回放假设，不能称为已验证的历史停电影响。

全部组的无条件停电概率、实际客户停电比例、实际客户 ERT、预测误差、准确率均为 **N/A**。原因是缺少可配对的客户结果、完整未损坏标签、事件暴露及小时级恢复真值。`Repaired_D - Report_Tim` 不能当作小时级停电时长，最近设备匹配也不是资产身份真值。

每组相同随机种子独立计算 3 次，期间清空结果缓存，表中为暖进程下端到端 Python 计算中位延迟；另测一次命中缓存延迟。不包括网络下载、网页渲染、Ollama、JSON 的 HTTP 传输或首次导入。已下载数据固定缓存，原始压缩包 SHA256 在状态审计中。

- 中位未命中缓存计算：**47.9 ms**；20 组中位数的 P95：**113.9 ms**。
- 中位缓存计算：**5.5 ms**；该次进程服务初始化：**2.57 s**。
- 另一次全区域测试实际输出 **117,642** 个客户的影响和 ERT 行：**2.04 s**，47 个客户路径未知。不是全区域天气概率验证。
- H01–H08 条件影响与直接扫描原始客户路径的最大差：**2.66e-15 个百分点**，仅浮点数误差。这是连接逻辑验证，**不是预测准确率**。

## English: interpretation before numbers

These are actual executions, not illustrative values: **8 historical-context replays, 12 synthetic hazard/failure scenarios, and zero genuine customer-outcome backtests**. Historical replays use real positive reports and reanalysis weather. Nearest-device identity is unverified and is explicitly assumed for the replay. No historical customer outage or restoration outcome is available.

Unconditional outage probability, actual outage percentage, actual ERT, forecast error and accuracy are **N/A for all 20 cases**. Report-to-repair date subtraction is not verified hourly outage duration. Source-path equivalence is a structural correctness test, not predictive accuracy.

Each case is computed three times with identical seeds and the result cache cleared. The table reports median warm-process calculation time. A separate cached call is measured. Network downloads, browser rendering, Ollama, HTTP serialization/transfer and first imports are excluded. Uncached median is 47.9 ms, P95 across case medians 113.9 ms, cached median 5.5 ms. The separate full-extract integration run outputs all 117,642 customer rows in 2.04 seconds.

## 预测/条件模拟结果 · Conditional results

`Impact` 是选中电路内、给定/假定设备故障后的客户影响比例，**不是天气导致停电的概率**。`95% sim` 是模拟分位范围，不是现实校准置信度。`Work h` 是维修工作完工范围，客户分阶段结果在 JSON/API。所有行置信度：**U = unvalidated / 未经真实结果验证**。实际结果与预测误差：所有行 **N/A**。

| ID | Date | Circuit / generalized point | Conditional impact % | 95% sim % | Work h | Compute ms | Cache ms | Truth / error | Confidence / gap |
|---|---|---|---:|---|---|---:|---:|---|---|
| H01 | 2025-03-16 | C-083 (37.24,-79.98) | 0.30 | 0.30–0.30 | 10.61–10.61 | 30.8 | 3.4 | N/A / N/A | U / H |
| H02 | 2024-11-23 | C-010 (37.17,-79.98) | 1.95 | 1.95–1.95 | 2.73–2.73 | 34.0 | 4.2 | N/A / N/A | U / H |
| H03 | 2024-01-10 | C-005 (37.22,-80.10) | 0.19 | 0.19–0.19 | 2.73–2.73 | 41.0 | 5.3 | N/A / N/A | U / H |
| H04 | 2024-08-03 | C-002 (37.26,-79.77) | 0.31 | 0.31–0.31 | 2.73–2.73 | 80.6 | 11.6 | N/A / N/A | U / H |
| H05 | 2025-01-06 | C-035 (37.29,-79.95) | 5.98 | 5.98–5.98 | 2.73–2.73 | 32.7 | 4.0 | N/A / N/A | U / H |
| H06 | 2024-08-09 | C-084 (37.24,-79.96) | 0.24 | 0.24–0.24 | 10.61–10.61 | 32.4 | 4.3 | N/A / N/A | U / H |
| H07 | 2025-05-17 | C-015 (37.28,-80.14) | 0.55 | 0.55–0.55 | 2.73–2.73 | 21.2 | 1.9 | N/A / N/A | U / H |
| H08 | 2025-12-19 | C-010 (37.18,-79.94) | 0.93 | 0.93–0.93 | 2.73–2.73 | 36.5 | 4.8 | N/A / N/A | U / H |
| S01 | 2025-01-15 | C-052 (37.27,-79.94) | 8.17 | 1.53–44.77 | 10.61–10.61 | 14.0 | 0.6 | N/A / N/A | U / V |
| S02 | 2025-02-15 | C-020 (37.29,-80.05) | 8.14 | 0.91–20.80 | 2.73–2.73 | 54.8 | 6.5 | N/A / N/A | U / V |
| S03 | 2025-03-15 | C-041 (37.28,-79.90) | 1.48 | 0.52–2.79 | 20.22–20.22 | 69.7 | 6.8 | N/A / N/A | U / V |
| S04 | 2025-04-15 | C-062 (37.23,-80.01) | 3.44 | 1.20–7.35 | 20.22–20.22 | 59.2 | 4.9 | N/A / N/A | U / V |
| S05 | 2025-05-15 | C-003 (37.12,-80.17) | 3.39 | 0.43–16.18 | 8.96–8.96 | 97.8 | 6.0 | N/A / N/A | U / T |
| S06 | 2025-06-15 | C-017 (37.43,-80.08) | 0.28 | 0.13–0.71 | 10.61–10.61 | 60.1 | 6.1 | N/A / N/A | U / T |
| S07 | 2025-07-15 | C-094 (37.43,-79.78) | 0.59 | 0.19–1.08 | 15.86–23.86 | 58.8 | 5.7 | N/A / N/A | U / T |
| S08 | 2025-08-15 | C-002 (37.25,-79.73) | 1.39 | 0.26–6.59 | 2.73–7.92 | 112.2 | 13.6 | N/A / N/A | U / T |
| S09 | 2025-09-15 | C-012 (37.07,-79.82) | 0.68 | 0.32–1.57 | 20.22–20.22 | 92.3 | 6.4 | N/A / N/A | U / T |
| S10 | 2025-10-15 | C-017 (37.38,-80.20) | 0.96 | 0.52–1.56 | 20.22–20.22 | 146.3 | 5.9 | N/A / N/A | U / T |
| S11 | 2025-11-15 | C-012 (37.20,-79.85) | N/A | N/A–N/A | N/A–N/A | 9.6 | 5.7 | N/A / N/A | U / L |
| S12 | 2025-12-15 | C-025 (37.32,-79.98) | 0.00 | 0.00–0.00 | 0.00–0.00 | 5.3 | 2.0 | N/A / N/A | U / V |

Gap codes / 缺口：

- **H**：真实损坏报告，但资产身份仅空间候选；无客户停电/ERT 真值。Real report, unverified asset identity, no customer-outcome labels.
- **L**：导线无可信客户路径且无工作簿维修费率，返回缺失。Conductor connectivity/labor unavailable; no fabricated fallback.
- **T**：选点在 LiDAR 研究数据边界以外；树木特征缺失。Outside LiDAR source bounds; tree features missing, not zero.
- **V**：条件模拟可运行，但没有真实结果校准；边界内树木仍不完整。Scenario executes; outcome calibration absent and vegetation remains incomplete.

## 每组条件和证据 · Conditions and evidence

H 行风向为当天最大阵风小时的区域再分析风向；降雨/降雪为全天累计，非同一瞬时暴露。S 行天气均为人工假设；日期不代表当天真的发生该灾害。Generalized coordinates are deliberately coarse.

| ID | Type / evidence | Hazard | Gust mph | Wind from ° | Rain mm | Snow cm | Freeze indicator | Terrain slope ° | LiDAR |
|---|---|---|---:|---:|---:|---:|---|---:|---|
| H01 | Real report D-0006 | Actual report date + reanalysis weather; incident hour unknown | 46.1 | 169 | 4.2 | 0.0 | False | 11.6 | partial_bounds |
| H02 | Real report D-0015 | Actual report date + reanalysis weather; incident hour unknown | 45.6 | 281 | 0.0 | 0.0 | False | 6.0 | missing_outside_bounds |
| H03 | Real report D-0020 | Actual report date + reanalysis weather; incident hour unknown | 49.2 | 278 | 0.5 | 0.0 | False | 13.8 | missing_outside_bounds |
| H04 | Real report D-0032 | Actual report date + reanalysis weather; incident hour unknown | 20.8 | 246 | 12.4 | 0.0 | False | 1.9 | missing_outside_bounds |
| H05 | Real report D-0047 | Actual report date + reanalysis weather; incident hour unknown | 31.8 | 297 | 19.5 | 1.5 | False | 3.8 | partial_bounds |
| H06 | Real report D-0048 | Actual report date + reanalysis weather; incident hour unknown | 27.5 | 66 | 15.5 | 0.0 | False | 9.7 | partial_bounds |
| H07 | Real report D-0061 | Actual report date + reanalysis weather; incident hour unknown | 44.5 | 260 | 4.5 | 0.0 | False | 6.2 | missing_outside_bounds |
| H08 | Real report D-0100 | Actual report date + reanalysis weather; incident hour unknown | 44.5 | 278 | 9.8 | 0.0 | False | 7.1 | missing_outside_bounds |
| S01 | Synthetic scenario | Rain | 40.0 | 225 | 50.0 | 0.0 | False | 1.5 | partial_bounds |
| S02 | Synthetic scenario | Wind east | 70.0 | 90 | 3.0 | 0.0 | False | 8.5 | partial_bounds |
| S03 | Synthetic scenario | Wind west | 70.0 | 270 | 3.0 | 0.0 | False | 0.6 | partial_bounds |
| S04 | Synthetic scenario | Snow | 55.0 | 315 | 0.0 | 30.0 | False | 2.2 | partial_bounds |
| S05 | Synthetic scenario | Freezing rain | 35.0 | 45 | 20.0 | 0.0 | True | 5.5 | missing_outside_bounds |
| S06 | Synthetic scenario | Severe gust | 95.0 | 180 | 65.0 | 0.0 | False | 13.3 | missing_outside_bounds |
| S07 | Synthetic scenario | Mountain access | 60.0 | 300 | 40.0 | 5.0 | False | 11.7 | missing_outside_bounds |
| S08 | Synthetic scenario | Few crews | 75.0 | 210 | 30.0 | 0.0 | False | 8.5 | missing_outside_bounds |
| S09 | Synthetic scenario | Clear calm | 8.0 | 0 | 0.0 | 0.0 | False | 12.7 | missing_outside_bounds |
| S10 | Synthetic scenario | Outside tree coverage | 65.0 | 135 | 10.0 | 0.0 | False | 20.0 | missing_outside_bounds |
| S11 | Synthetic scenario | Missing conductor labor | 60.0 | 180 | 25.0 | 20.0 | False | 21.8 | missing_outside_bounds |
| S12 | Synthetic scenario | No damaged tasks | 15.0 | 15 | 0.0 | 0.0 | False | 1.5 | partial_bounds |

## 简单基线是否被复杂算法超过？ / Did complexity beat the baselines?

1. **真实风险预测 / Real risk prediction**：没有合格的真实标签，XGBoost、逻辑回归、常数发生率的真实 Brier、log loss、AUC 均 N/A。不能声称复杂模型提升了准确率。实际跑过 XGBoost→独立校准→基线比较→门槛判断的合成代码测试；产物留在临时目录，未部署，合成指标不代表 AEP 结果。
2. **图影响 / Graph impact**：历史背景回放的条件影响与独立原始路径扫描一致。验证覆盖全部 32,600 节点的反向客户索引；未把有 60 个多上游节点的合并图盲目当树。
3. **Monte Carlo**：20,000 次小型独立概率实验对照解析结果 `[0.20, 0.44, 0.30]`，每项误差小于测试容差 0.015；另测公共因子相关模拟保持给定边缘概率。它们证明实现可用，不证明给定概率在现实正确。
4. **ERT 排程 / Scheduling**：对同一场景比较 FIFO 和优化排程的加权任务完成时间。保证仅采用不劣于已有可行基线的解；求解超时保留基线。下表是模型内目标比较，不是实测恢复误差，也不证明得到全局最优客户恢复方案。

| ID | FIFO objective | Selected objective | Improvement | Meaning |
|---|---:|---:|---:|---|
| H01 | 42.44 | 42.44 | 0.00 | weighted task-hours, not observed outage error |
| H02 | 65.52 | 65.52 | 0.00 | weighted task-hours, not observed outage error |
| H03 | 10.92 | 10.92 | 0.00 | weighted task-hours, not observed outage error |
| H04 | 32.76 | 32.76 | 0.00 | weighted task-hours, not observed outage error |
| H05 | 193.83 | 193.83 | 0.00 | weighted task-hours, not observed outage error |
| H06 | 42.44 | 42.44 | 0.00 | weighted task-hours, not observed outage error |
| H07 | 10.92 | 10.92 | 0.00 | weighted task-hours, not observed outage error |
| H08 | 32.76 | 32.76 | 0.00 | weighted task-hours, not observed outage error |
| S01 | 53.05 | 53.05 | 0.00 | weighted task-hours, not observed outage error |
| S02 | 903.63 | 903.63 | 0.00 | weighted task-hours, not observed outage error |
| S03 | 258.25 | 210.20 | 48.05 | weighted task-hours, not observed outage error |
| S04 | 493.28 | 397.18 | 96.10 | weighted task-hours, not observed outage error |
| S05 | 358.42 | 246.98 | 111.44 | weighted task-hours, not observed outage error |
| S06 | 63.66 | 63.66 | 0.00 | weighted task-hours, not observed outage error |
| S07 | 126.88 | 126.88 | 0.00 | weighted task-hours, not observed outage error |
| S08 | 205.59 | 202.13 | 3.46 | weighted task-hours, not observed outage error |
| S09 | 207.20 | 197.59 | 9.61 | weighted task-hours, not observed outage error |
| S10 | 372.96 | 363.35 | 9.61 | weighted task-hours, not observed outage error |
| S11 | N/A | N/A | N/A | weighted task-hours, not observed outage error |
| S12 | N/A | 0.00 | N/A | weighted task-hours, not observed outage error |

不同案例的目标权重和客户数不同，不能把目标值横向当作灾害严重程度。这里没有可靠标签支持 XGBoost 相对简单风险基线的真实提升；对于给定故障，确定性路径本来就是准确而直接的方法。复杂排程是否改善真实恢复时间，仍需小时级现场结果。

Objective values depend on scope and explicit priority policy and should not be compared across storms as severity scores. There is no evidence here of real predictive improvement by XGBoost over simple risk baselines. Deterministic path logic is the direct baseline for known failures; real restoration improvement remains unverified.

## 实际测试与失败行为 / Executed checks and failure behavior

- `tests-all.txt`：40 个 Python 测试通过（含 22 个 v2 测试），覆盖完整路径反向索引、真实地形/天气、缺树、缺标签、未知拓扑、概率模拟、组件工时、队伍占用、访问延迟、分阶段送电、备用约束、缓存、输入拒绝、隐私与 HTTP 接口。
- `tests-frontend.txt`：四天 Demo fixture 与真实 HTTP API 实测通过；所有旧风险分数保持 null，缺导线工时返回 null，雪天保持雪的天气上下文。
- `full-scope-check.json`：全部 117,642 客户的影响和客户 ERT 输出，通过独立路径基线核对。
- 导线场景 S11 的不可计算是预期的诚实拒绝，不是悄悄用假费率补齐。电杆无客户路径时同样只允许工作量估计。
- 界面已实际打开检查：未知概率不会显示成低风险，固定彩色风险圆环和分数表尺移除；地图、天气、Demo 与本机 Ollama 接口保留。

Forty Python checks pass, including twenty-two v2 checks. Frontend fixtures also pass through the real HTTP API. Missing conductor labor and unverified topology deliberately produce unavailable outputs. Unknown probability never becomes a low-risk claim. Full per-customer integration, actual public input downloads and browser integration are verified separately from outcome accuracy.

## 下一步需要真实补充什么 / Required evidence to measure accuracy

提供设备×风暴事件的完整暴露及已检查 0/1 结果、精确设备连接、客户停电/复电时间、实际班组/工班/材料、道路封闭和真实安全隔离依赖；补齐资产规格/损坏部件、树木覆盖/健康/树冠、冻雨覆冰、历史风暴路径、设施客户关联和经工程审批的备用线路参数。届时才可进行真正独立事件/地点回测、校准与 MAE/Brier 等误差比较。

Required next inputs are complete inspected asset-event exposures, accurate electrical connections, hourly customer outage/restoration outcomes, actual crew/shift/material/road/safety constraints, asset specifications and damaged components, vegetation coverage/health/crowns, icing/storm tracks, verified critical-facility supply links and approved alternate-feed engineering data. These are missing data requirements, not evidence of current accuracy.

## 可复现文件 / Evidence artifacts

- `20-cases.csv`：所有 20 组的机器可读指标，真实结果/误差留空。
- `20-cases.json`：输入、种子、物理特征、逐客户条件影响/恢复输出、排程与缺失原因。
- `benchmark-summary.json` / `benchmark-run.txt`：平台、延迟、冷启动与完整运行记录。
- `xgboost-synthetic-plumbing.json`：**仅合成训练代码检查**，非真实验证。
- `full-scope-check.json` / `tests-all.txt` / `tests-v2.txt` / `tests-frontend.txt`。
- 私有目录中的源数据哈希、DEM/天气 URL/下载时间与全客户示例压缩输出；复现命令见 `REPRODUCE.md`。
