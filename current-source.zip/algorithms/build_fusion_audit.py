"""Sanitized, reproducible all-source audit: ingestion != numerical use."""
from pathlib import Path
import json,pickle,hashlib,collections
ROOT=Path(__file__).resolve().parents[1]
SOURCE=Path('/Users/tony/Downloads/aep_challenge_hack26-main')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def main():
 with (ROOT/'private/algorithm/network.pkl').open('rb') as f:d=pickle.load(f)
 files=[]
 for p in sorted(SOURCE.rglob('*')):
  if p.is_file() and not any(x.startswith('.') for x in p.relative_to(SOURCE).parts):files.append({'file':str(p.relative_to(SOURCE)),'bytes':p.stat().st_size,'sha256':sha(p)})
 for r in files:
  same=[q['file'] for q in files if q['sha256']==r['sha256'] and q['file']!=r['file']];r['identicalCopies']=same
 # Original identifiers never exported; only schema completeness counts.
 assets={}
 for kind in sorted({a['kind'] for a in d['assets']}):
  rows=[a['attributes'] for a in d['assets'] if a['kind']==kind];fields=sorted(set(k for r in rows for k in r));assets[kind]={'records':len(rows),'fieldsPresentCounts':{k:sum(bool(r.get(k)) for r in rows) for k in fields}}
 roles=[
 {'source':'Customer_Clip + matched_upstream','status':'active','use':'Exact customer locations and supplied upstream paths; critical LS flags for scheduling. Missing/conflicting paths remain audited.'},
 {'source':'Pole_Clip','status':'active_partial','use':'Material, class, height, unique shared location; installation date context only. No unvalidated age decay.'},
 {'source':'Primary_ExportFeatures','status':'active_partial','use':'Both verified overhead endpoint identifiers and geometry for exposure bearings; span length/context. No invented ampacity, resistance, or loading.'},
 {'source':'Secondary_ExportFeatures','status':'ingested_partial','use':'Private raw geometry and attributes retained; no full-span failure model or invented electrical routing.'},
 {'source':'Transformer_Clip','status':'active_partial','use':'Overhead support associations, source paths, actual phase kVA when exact workbook row exists; explicitly declared bank replacement. Missing specs retain stated fallback.'},
 {'source':'Fuse/Switch/Recloser','status':'active_partial','use':'Supplied upstream paths and exact task type/workbook rates; fuse support exposure. No claim of remote switching or verified tie feasibility.'},
 {'source':'Damage reports','status':'context_not_calibration','use':'Prior-date spatial context; no fabricated undamaged examples, hourly ERT outcomes, or negative labels.'},
 {'source':'Hospital/fire/ambulance','status':'link_gap','use':'52 facilities ingested; critical customer mapping requires verified link, not nearest-neighbor electrical guesses.'},
 {'source':'Install_Labor_HackOHIO.xlsx','status':'all_five_sheets_cataloged','use':'95 exact connector CUs,14 material categories,3 pole size ranges,12 transformer size rows,11 explicit adders (1 missing time rejected),17 descriptions and ILM. Only selected work applied; not all work assumed damaged.'},
 {'source':'structure_drawings.pdf','status':'all_nine_pages_reference_catalog','use':'Explicit selected drawing reference + declared components; no GIS-to-drawing key, no automatic BOM or full-assembly damage assumption.'},
 {'source':'LiDAR/OSM/canopy','status':'active_partial','use':'Downwind reachable LiDAR trees and heights; woodland context. Missing species, health and verified crowns; canopy units unverified, excluded from probability.'},
 {'source':'DEM','status':'diagnostic','use':'Elevation,slope,openness,windward/leeward context; no unsupported speed-up multiplier.'},
 {'source':'Weather','status':'active_partial','use':'Wind gust/direction + preceding-year seasonal reference. Rain,freeze,snow flagged; no unsupported accretion or soil-strength multipliers.'},
 {'source':'README/challenge documents','status':'requirements_reference','use':'Requirements and data interpretation, not numerical prediction parameters.'},
 {'source':'ZIP/extracted/duplicate copies','status':'deduplicated_sources','use':'File hashes recorded; duplicate copies never counted as extra customers, equipment or training evidence.'}]
 input_matches={}
 for path,expected in d['audit']['sourceSha256'].items():
  actual=SOURCE/path;input_matches[path]={'sameAsIngested':actual.exists() and sha(actual)==expected}
 result={'sourceFilesAudited':len(files),'organizerInputMatches':input_matches,'roles':roles,'assetSchemaAudit':assets,'sourceFiles':files,'calibratedProbability':False,'realOutcomeBacktests':0,'PINN':{'active':False,'reason':'No well-identified asset mechanics/soil/ice equation system or full local outcome labels. Do not equate physics features with PINN or teacher simulation with ground truth.'},'fullFusionClaim':False,'meaning':'All supplied files inventoried; numerical use explicitly distinguished from context, references, duplicates and missing links.'}
 out=ROOT/'reports/fusion';out.mkdir(exist_ok=True);(out/'data-coverage.json').write_text(json.dumps(result,indent=2));(ROOT/'private/algorithm/data-coverage.json').write_text(json.dumps(result));print('Audited files',len(files),'input matches',input_matches)
if __name__=='__main__':main()
