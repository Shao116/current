"""v2 scheduling extension: heterogeneous work, customer-objective, uncertainty.
Keeps workbook labor, CP-SAT and SimPy; never treats workload completion as
an individual customer's restoration time or invents switch connectivity.
"""
import math
import numpy as np
from scipy.stats import norm
from .restoration import labor,schedule,feasible_backup
from .vulnerability import REFERENCE
from .component_evidence import adder_hours,drawing_reference,CATALOG

def repair_work(kind,size='medium',raw=None):
 raw=raw or {}
 if raw.get('laborBasis','crew_hours') not in ['crew_hours','person_hours']:raise ValueError('Unknown labor basis')
 work=labor(kind,size,raw.get('components'),raw.get('access',False),raw.get('repairHours'),raw.get('laborBasis','crew_hours'),raw.get('crewSize',1),raw.get('_assetAttributes'),raw.get('laborAdders'),raw.get('drawingPage'))
 if not work['available'] and raw.get('components') is None and kind in ['wire','secondary','short_circuit']:
  base=REFERENCE['referenceRepairHours']['short_circuit' if kind=='short_circuit' else 'wire'];extra,details=adder_hours(raw.get('laborAdders',[]),raw.get('access',False));mean=base+extra*CATALOG['indirectMultiplier']/raw.get('crewSize',1) if raw.get('laborBasis','crew_hours')=='person_hours' else base+extra*CATALOG['indirectMultiplier']
  return {'available':True,'taskHours':mean,'publishedBaseHours':base,'laborAdders':details,'drawingReference':drawing_reference(raw.get('drawingPage')),'directHours':None,'indirectMultiplier':None,'components':[],'basis':'published transferred total repair-duration reference','source':REFERENCE['source']+' §2.5','note':'Published reference, not AEP labor or local observed repair time. No extra ILM applied to published base; explicitly selected workbook adders receive workbook ILM exactly once.'}
 return work

def dependency_groups(failed,nodes,customers,scope,critical_ids):
 local={int(c):j for j,c in enumerate(scope)};masks={}
 for j,n in enumerate(failed):
  for c in nodes[n]['customers']:
   c=int(c)
   if c in local:masks[c]=masks.get(c,0)|(1<<j)
 grouped={}
 for c,mask in masks.items():
  critical=customers[c]['criticalRaw']=='LS Life Support' or customers[c]['id'] in critical_ids
  g=grouped.setdefault(mask,{'tasks':[j for j in range(len(failed)) if mask&(1<<j)],'weight':0,'customers':[],'critical':0});g['weight']+=1+(len(scope)+1 if critical else 0);g['customers'].append(local[c]);g['critical']+=int(critical)
 return list(grouped.values())

def restore_ensemble(data,nodes,scope,draws,s,raw,physics_rows=None,weather_mode=False):
 customers=data['customers'];assets=data['assets'];seed=int(raw.get('seed',20261024));rng=np.random.default_rng(seed+917);cv=float(raw.get('repairCV',.5))
 if not math.isfinite(cv) or not 0<=cv<=2:raise ValueError('repairCV must be between 0 and 2')
 sigma=math.sqrt(math.log1p(cv*cv));crew_range=raw.get('crewRange',[s['crews'],s['crews']]);delay_range=raw.get('accessDelayRange',[s['accessDelay'],s['accessDelay']]);hold=raw.get('hazardHoldHours',0)
 if len(crew_range)!=2 or any(not isinstance(v,int) or not 1<=v<=20 for v in crew_range):raise ValueError('Invalid crewRange')
 if len(delay_range)!=2 or any(not isinstance(v,(int,float)) or not math.isfinite(v) or not 0<=v<=72 for v in delay_range):raise ValueError('Invalid accessDelayRange')
 if not isinstance(hold,(int,float)) or not math.isfinite(hold) or not 0<=hold<=168:raise ValueError('Invalid hazardHoldHours')
 facility_links=raw.get('facilityLinks',[])
 if not isinstance(facility_links,list) or len(facility_links)>52:raise ValueError('Invalid facilityLinks')
 valid_customer_ids={p['id'] for p in customers};valid_facilities={f['id'] for f in data['facilities']};critical_ids=set()
 for f in facility_links:
  if f.get('verified') is not True or f.get('customerId') not in valid_customer_ids or f.get('facilityId') not in valid_facilities:raise ValueError('Facility link must identify existing facility/customer and be explicitly verified')
  critical_ids.add(f['customerId'])
 physics={r['node']:r for r in physics_rows or []};fallback=False;selection='Stratified by modeled damage count, including zero-damage scenarios.'
 if weather_mode and not any(draws):
  # Useful rare-event contingency without silently conditioning the MC probabilities.
  top=sorted(physics,key=lambda n:physics[n]['scenarioFailureProbability'],reverse=True)[:8]
  draws=[[n] for n in top if physics[n]['scenarioFailureProbability']>0];fallback=bool(draws);selection='Explicit single-support contingencies because MC saw no damage; not probabilistically weighted.'
 if not draws:draws=[[]]
 order=sorted(range(len(draws)),key=lambda i:len(draws[i]));sample_budget=8 if max(map(len,draws),default=0)>200 else 16;chosen=[order[int(i)] for i in np.linspace(0,len(order)-1,min(sample_budget,len(order))).round().astype(int)]
 event_results=[];time_samples=[];durations=[];rates=[];skipped=0;sampled_task_count=[];component_counts={};capped=0
 for ix,index in enumerate(chosen):
  failed=list(draws[index]);sampled_task_count.append(len(failed))
  # Large incidents reuse feasible list scheduling; CP-SAT remains bounded to ≤40 tasks.
  tasks=[];task_failure_kinds=[]
  for n in failed:
   a=assets[nodes[n]['asset']] if nodes[n].get('asset') is not None else None;kind=a['kind'] if a else s['asset'];size=s['size']
   if n in physics:
    p=physics[n];pw=p['windScenarioProbability'];pl=p.get('wireScenarioProbability',0);pt=p['treeContactScenarioProbability'];total=max(p['scenarioFailureProbability'],1e-15);exclusive=np.array([pw,(1-pw)*pl,(1-pw)*(1-pl)*pt]);exclusive=exclusive/exclusive.sum() if exclusive.sum() else np.array([1.,0.,0.]);kind=rng.choice(['pole','wire','short_circuit'],p=exclusive)
   if a and a['kind']=='pole':
    try:
     ft=float(a['attributes']['height'].split()[0]);size='small' if ft<=35 else 'medium' if ft<60 else 'large'
    except (ValueError,KeyError,IndexError):pass
   # Explicit per-node component evidence overrides inferred planning mode.
   node_details=raw.get('damageDetails',{}).get(n,{})
   spec={**raw,**node_details,'access':s['access'],'_assetAttributes':a['attributes'] if a else {}};kind=node_details.get('kind',kind);work=repair_work(kind,size,spec)
   if not work['available']:skipped+=1;continue
   rates.append(work);component_counts[kind]=component_counts.get(kind,0)+1;mean=work['taskHours'];factor=float(np.exp(-.5*sigma*sigma+sigma*rng.normal())) if cv else 1.;hours=mean*factor;release=float(delay_range[ix%2])+hold
   tasks.append({'node':n,'hours':hours,'meanHours':mean,'release':release,'weight':len(nodes[n]['customers'])+1});task_failure_kinds.append(kind)
  if len(tasks)!=len(failed):continue
  groups=dependency_groups(failed,nodes,customers,scope,critical_ids)
  # Critical benefit also seeds the existing feasible greedy schedule.
  for g in groups:
   for j in g['tasks']:tasks[j]['weight']+=g['weight']
  sch=schedule(tasks,crew_range[ix%2],time_limit=.03 if ix==0 else .005,customer_groups=groups)
  times=np.zeros(len(scope));known=np.array([bool(customers[i]['path']) for i in scope]);times[~known]=np.nan;finish={e['task']:e['end'] for e in sch['events']}
  for g in groups:times[g['customers']]=max(finish[j] for j in g['tasks'])
  critical_hours=sum(max(finish[j] for j in g['tasks'])*g['critical'] for g in groups);normal_hours=float(np.nansum(times))
  # Actual step restoration after completed upstream work, no fixed percentages.
  positives=times[np.isfinite(times)&(times>0)];unique,counts=np.unique(positives,return_counts=True);cumulative=np.cumsum(counts)
  stages=[{'hour':float(t),'restoredCustomers':int(count),'remainingAffectedCustomers':int(len(positives)-count)} for t,count in zip(unique,cumulative)]
  sch.update({'laborEvidence':[{'kind':k,'components':w.get('components',[]),'laborAdders':w.get('laborAdders',[]),'drawingReference':w.get('drawingReference'),'source':w.get('source')} for k,w in zip(task_failure_kinds,rates[-len(tasks):])] if tasks else [],'crewHours':sum(t['hours'] for t in tasks),'failureNodes':failed,'repairKinds':task_failure_kinds,'customerHours':normal_hours,'criticalCustomerHours':critical_hours,'stages':stages})
  event_results.append(sch);time_samples.append(times);durations.append(sch['makespan'])
 if not event_results:return {'status':'unavailable','low':None,'high':None,'reason':'Unresolved task rate in sampled scenario; no silent truncation.','perCustomer':[],'workload':rates[0] if rates else {'available':False},'backup':feasible_backup(raw.get('backup',{})),'taskCount':None,'unresolvedTasks':skipped,'overloadScenarios':capped}
 positive_duration=[v for v in durations if v>0];low,high=np.quantile(positive_duration,[.1,.9]).tolist() if positive_duration else [0.,0.];positive_events=[v for v in event_results if v['makespan']>0];representative=sorted(positive_events or event_results,key=lambda v:v['makespan'])[len(positive_events or event_results)//2];arr=np.array(time_samples);per=[]
 # Analytic single-fault planning windows supplement sparse per-customer MC coverage.
 factor_bounds=np.exp(-.5*sigma*sigma+sigma*norm.ppf([.1,.9]));fallback_customers=0
 selected_sets={int(i):[] for i in scope}
 if weather_mode:
  for n,p in physics.items():
   if p['scenarioFailureProbability']<=0:continue
   kinds=['pole']+(['wire'] if p.get('wireScenarioProbability',0)>0 else [])+(['short_circuit'] if p['treeContactScenarioProbability']>0 else [])
   means=[repair_work(k,raw=raw)['taskHours'] for k in kinds];lo=min(means)*factor_bounds[0]+min(delay_range)+hold;hi=max(means)*factor_bounds[1]+max(delay_range)+hold
   for c in nodes[n]['customers']:
    if int(c) in selected_sets:selected_sets[int(c)].append((lo,hi))
 for j,i in enumerate(scope):
  positive=arr[:,j][np.isfinite(arr[:,j])&(arr[:,j]>0)];basis='P10–P90 among sampled outages affecting this customer; uncalibrated';bounds=np.quantile(positive,[.1,.9]).tolist() if len(positive) else [None,None]
  if not len(positive) and selected_sets[int(i)]:
   bounds=[min(v[0] for v in selected_sets[int(i)]),max(v[1] for v in selected_sets[int(i)])];basis='Single-fault contingency envelope; sampled outages too rare. Backlog outside scenario not estimated.';fallback_customers+=1
  elif not len(positive) and not weather_mode and customers[i]['path']:bounds=[0.,0.];basis='Unaffected by these explicit failure scenarios.'
  per.append({'id':customers[i]['id'],'hoursLow':bounds[0],'hoursHigh':bounds[1],'basis':basis,'sampledAffectedScenarios':len(positive)})
 backup=feasible_backup(raw.get('backup',{}));backup['applied']=False;backup['reason']+=' No real alternate feeder is applied without a verified electrical path model.'
 return {'status':'engineering_restoration_ensemble','low':low,'high':high,'reason':None,'workload':rates[0] if rates else repair_work(s['asset'],s['size'],raw),'taskCount':int(np.median(sampled_task_count)) if sampled_task_count else 0,'meanCrewHours':float(np.mean([r['crewHours'] for r in event_results])),'expectedTasksInSelectedScenarios':float(np.mean(sampled_task_count)) if sampled_task_count else 0,'sampledComponentModes':component_counts,'perCustomer':per,'schedules':[representative],'stages':representative['stages'],'ensembleWorkloadP10P90Hours':[low,high],'rangeMeaning':'P10–P90 workload completion conditional on positive modeled damage, or explicit single-fault contingency; not an official ERT or locally calibrated coverage.','rangeScope':'Conditional workload; per-customer outage-conditioned windows reported separately.','uncertainty':{'distribution':'Lognormal with workbook mean preserved','coefficientOfVariation':cv,'cvSource':'Explicit engineering scenario assumption; not estimated from AEP labels. Distribution shape follows Arif et al. (2018).','samples':len(event_results),'drawSelection':selection,'contingencyFallback':fallback,'singleFaultCustomerFallbacks':fallback_customers},'firstRestoration':[representative['stages'][0]['hour']]*2 if representative['stages'] else None,'crewRange':crew_range,'accessDelayRange':delay_range,'hazardHoldHours':hold,'criticalFacilities':{'providedFacilities':52,'verifiedCustomerLinks':len(facility_links),'policy':'Life-support flags plus caller-confirmed facility links only; proximity never establishes supply'},'roads':{'available':False,'assumption':'Reference drive/setup included in ILM; explicit access/hold delays, no invented road route'},'backup':backup,'confidence':'Transferred-model / assumed repair variability; no real customer ERT truth','unresolvedTasks':skipped,'overloadScenarios':capped}
