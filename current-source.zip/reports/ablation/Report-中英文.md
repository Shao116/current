# 树木与风向消融实验 / Tree and wind-direction ablation

**准确率提升：未知。没有真实客户停电结果，不能计算。 / Accuracy gain: unknown; no observed customer outcomes.**

使用同一生产物理模型、真实客户依赖、相同128次模拟与种子，20组受控情景。保留电杆等级与相数，逐步加入线路方向和树木接触项。基础模型方向未知时采用现有最大横风默认；它不是旧版v2。
Same production model, topology and random seed. Baseline retains pole class/phase and uses existing maximum-crosswind fallback, then adds actual line orientation and LiDAR contact exposure. This is not a v2 benchmark.

五条线路按附近树木关联数量选取，偏向有树区域；不代表区域总体。日期为统一条件，天气为人工控制输入，非历史回测。
Five tree-rich circuits selected intentionally; synthetic hazards on real GIS, not historical outcome backtests.

|Case|Circuit|Gust mph|Wind-only %|+ direction %|+ trees %|Tree change pp|Full ms|
|---|---|---:|---:|---:|---:|---:|---:|
|1|C-041|0|0.000000|0.000000|0.000000|0.000000|15.11|
|2|C-041|40|0.731232|0.598834|0.598834|0.000000|16.05|
|3|C-041|81|3.407958|2.745940|2.745940|0.000000|15.64|
|4|C-041|100|6.503832|5.177955|5.193509|0.015554|16.06|
|5|C-054|0|0.000000|0.000000|0.000000|0.000000|11.96|
|6|C-054|40|0.953947|0.772271|0.772271|0.000000|11.98|
|7|C-054|81|4.492103|3.254348|3.255828|0.001481|12.37|
|8|C-054|100|8.638723|6.340396|6.340396|0.000000|12.16|
|9|C-071|0|0.000000|0.000000|0.000000|0.000000|11.49|
|10|C-071|40|0.759273|0.663307|0.677578|0.014271|10.85|
|11|C-071|81|3.442202|3.022350|3.137849|0.115500|12.31|
|12|C-071|100|6.449729|4.904676|4.904676|0.000000|11.69|
|13|C-073|0|0.000000|0.000000|0.000000|0.000000|8.45|
|14|C-073|40|0.899532|0.783324|0.787691|0.004367|8.84|
|15|C-073|81|4.198349|2.915323|2.944552|0.029230|9.31|
|16|C-073|100|8.015062|5.928299|5.928299|0.000000|8.96|
|17|C-030|0|0.000000|0.000000|0.000000|0.000000|8.40|
|18|C-030|40|0.804222|0.666390|0.666449|0.000059|8.58|
|19|C-030|81|3.696052|2.814625|2.835354|0.020728|8.28|
|20|C-030|100|6.987395|6.253172|6.253172|0.000000|8.29|

## Interpretation / 解释
加入树木改变了 8/20 组结果；最大变化 0.115500 个百分点。这是模型敏感性，不是准确率提升。
Trees changed modeled exposure, not measured accuracy. Terrain, rain-soil coupling and asset aging currently have no calibrated risk multiplier; adding them cannot honestly be reported as numerical accuracy gains.
地形提供环境解释；当前不直接放大风险。原始损坏阳性记录缺完整暴露分母、负样本与逐户停复电标签，不能替代真值。
运行时间只含风险与影响模拟，不含ERT；不把顺序执行产生的缓存优势当成速度提升。

{
  "cases": 20,
  "realOutcomeBacktests": 0,
  "accuracyImprovement": null,
  "treeChangedCases": 8,
  "maxTreeChangePercentagePoints": 0.11549971967211237,
  "maxDirectionChangePercentagePoints": 2.2983263842012853,
  "medianFullMs": 11.590228998102248,
  "seconds": 6.612300125008915,
  "labelGate": {
    "trainable": false,
    "reasons": [
      "No complete asset × event exposure table or observed undamaged labels.",
      "Event is Default and outage identifier is not a usable event key.",
      "Damage reports do not establish hourly customer outage/restoration outcomes."
    ]
  },
  "selection": "Five circuits ranked by nearby tree associations; deliberately tree-rich, not representative of full region",
  "timing": "Single execution per variant, shared static context cache warmed; includes 128-trial impact simulation; excludes service startup, context extraction and ERT. Ordered runs may bias timing.",
  "terrain": "Context-only in current production model; no numerical risk multiplier",
  "checks": [
    "20 completed",
    "zero wind gives zero modeled wind/tree impact",
    "adding tree term never lowers impact",
    "terrain context leaves numerical prediction unchanged"
  ],
  "sourceHashes": {
    "algorithms/vulnerability.py": "353f4ed81220a6a5f211faa2667a4726d2dbf3cad536e6d8e8e40a606555fd0e",
    "algorithms/impact.py": "128abe0a1d14177e0fe6c0621016d097c08f0e0ebb7ba688dab12cd35afa26e8",
    "private/algorithm/network.pkl": "46d3164b7db4de1d42454d5de3931ed89560e4fa35186c9f847c4683f28fa831"
  }
}