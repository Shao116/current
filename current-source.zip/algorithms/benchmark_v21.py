"""Same-input v2 versus incremental v2.1 comparison; no invented outcome truth."""
import sys,json,time,csv,statistics,threading,platform
from pathlib import Path
from collections import OrderedDict
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from engine import normalize
from algorithms.service import get_service
from algorithms.baseline_v2.service import Service as Baseline
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'reports/v21'
def resolve(raw,d):
 s=normalize(raw)
 if s['contextType']=='premise':p=d['premiseIndex'][s['contextId']];s.update({k:p[k] for k in ['lat','lng']})
 elif s['contextType']=='circuit':p=d['circuitIndex'][s['contextId']];s.update({k:p[k] for k in ['lat','lng']})
 return s

def main():
 svc=get_service();d=json.loads((ROOT/'private/data.json').read_text());d['premiseIndex']={p['id']:p for p in d['premises']};d['circuitIndex']={p['id']:p for p in d['circuits']}
 baseline=Baseline.__new__(Baseline)
 # Immutable source data and indexes shared to avoid loading a second 227MB artifact.
 for field in ['d','features','customer_tree','project','circuits','pool','predictor','modelLoadError']:setattr(baseline,field,getattr(svc,field))
 baseline.cache=OrderedDict();baseline.lock=threading.RLock();baseline.startupSeconds=0
 old=json.loads((ROOT/'reports/20-cases.json').read_text());cases=[]
 for c in old[:8]:cases.append({'id':c['case']['id'],'type':'historical_context_replay_NOT_outcome_backtest','name':'Real positive report, assumed asset identity','scenario':c['case']['scenario'],'truth':'Real positive damage record only; no outage/ERT ground truth'})
 locations=[(37.27,-79.94),(37.29,-80.05),(37.28,-79.90),(37.23,-80.01),(37.12,-80.17),(37.43,-80.08),(37.43,-79.78),(37.25,-79.73),(37.07,-79.82),(37.38,-80.20),(37.20,-79.85),(37.32,-79.98)]
 hazards=[('Rain and gusts',40,225,50,0,False),('East wind',70,90,3,0,False),('West wind',70,270,3,0,False),('Snow and wind',55,315,0,30,False),('Freezing rain',35,45,20,0,True),('Severe gusts',95,180,65,0,False),('Mountain access delay',60,300,40,5,False),('Crew shortage',75,210,30,0,False),('Calm',8,0,0,0,False),('Missing LiDAR',65,135,10,0,False),('Conductor exposure',60,180,25,20,False),('Zero wind',0,15,0,0,False)]
 for i,((lat,lng),h) in enumerate(zip(locations,hazards)):
  name,wind,direction,rain,snow,ice=h;s={'predictionMode':'weather','contextType':'map','lat':lat,'lng':lng,'asset':'wire' if i==10 else 'pole','date':f'2025-{i+1:02}-15','wind':wind,'windDirection':direction,'rainMm':rain,'snowfallCm':snow,'freezingRain':ice,'crews':1 if i==7 else 3,'accessDelay':8 if i==6 else 1,'access':i in [4,6],'seed':20261200+i,'accessDelayRange':[4,12] if i==6 else [1,1]}
  cases.append({'id':f'W{i+1:02}','type':'synthetic_hazard_real_GIS','name':name,'scenario':s,'truth':'No observed outcome; explicit hazard scenario'})
 for ident,kw,name in [('E01',{'wind':120},'Maximum API gust'),('E02',{'wind':75,'crews':6},'Six-crew sensitivity'),('E03',{'wind':75,'crews':1},'One-crew sensitivity'),('E04',{'wind':55,'backup':{'spareCapacityKW':float(100),'loadKW':50}},'Unverified backup rejected')]:
  cases.append({'id':ident,'type':'edge_case_real_GIS','name':name,'scenario':{'predictionMode':'weather','contextType':'circuit','contextId':'C-001','asset':'pole','date':'2025-09-27','windDirection':225,'seed':20261024,**kw},'truth':'No observed outcome; explicit edge scenario'})
 results=[];summaries=[]
 for case in cases:
  raw=case['scenario'];s=resolve(raw,d);times={};rs={}
  for name,service in [('v2',baseline),('v21',svc)]:
   elapsed=[]
   for repeat in range(3):
    service.cache.clear();t=time.perf_counter();r=service.run(dict(s),dict(raw));elapsed.append((time.perf_counter()-t)*1000)
   rs[name]=r;t=time.perf_counter();service.run(dict(s),dict(raw));cache=(time.perf_counter()-t)*1000;times[name]={'medianMs':statistics.median(elapsed),'maxMs':max(elapsed),'firstMs':elapsed[0],'cacheMs':cache}
  r=rs['v21'];i=r['impact'];e=r['ert'];p=rs['v2']['impact'];ert2=rs['v2']['ert'];schedules=e.get('schedules',[]);sch=schedules[0] if schedules else {};actual=i['expectedAffectedPercentage'];lohi=i.get('modelSensitivityRangePercentage');row={'case':case['id'],'type':case['type'],'name':case['name'],'date':raw['date'],'circuit':r['scopeCircuit'],'lat':round(s['lat'],2),'lng':round(s['lng'],2),'gustMph':r['physicsFeatures']['weather']['gustMph'],'direction':r['physicsFeatures']['weather'].get('windDirection'),'v2ImpactPct':p['expectedAffectedPercentage'],'v21ImpactPct':actual,'modelLowPct':lohi[0] if lohi else None,'modelHighPct':lohi[1] if lohi else None,'v2ERTLowH':ert2['low'],'v2ERTHighH':ert2['high'],'v21ERTLowH':e['low'],'v21ERTHighH':e['high'],'restorationStages':len(e.get('stages',[])),'v2MedianMs':times['v2']['medianMs'],'v21MedianMs':times['v21']['medianMs'],'v21CacheMs':times['v21']['cacheMs'],'coveragePct':i.get('modeledCustomerCoveragePercentage'),'actualOutagePct':None,'actualERT':None,'error':None,'reliability':'Transferred/uncalibrated' if 'riskAssessment' in r else 'Known-failure engineering replay','winterPartial':r.get('riskAssessment',{}).get('status')=='partial_winter_hazard','fifoCustomerObjective':sch.get('fifoObjective'),'optimizedCustomerObjective':sch.get('objective'),'customerObjectiveImprovement':sch.get('improvementAgainstFIFO'),'ERTSource':e.get('workload',{}).get('source','AEP workbook'),'limitations':'; '.join(i.get('warnings',[])),'truth':case['truth']}
  # No falsely claiming risk-model superiority from different model semantics.
  if raw.get('failedNodes'):
   scope=[c for c in svc.d['customers'] if c['circuit']==r['scopeCircuit']];ref=sum(bool(set(raw['failedNodes']).intersection(c['path'])) for c in scope)/len(scope)*100;row['sourcePathDifferencePct']=abs(ref-actual)
  else:row['sourcePathDifferencePct']=None
  results.append({'case':case,'timing':times,'metrics':row,'v2Summary':{k:rs['v2'][k] for k in ['performance','model']},'result':r});summaries.append(row);print(case['id'],'v2',p['expectedAffectedPercentage'],'v21',actual,'ERT',e['low'],e['high'],'ms',round(times['v21']['medianMs'],1),flush=True)
 with (OUT/'24-scenarios.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=summaries[0]);w.writeheader();w.writerows(summaries)
 (OUT/'24-scenarios.json').write_text(json.dumps(results,allow_nan=False))
 summary={'cases':len(results),'contextReplays':8,'weatherAndEdgeScenarios':16,'realOutcomeBacktests':0,'v2NumericImpactCases':sum(r['v2ImpactPct'] is not None for r in summaries),'v21NumericImpactCases':sum(r['v21ImpactPct'] is not None for r in summaries),'v2MedianMs':statistics.median(r['v2MedianMs'] for r in summaries),'v21MedianMs':statistics.median(r['v21MedianMs'] for r in summaries),'v21P95Ms':float(np.quantile([r['v21MedianMs'] for r in summaries],.95)),'v21MedianCacheMs':statistics.median(r['v21CacheMs'] for r in summaries),'newCustomerStageCases':sum(r['restorationStages']>0 for r in summaries),'maxKnownFailurePathDifferencePct':max(r['sourcePathDifferencePct'] or 0 for r in summaries),'predictionAccuracy':None,'ERT_MAE':None,'sourceAudit':svc.d['audit'],'supportAssociationAudit':svc.physics.audit,'platform':platform.platform(),'python':platform.python_version(),'coldServiceStartupSeconds':svc.startupSeconds,'firstPhysicsRequestMs':results[8]['timing']['v21']['firstMs'],'seedBase':20261024,'comparisonMeaning':'Same input cases; v2 count-conditioned impact and v2.1 weather-conditioned reference scenarios have different estimands. Availability/responsiveness improve; no predictive-accuracy superiority is inferred.'}
 (OUT/'comparison-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k not in ['sourceAudit','supportAssociationAudit']},indent=2))
if __name__=='__main__':main()
