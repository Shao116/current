"""Reproducible private exact-geometry ingest; no raw customer identifiers in exports."""
import sys,json,pickle,hashlib,collections,struct
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from prepare_data import SRC,ROOT,dbf,shapes,anon
from zipfile import ZipFile
import numpy as np
from pyproj import Transformer
from scipy.spatial import cKDTree
import networkx as nx
OUT=ROOT/'private/algorithm';OUT.mkdir(exist_ok=True)
LAYERS={'Pole_Clip':'pole','Primary_ExportFeatures':'wire','Secondary_ExportFeatures':'secondary','Transformer_Clip':'transformer','Fuse_Bank_Clip':'fuse','Switch_Clip':'switch','Recloser_Bank_Clip':'recloser'}
def main():
 project=Transformer.from_crs(4326,26917,always_xy=True);merc=Transformer.from_crs(3857,4326,always_xy=True)
 assets=[];customers=[];damage=[];facilities=[];lookup={};circuits={};inventory={};rawids=collections.defaultdict(list);locations=collections.defaultdict(list)
 for fn in ['Data1.zip','Data2.zip']:
  with ZipFile(SRC/'data/raw'/fn) as z:
   for name in [n[:-4] for n in z.namelist() if n.endswith('.dbf')]:
    rows=list(dbf(z,name));geoms=list(shapes(z,name));inventory[name]=len(rows)
    for i,(r,g) in enumerate(zip(rows,geoms)):
     if name=='Customer_Clip':
      c=r['circuit_id'];circuits.setdefault(c,f'C-{len(circuits)+1:03}')
      p={'id':f'P-{i+1:06}','xy':project.transform(*g),'circuit':circuits[c],'criticalRaw':r.get('critical_c',''),'specialRaw':r.get('special_op',''),'path':[]};lookup[r['premise_nu']]=len(customers);customers.append(p)
     elif name in LAYERS:
      # Keep complete original attributes privately for joins/material feature extraction.
      a={'id':f'A-{LAYERS[name]}-{i+1:06}','kind':LAYERS[name],'attributes':r,'geometry':g}
      pt=g[0] if isinstance(g[0],list) else g;a['xy']=project.transform(*pt);a['lnglat']=pt
      j=len(assets);assets.append(a);rawids[r.get('id','')].append(j);locations[r.get('location_n','')].append(j)
     elif name=='arcos_prod_damage_09_28_Clip':damage.append({'id':f'D-{i+1:04}','xy':project.transform(*g),'attributes':r})
     else:
      p=merc.transform(*g);facilities.append({'id':f'F-{len(facilities)+1:03}','kind':name.split('_')[0],'xy':project.transform(*p)})
 nodes={};graph=nx.DiGraph();rows=0;duplicates=0;joins=collections.Counter()
 with ZipFile(SRC/'data/raw/matched_upstream.zip') as z:
  for line in z.read('matched_upstream.txt').decode().splitlines():
   rows+=1;parts=line.split('\t');ci=lookup.get(parts[0]);path=[]
   for item in parts[1:]:
    b=item.split('*')
    if len(b)<3:continue
    nid=anon('N',item);path.append(nid)
    if nid not in nodes:
     candidates=rawids.get(b[1],[]);method='id'
     if not candidates and len(b)>3:candidates=locations.get(b[3],[]);method='location'
     ai=candidates[0] if len(candidates)==1 else None;joins[method if ai is not None else 'unmatched_or_ambiguous']+=1
     nodes[nid]={'id':nid,'type':b[2],'asset':ai,'customers':[]}
    if ci is not None:nodes[nid]['customers'].append(ci)
   # Authoritative customer path retained, graph conflicts audited separately.
   graph.add_edges_from(zip(path[1:],path[:-1]));graph.add_nodes_from(path)
   if ci is not None:
    if customers[ci]['path']:duplicates+=1
    customers[ci]['path']=path
 for n in nodes.values():n['customers']=np.unique(n['customers']).astype(np.int32)
 for i,a in enumerate(assets):a['nodes']=[]
 for n,v in nodes.items():
  if v['asset'] is not None:assets[v['asset']]['nodes'].append(n)
 # Damage spatial association is candidate-only, never a verified asset identity/negative label.
 trees={}
 for kind in sorted(set(a['kind'] for a in assets)):
  inds=np.array([i for i,a in enumerate(assets) if a['kind']==kind]);trees[kind]=(inds,cKDTree([assets[i]['xy'] for i in inds]))
 for d in damage:
  t=d['attributes']['Asset_Type'].lower();kind=next((k for word,k in [('transform','transformer'),('primary','wire'),('secondary','secondary'),('pole','pole'),('fuse','fuse'),('switch','switch'),('recloser','recloser')] if word in t),None)
  d['candidate']=None
  if kind:
   inds,tree=trees[kind];dist,j=tree.query(d['xy']);d['candidate']={'asset':int(inds[j]),'distanceM':float(dist),'verified':False,'method':'nearest reference point; line distance not verified' if kind in ['wire','secondary'] else 'nearest point; identity not verified'}
 # Critical flags are not interpreted without a supplied codebook.
 critical=collections.Counter(p['criticalRaw'] for p in customers);special=collections.Counter(p['specialRaw'] for p in customers)
 customer_tree=cKDTree([p['xy'] for p in customers])
 for f in facilities:
  dist,j=customer_tree.query(f['xy']);f['candidateCustomer']=int(j);f['distanceM']=float(dist);f['verifiedCustomerLink']=False
 audit={'inventory':inventory,'customers':len(customers),'matchedCustomers':sum(bool(p['path']) for p in customers),'topologyRows':rows,'duplicateCustomerPaths':duplicates,'nodes':len(nodes),'edges':graph.number_of_edges(),'acyclic':nx.is_directed_acyclic_graph(graph),'multipleParents':sum(graph.in_degree(n)>1 for n in graph),'assetJoins':dict(joins),'assetKinds':dict(collections.Counter(a['kind'] for a in assets)),'criticalCodes':dict(critical),'specialCodes':dict(special),'facilityCount':len(facilities),'labelGate':{'trainable':False,'reasons':['No complete asset × event exposure table or observed undamaged labels.','Event is Default and outage identifier is not a usable event key.','Damage reports do not establish hourly customer outage/restoration outcomes.']},'lineGeometryAudit':'All 62,788 primary and 127,403 secondary features have a single SHP part; no disconnected parts concatenated in this extract','region':'Roanoke, Virginia, USA — not Ohio','sourceSha256':{str(p.relative_to(SRC)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [SRC/'data/raw/Data1.zip',SRC/'data/raw/Data2.zip',SRC/'data/raw/matched_upstream.zip',SRC/'data/Install_Labor_HackOHIO.xlsx']}}
 audit['historicalLabelEvidence']={'eventCounts':dict(collections.Counter(d['attributes']['Event'] for d in damage)),'uniqueOutageIdentifiers':len(set(d['attributes']['Outage_Num'] for d in damage)),'reportStringLengths':dict(collections.Counter(len(d['attributes']['Report_Tim']) for d in damage)),'repairedFlags':dict(collections.Counter(d['attributes']['Repaired'] for d in damage)),'repairDatePresent':sum(bool(d['attributes']['Repaired_D']) for d in damage)}
 obj={'assets':assets,'customers':customers,'nodes':nodes,'graph':graph,'damage':damage,'facilities':facilities,'audit':audit}
 with (OUT/'network.pkl').open('wb') as f:pickle.dump(obj,f,protocol=5)
 (OUT/'audit.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit,indent=2))
if __name__=='__main__':main()
