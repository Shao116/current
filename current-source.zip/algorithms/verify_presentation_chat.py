from pathlib import Path
import urllib.request,json,time
s={'contextType':'premise','contextId':'P-094125','predictionMode':'weather','wind':81,'windDirection':297,'date':'2012-06-29','crews':3}
r=urllib.request.Request('http://127.0.0.1:8765/api/chat',data=json.dumps({'message':'Explain my selected home risk in one short sentence. Do not quote circuit averages.','scenario':s}).encode(),headers={'Content-Type':'application/json'});start=time.time();parts=[]
with urllib.request.urlopen(r,timeout=90) as response:
 for line in response:
  d=json.loads(line)
  if 'token' in d:parts.append(d['token'])
  if d.get('error'):raise RuntimeError(d['error'])
text=''.join(parts);assert len(text)>20
Path('reports/launch/ollama-check.txt').write_text(f'Actual local Ollama streaming response; {time.time()-start:.2f} seconds\n'+text);print(text)
