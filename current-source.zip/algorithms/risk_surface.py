"""Regional expected customer impact raster; interpolation is display-only.
Unlike a density heatmap, color represents model output, not customer/report count.
Missing coverage stays gray. No electrical connectivity is interpolated.
"""
import math,json,hashlib,time,io,base64,threading
from pathlib import Path
import numpy as np
from scipy.ndimage import gaussian_filter
from scipy.spatial import cKDTree,Delaunay,ConvexHull
from scipy.sparse import csr_matrix
from scipy.special import ndtri
from scipy.stats import norm
from numpy.polynomial.hermite import hermgauss
from pyproj import Transformer
from PIL import Image
from .vulnerability import PhysicsModel
ROOT=Path(__file__).resolve().parents[1]
STOPS=[0,1,5,15,30,100]
COLORS=['#42a66b','#b9cf48','#f2ce3d','#ef8b31','#d94335','#8d2239']
def band(percent):
 if percent is None:return {'label':'Coverage unavailable','color':'#66756e'}
 number=float(percent)
 if not math.isfinite(number) or not 0<=number<=100:raise ValueError('Invalid impact percentage')
 i=0 if number<1 else 1 if number<5 else 2 if number<15 else 3 if number<30 else 4
 return {'label':['Limited impact','Moderate impact','Elevated impact','High impact','Severe impact'][i],'color':['#28794b','#7b771c','#9b7111','#b6531b','#b52e30'][i]}
def expected_customers(nodes,customers,ids,probabilities,rho=.35):
 rows=[];cols=[]
 for j,n in enumerate(ids):
  ci=nodes[n]['customers'];rows.extend(ci.tolist());cols.extend([j]*len(ci))
 exposure=csr_matrix((np.ones(len(rows)),(rows,cols)),shape=(len(customers),len(ids)))
 z,w=hermgauss(32);q=norm.cdf((ndtri(probabilities)[:,None]-math.sqrt(rho)*z[None,:]*math.sqrt(2))/math.sqrt(1-rho));q=np.clip(q,0,1-1e-15)
 values=(-np.expm1(exposure@np.log1p(-q)))@(w/math.sqrt(math.pi));known=np.asarray(exposure.sum(axis=1)).ravel()>0
 return values,known

def raster(ll,values,known,width=400,height=300):
 # About 0.2–0.3km pixels, 1.5px Gaussian display smoothing; never infer routing.
 west,south=ll.min(axis=0)-[.012,.009];east,north=ll.max(axis=0)+[.012,.009]
 xs=np.linspace(west,east,width+1);ys=np.linspace(south,north,height+1)
 gx,gy=np.meshgrid((xs[:-1]+xs[1:])/2,(ys[:-1]+ys[1:])/2);grid=np.column_stack([gx.ravel(),gy.ravel()]);units=np.array([88500,111000]);tree=cKDTree(ll[known]*units) if known.any() else None
 if tree is not None:
  k=min(8,int(known.sum()));dist,nearest=tree.query(grid*units,k=k)
  if k==1:dist=dist[:,None];nearest=nearest[:,None]
  weights=1/np.maximum(dist,1.)**2;local=(values[known][nearest]*weights).sum(axis=1)/weights.sum(axis=1)*100;v=gaussian_filter(local.reshape(height,width),1.5);valid=dist[:,0].reshape(height,width)<=3000
 else:v=np.zeros((height,width));valid=np.zeros((height,width),bool)
 # Entire source footprint gets an overlay: neutral gray where the model is unsupported.
 hull=Delaunay(ll[ConvexHull(ll).vertices]);inside=hull.find_simplex(grid)>=0;inside=inside.reshape(height,width)
 rgb=np.array([[int(c[i:i+2],16) for i in (1,3,5)] for c in COLORS]);out=np.empty((height,width,4),dtype=np.uint8)
 for k in range(3):out[:,:,k]=np.interp(v,STOPS,rgb[:,k]).astype(np.uint8)
 out[:,:,3]=np.where(valid&inside,166,np.where(inside,90,0));out[~valid,:3]=[133,145,141]
 image=Image.fromarray(np.flipud(out));f=io.BytesIO();image.save(f,format='PNG',optimize=True)
 return {'image':'data:image/png;base64,'+base64.b64encode(f.getvalue()).decode(),'coordinates':[[float(west),float(north)],[float(east),float(north)],[float(east),float(south)],[float(west),float(south)]],'bounds':[[float(west),float(south)],[float(east),float(north)]],'rasterSize':[width,height],'displaySmoothing':'Eight-nearest-customer inverse-distance display interpolation, 1.5-pixel smoothing, within 3km of modeled customers; gray unsupported, transparent outside source hull. Not a calibrated spatial forecast.'}

SURFACE_LOCK=threading.RLock()
def surface(service,s,raw):
 start=time.perf_counter()
 weather={'date':str(raw.get('date','2026-10-24')),'gustMph':s['wind'],'windDirection':float(raw.get('windDirection',0)),'source':'Explicit region-wide weather replay or selected forecast sample','snowfallCm':float(raw.get('snowfallCm',0)),'snowDepthM':float(raw.get('snowDepthM',0)),'freezingRainIndicator':raw.get('freezingRain') is True}
 rho=float(raw.get('correlation',.35));corridor=float(raw.get('fallCorridorM',1.))
 if not all(math.isfinite(v) for v in [weather['windDirection'],weather['snowfallCm'],weather['snowDepthM'],rho,corridor]) or weather['snowfallCm']<0 or weather['snowDepthM']<0 or not 0<=rho<1 or not 0<corridor<=100:raise ValueError('Invalid surface parameters')
 # A region-wide replay deliberately uses one weather vector everywhere. No claimed storm track.
 key=json.dumps([weather,rho,corridor],sort_keys=True)
 with SURFACE_LOCK:
  if not hasattr(service,'surface_signature'):
   signature=''.join(hashlib.sha256((ROOT/'algorithms'/p).read_bytes()).hexdigest() for p in ['risk_surface.py','vulnerability.py','features.py','literature.json'])
   for relative in ['private/algorithm/network.pkl','private/algorithm/dem.tif','public/data/lidar-trees.geojson']:signature+=str((ROOT/relative).stat().st_mtime_ns)
   service.surface_signature=signature
  filename=hashlib.sha256((service.surface_signature+key).encode()).hexdigest()+'.json';directory=ROOT/'private/algorithm/surfaces';path=directory/filename
  if path.exists():
   out=json.loads(path.read_text());out['performance']={'cacheHit':True,'seconds':time.perf_counter()-start};return out
  with service.lock:
   if not hasattr(service,'physics'):service.physics=PhysicsModel(service.d,service.features)
  physics=service.physics;ids=physics.ids;feature={'seasonalWind':{'available':False}};p,lo,hi,_,method=physics.predict(ids,weather,feature,{'windDirection':weather['windDirection'],'fallCorridorM':corridor})
  values,known=expected_customers(physics.nodes,service.d['customers'],ids,p,rho)
  if not hasattr(service,'surface_ll'):
   xy=np.array([c['xy'] for c in service.d['customers']]);lng,lat=Transformer.from_crs(26917,4326,always_xy=True).transform(xy[:,0],xy[:,1]);service.surface_ll=np.column_stack([lng,lat])
  out=raster(service.surface_ll,values,known);out.update({'expectedAffectedPercentage':float(values.mean()*100),'modeledCustomers':int(known.sum()),'totalCustomers':len(values),'winterPartial':weather['snowfallCm']>0 or weather['snowDepthM']>0 or weather['freezingRainIndicator'],'weather':weather,'bands':{'stops':STOPS,'colors':COLORS,'thresholds':[1,5,15,30],'labels':['Limited','Moderate','Elevated','High','Severe'],'basis':'Product planning bands, NOT validated danger cutoffs or official utility thresholds'},'basis':'Uncalibrated published wind/tree model + actual source customer upstream paths; uniform regional hazard; color is expected customer fraction, never point density.','performance':{'cacheHit':False,'seconds':time.perf_counter()-start}})
  directory.mkdir(exist_ok=True);tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(out,allow_nan=False));tmp.replace(path)
  for old in sorted(directory.glob('*.json'),key=lambda f:f.stat().st_mtime,reverse=True)[16:]:old.unlink()
  return out
