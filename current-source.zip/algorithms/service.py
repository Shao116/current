"""Cached application orchestration; abstains when forecast labels/topology are absent."""
import pickle,json,time,math,threading,copy
from pathlib import Path
from collections import OrderedDict
import numpy as np
from scipy.spatial import cKDTree
from pyproj import Transformer
from .features import Features
from .impact import simulate,exact_customers
from .restoration import labor,schedule,customer_restore,feasible_backup
ROOT=Path(__file__).resolve().parents[1]
class Service:
 def __init__(self):
  start=time.perf_counter()
  with (ROOT/'private/algorithm/network.pkl').open('rb') as f:self.d=pickle.load(f)
  self.features=Features();self.customer_tree=cKDTree([p['xy'] for p in self.d['customers']]);self.project=Transformer.from_crs(4326,26917,always_xy=True)
  self.circuits={}
  for i,p in enumerate(self.d['customers']):self.circuits.setdefault(p['circuit'],[]).append(i)
  self.pool={}
  for c,ix in self.circuits.items():
   nset=set(n for i in ix for n in self.d['customers'][i]['path']);self.pool[c]=sorted(nset)
  self.predictor=None;self.modelLoadError=None
  model_path=ROOT/'private/algorithm/model/candidate.joblib'
  if model_path.exists():
   try:
    from .model import Predictor
    self.predictor=Predictor(model_path)
   except Exception as e:self.modelLoadError=str(e)
  coverage_path=ROOT/'private/algorithm/data-coverage.json'
  coverage=json.loads(coverage_path.read_text()) if coverage_path.exists() else {}
  self.fusion={'sourceFilesAudited':coverage.get('sourceFilesAudited',0),'organizerInputMatches':coverage.get('organizerInputMatches',{}),'roles':coverage.get('roles',[]),'fullFusionClaim':False,'calibratedProbability':False,'PINN':coverage.get('PINN',{}),'extension':'Exact workbook specs and both overhead line endpoints'}
  self.cache=OrderedDict();self.lock=threading.RLock();self.startupSeconds=time.perf_counter()-start
 def status(self):
  return {'version':'2.1.0','dataFusion':self.fusion,'audit':self.d['audit'],'model':{'status':'validated_candidate' if self.predictor else 'not_trained','unconditionalProbabilitiesAvailable':bool(self.predictor),'reasons':[] if self.predictor else self.d['audit']['labelGate']['reasons'],'pipeline':'XGBoost + chronological event split + isotonic calibration + logistic/constant baseline gate; no model approved for these data'},'terrain':self.features.demmeta,'historyWeatherYears':list(self.features.weather),'lidarBounds':self.features.bounds,'cacheEntries':len(self.cache),'startupSeconds':self.startupSeconds,'engineeringPrediction':{'active':True,'method':'Published wind fragility + exact customer paths + shared-location support groups','calibratedToAEP':False},'backupSupply':'Disabled for real grid: no verified tie capacity/protection/switching plan','drawings':'Nine engineering reference pages; not an asset-specific verified bill of materials'}
 def run(self,s,raw):
  # Existing explicit damage scenarios keep their meaning. Frontend requests weather mode.
  for field in ['windDirection','rainMm','snowfallCm','snowDepthM','repairHours','iceAccretionMm','fallCorridorM']:
   if field in raw and (not isinstance(raw[field],(int,float)) or not math.isfinite(raw[field]) or raw[field]<0):raise ValueError('Invalid '+field)
  if raw.get('components') is not None and (not isinstance(raw['components'],list) or not raw['components'] or len(raw['components'])>100):raise ValueError('components must contain 1–100 entries')
  if not isinstance(raw.get('damageDetails',{}),dict):raise ValueError('damageDetails must be a node-keyed object')
  if not isinstance(raw.get('backup',{}),dict):raise ValueError('backup must be an object')
  if raw.get('predictionMode') not in [None,'weather','conditional']:raise ValueError('Unknown predictionMode')
  if not isinstance(raw.get('crewSize',1),int) or not 1<=raw.get('crewSize',1)<=20:raise ValueError('Invalid crewSize')
  from .component_evidence import adder_hours,drawing_reference
  adder_hours(raw.get('laborAdders',[]),s['access']);drawing_reference(raw.get('drawingPage'))
  weather_mode=raw.get('predictionMode')=='weather' or (raw.get('predictionMode') is None and not any(k in raw for k in ['quantity','upstream','failedNodes']))
  if weather_mode and raw.get('failedNodes') is None:
   from .weather_engine import run_weather
   return run_weather(self,s,raw)
  started=time.perf_counter();final_key='v21-conditional:'+json.dumps([s,raw],sort_keys=True,allow_nan=False)
  with self.lock:
   if final_key in self.cache:
    hit=copy.deepcopy(self.cache[final_key]);hit['performance']['cacheHit']=True;return hit
  result=self._run_conditional(s,raw)
  # Reuse v2 known-failure impact. Replace only the ERT ensemble.
  if raw.get('restorationModel')!='v2':
   from .restoration_ensemble import restore_ensemble
   known=raw.get('failedNodes');nodes=self.d['nodes'];scope=[i for i,p in enumerate(self.d['customers']) if raw.get('scope')=='all' or p['circuit']==result['scopeCircuit']]
   if known is not None:draws=[known]*16
   else:
    # The original count-conditioned MC remains authoritative for impact.
    candidates=[n for n in self.pool[result['scopeCircuit']] if nodes[n]['asset'] is not None and self.d['assets'][nodes[n]['asset']]['kind']==s['asset']]
    if raw.get('scope')=='all':candidates=[n for n,v in nodes.items() if v['asset'] is not None and self.d['assets'][v['asset']]['kind']==s['asset']]
    if candidates:
     temp=simulate(nodes,self.d['customers'],scope,candidates,s['quantity']+s['upstream'],int(raw.get('trials',128)),int(raw.get('seed',20261024)),float(raw.get('correlation',.35)));draws=temp['_draws']
    else:
     nodes=dict(nodes);jobs=[f'JOB-{i}' for i in range(s['quantity']+s['upstream'])]
     for n in jobs:nodes[n]={'asset':None,'customers':np.array([],dtype=np.int32)}
     draws=[jobs]*16
   ert=restore_ensemble(self.d,nodes,scope,draws,s,raw)
   if known is None and not candidates:
    for p in ert['perCustomer']:p.update(hoursLow=None,hoursHigh=None,basis='Workload only: no verified failure-to-customer link')
   result['ert']=ert
  result['dataFusion']=self.fusion
  result['performance']['seconds']=time.perf_counter()-started
  with self.lock:
   if len(json.dumps(result,allow_nan=False))<8_000_000:self.cache[final_key]=copy.deepcopy(result)
   while len(self.cache)>32:self.cache.popitem(last=False)
  return result
 def _run_conditional(self,s,raw):
  key=json.dumps([s,raw],sort_keys=True,allow_nan=False)
  with self.lock:
   if key in self.cache:
    x=copy.deepcopy(self.cache[key]);self.cache.move_to_end(key);x['performance']['cacheHit']=True;return x
  start=time.perf_counter();customers=self.d['customers'];nodes=self.d['nodes'];assets=self.d['assets']
  if s['contextType']=='premise':ci=int(s['contextId'].split('-')[1])-1
  else:_,ci=self.customer_tree.query(self.project.transform(s['lng'],s['lat']));ci=int(ci)
  circuit=s['contextId'] if s['contextType']=='circuit' else customers[ci]['circuit'];scope=self.circuits[circuit]
  if raw.get('scope')=='all':scope=list(range(len(customers)))
  weather={'date':str(raw.get('date','2026-10-24')),'gustMph':s['wind'],'windDirection':float(raw.get('windDirection',0)),'rainMm':float(raw.get('rainMm',0)),'snowfallCm':float(raw.get('snowfallCm',0)),'snowDepthM':float(raw.get('snowDepthM',0)),'freezingRainIndicator':raw.get('freezingRain') is True,'iceAccretionMm':None,'source':'Caller-selected scenario; missing rain/snow/direction default to zero as explicit scenario assumptions, not observations'}
  if raw.get('historicalWeather') is True:
   actual=self.features.historical(weather['date'],s['lng'],s['lat'])
   if actual:weather=actual
   else:weather={'date':weather['date'],'gustMph':s['wind'],'windDirection':float(raw.get('windDirection',0)),'source':'Historical weather missing; manual scenario fallback explicitly used','historicalUnavailable':True}
  precise=(s['lng'],s['lat'])
  if s['contextType']=='premise':precise=Transformer.from_crs(26917,4326,always_xy=True).transform(*customers[ci]['xy'])
  feature=self.features.at(*precise,weather)
  kind=s['asset'];candidates=[n for n in (sorted(nodes) if raw.get('scope')=='all' else self.pool[circuit]) if nodes[n]['asset'] is not None and assets[nodes[n]['asset']]['kind']==kind]
  count=s['quantity']+s['upstream'];known=raw.get('failedNodes');trials=int(raw.get('trials',128));seed=int(raw.get('seed',20261024));rho=float(raw.get('correlation',.35))
  if known is not None:
   if not isinstance(known,list) or len(known)>60 or any(n not in nodes for n in known):raise ValueError('Unknown/invalid failedNodes')
   if len(set(known))!=len(known):raise ValueError('Duplicate failedNodes are not distinct failures')
   candidates=sorted(set(known));count=len(known)
  if not 16<=trials<=2048 or not 0<=rho<1:raise ValueError('trials must be 16–2048 and correlation in [0,1)')
  predictions=[];marginals=None
  if self.predictor and candidates and known is None:
   fs=[self.features.at(*assets[nodes[n]['asset']]['lnglat'],weather,asset=assets[nodes[n]['asset']]) for n in candidates]
   predictions=self.predictor.predict(fs);marginals=[p['probability'] for p in predictions]
  if candidates or count==0:
   impact=simulate(nodes,customers,scope,candidates,count,trials,seed,rho,marginals=marginals,known_failures=known);draws=impact.pop('_draws')
   impact.update({'status':'model_simulation' if marginals is not None else 'conditional_engineering_baseline','outageProbability':None,'region':circuit,'scope':'Entire supplied customer extract' if raw.get('scope')=='all' else 'Selected circuit; not entire AEP service territory','warnings':['Failure count and overlap-block mixture are scenario assumptions, not weather-derived probabilities. Requested count is capped at available distinct devices.','Only source customer paths establish disconnection; no nearest-asset inferred topology.','Unknown customer paths are excluded from known affected count and included in the missing-data upper bound.']})
  else:
   impact={'status':'unavailable','basis':'missing_verified_asset_topology','outageProbability':None,'expectedAffectedPercentage':None,'scenarioInterval95Percentage':None,'monteCarloMeanCI95Percentage':None,'scopeCustomers':len(scope),'candidateDevices':0,'perCustomer':[{'id':customers[i]['id'],'outageProbability':None,'conditionalOutageProbability':None,'topologyAvailable':bool(customers[i]['path'])} for i in scope],'warnings':[f'No verified {kind}-to-customer path in selected scope; spatial proximity is not electrical connectivity.'],'trials':0};draws=[]
  crew_size=raw.get('crewSize',1)
  if not isinstance(crew_size,int) or not 1<=crew_size<=20:raise ValueError('crewSize must be an integer between 1 and 20')
  for field in ['windDirection','rainMm','snowfallCm','snowDepthM','repairHours']:
   if field in raw and (not isinstance(raw[field],(int,float)) or not math.isfinite(raw[field]) or raw[field]<0):raise ValueError('Invalid '+field)
  if raw.get('components') is not None and (not isinstance(raw['components'],list) or not raw['components'] or len(raw['components'])>100):raise ValueError('components must contain 1–100 entries')
  work=labor(kind,s['size'],raw.get('components'),s['access'],raw.get('repairHours'),raw.get('laborBasis','crew_hours'),int(raw.get('crewSize',1)))
  ert={'status':'unavailable','low':None,'high':None,'perCustomer':[],'reason':work.get('reason'),'workload':work,'backup':feasible_backup(raw.get('backup',{})),'roads':{'available':False,'reason':'No routable road/closure data; workbook ILM already includes reference drive time. accessDelay is a user assumption.'},'criticalFacilities':{'count':52,'verifiedCustomerLinks':0,'candidateLinksPrivateOnly':True},'confidence':'Unvalidated engineering scenario; no hourly outcome labels','rangeScope':'Completion of scenario repair workload. Per-customer restoration is separate and requires verified failed ancestors.','taskCount':impact.get('effectiveFailureCount',count),'drawingReference':json.loads((ROOT/'algorithms/drawings.json').read_text())}
  schedules=[];customer_times=[];taskfeatures=[]
  if work['available']:
   # Bounds are actual declared parameter sensitivity, not arbitrary confidence multipliers.
   crew_options=raw.get('crewRange',[s['crews'],s['crews']]);delay_options=raw.get('accessDelayRange',[s['accessDelay'],s['accessDelay']])
   if len(crew_options)!=2 or any(not isinstance(v,int) or not 1<=v<=20 for v in crew_options) or len(delay_options)!=2 or any(not isinstance(v,(int,float)) or not math.isfinite(v) or not 0<=v<=72 for v in delay_options):raise ValueError('Invalid crew/delay sensitivity bounds')
   # Run scheduling on representative MC failure sets, all sets identical when observed input.
   work_draws=draws[:min(16,len(draws))] if draws else [[None]*count]
   for ix,failed in enumerate(work_draws):
    failed=failed if failed else []
    tasks=[]
    for n in failed:
     deps=nodes[n]['customers'] if n else [];critical=sum(customers[int(i)]['criticalRaw']=='LS Life Support' for i in deps)
     # Critical needs are prioritized explicitly; this is policy, not a probability weight.
     tasks.append({'node':n,'hours':work['taskHours'],'weight':len(deps)+critical*len(customers)+1,'release':delay_options[ix%2] if tasks or failed else 0})
    sch=schedule(tasks,crew_options[ix%2],time_limit=.05 if ix==0 else .01);schedules.append(sch)
    if failed and failed[0] is not None:
     finish={tasks[e['task']]['node']:e['end'] for e in sch['events']};times=customer_restore(customers,scope,failed,finish);customer_times.append(times)
   durations=[a['makespan'] for a in schedules];ert.update({'status':'conditional_engineering_baseline','low':min(durations,default=0),'high':max(durations,default=0),'rangeMeaning':'Range across sampled damage-location and explicitly declared crew/access scenarios; NOT calibrated 95% ERT confidence interval.','schedules':schedules[:1],'schedulingScenarios':len(schedules),'crewRange':crew_options,'accessDelayRange':delay_options,'firstRestoration':None,'reason':None})
   if customer_times:
    arr=np.array([[np.nan if v is None else v for v in t] for t in customer_times]);ert['perCustomer']=[{'id':customers[i]['id'],'hoursLow':None if np.all(np.isnan(arr[:,j])) else float(np.nanmin(arr[:,j])),'hoursHigh':None if np.all(np.isnan(arr[:,j])) else float(np.nanmax(arr[:,j])),'basis':'Conditional sampled-scenario range; zero means unaffected in that sample, not guaranteed supply'} for j,i in enumerate(scope)]
    positives=arr[arr>0];ert['firstRestoration']=[float(positives.min()),float(positives.min())] if len(positives) else None
   # Feature attribution remains available even though learned risk must abstain.
   for n in next(iter(draws),[])[:8]:
    a=assets[nodes[n]['asset']] if nodes[n]['asset'] is not None else None
    if a:taskfeatures.append({'node':n,'kind':a['kind'],'features':self.features.at(*a['lnglat'],weather,asset=a)})
  if not ert['perCustomer']:
   ert['perCustomer']=[{'id':customers[i]['id'],'hoursLow':None,'hoursHigh':None,'basis':'Customer restoration unavailable: failed-asset connectivity or labor rate missing.'} for i in scope]
  result={'impact':impact,'ert':ert,'physicsFeatures':feature,'equipmentPredictions':[{'node':n,**p} for n,p in zip(candidates,predictions)],'equipmentFeatures':taskfeatures,'model':self.status()['model'],'performance':{'cacheHit':False,'seconds':time.perf_counter()-start,'seed':seed},'scopeCircuit':circuit}
  with self.lock:
   if len(json.dumps(result,allow_nan=False))<8_000_000:self.cache[key]=copy.deepcopy(result)
   while len(self.cache)>32:self.cache.popitem(last=False)
  return result
_instance=None;_init_lock=threading.Lock()
def get_service():
 global _instance
 with _init_lock:
  if _instance is None:_instance=Service()
 return _instance
