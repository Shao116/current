"""Documented presentation policies, independent of damage-probability estimation.
58 mph is severe-wind safety context; >=5% is an explicit product planning band,
not a calibrated probability threshold or an official utility alert policy.
"""
import math

def guidance(s,result):
 weather=result.get('physicsFeatures',{}).get('weather',{});gust=weather.get('gustMph',s['wind']);pct=result['impact'].get('expectedAffectedPercentage');winter=bool(weather.get('freezingRainIndicator') or weather.get('snowfallCm',0)>0 or weather.get('snowDepthM',0)>0)
 weather_trigger=gust>=58 or winter;planning_trigger=isinstance(pct,(int,float)) and math.isfinite(pct) and pct>=5;needs=s['medical'] or s['accessible'] or s['critical'];eligible=bool(needs or s['stage']!='pre' or weather_trigger or planning_trigger)
 actions=[]
 if s['medical'] or s['critical']:actions.append({'id':'medical','title':'Confirm your critical-power backup plan','detail':'Check available backup runtime and coordinate with your care team or facility operator. A priority plan does not guarantee power.'})
 if s['accessible']:actions.append({'id':'accessibility','title':'Arrange accessible support','detail':'Choose a trusted contact and accessible travel or shelter options before conditions worsen.'})
 if eligible:
  actions.extend([{'id':'safety','title':'Keep clear of downed power lines','detail':'Treat fallen wires as energized. For immediate danger, contact emergency services.'},{'id':'charge','title':'Charge essential devices','detail':'Charge phones and available backup batteries; check the runtime of essential equipment.'},{'id':'light','title':'Keep lighting and updates ready','detail':'Have a flashlight and a way to receive official utility and weather updates.'}])
 if winter:actions.append({'id':'winter','title':'Allow for difficult winter access','detail':'Snow and ice damage are not fully modeled. Plan for travel restrictions and check official winter weather guidance.'})
 if eligible and result['ert'].get('high') is not None and result['ert']['high']>=24:actions.append({'id':'extended','title':'Plan for a longer interruption','detail':'Review food, warmth or cooling, and an alternative place to stay if your essential backup will not last.'})
 timing=['Before the storm when a declared need, severe-weather input, or planning-impact threshold triggers.','After a user-selected outage/update/restoration stage or a material scenario change.']
 escalation=['Immediate danger, fallen wires or fire: emergency services; keep clear of the hazard.','Powered medical or other essential needs exceeding available backup: contact the care team or facility operator and arrange an alternative power plan.','Unavailable model coverage or an uncertain restoration estimate: use official utility updates; no reliable ETA is inferred.']
 return actions,{'eligible':eligible,'subscribed':eligible and s['optIn'],'rule':'Demo policy: self-declared medical/accessibility/critical need, non-prestorm demo stage, gust >=58 mph, winter-hazard input, or expected circuit impact >=5%. Weather/impact triggers are scenario policies, not official AEP alert criteria.','channel':s['channel'],'timing':timing,'escalation':escalation,'delivery':'Local in-app scenario preview only; SMS/email not sent.','triggers':{'declaredNeeds':needs,'weather':weather_trigger,'circuitPlanningBand':planning_trigger,'stage':s['stage']!='pre'}}

def messages(s,customer_risk,impact,duration):
 if customer_risk and customer_risk['available']:risk=f"This home's modeled outage chance is {customer_risk['scenarioOutagePercentage']:.1f}% in this scenario."
 elif customer_risk:risk='A supported outage estimate is unavailable for this home.'
 elif impact.get('expectedAffectedPercentage') is not None:risk=f"The model estimates {impact['expectedAffectedPercentage']:.1f}% of customers affected on this circuit."
 else:risk='A supported outage estimate is unavailable here.'
 return {'pre':f'Engineering scenario: {risk} Check essential backup power and official weather/utility updates if conditions worsen. This is an uncalibrated model estimate.','outage':f'Demo outage scenario: assumed damage has a repair-work range of {duration}. Stay clear of fallen lines; this is not confirmed utility status.','update':f'Demo estimate update: the repair-work range is now {duration}. Crew availability, access and upstream repairs can change this range.','restored':'Demo restoration scenario: the modeled restoration stage is complete. Verify actual supply with the utility; no live restoration confirmation is connected.'}
