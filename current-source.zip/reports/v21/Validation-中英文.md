# Stormi v2.1 · 24 组实测与 v2 对比 / 24-scenario comparison

2026-10-25T02:15:29.716706+00:00 · macOS-14.8.9-arm64-arm-64bit · Python 3.12.14

## 结论 / Findings

| 实测项目 / Measure | v2 | v2.1 |
|---|---:|---:|
| 可输出数值影响比例 / Numeric impact cases | 11/24 | 24/24 |
| 有客户恢复阶段 / Customer-stage cases | 0 | 23 |
| 暖进程未命中缓存中位 / Warm uncached median | 11.6 ms | 93.0 ms |
| v2.1 P95 / P95 across case medians | — | 163.8 ms |
| v2.1 缓存中位 / Cached median | — | 7.1 ms |
| 真实停电/ERT 准确率 / Real accuracy | N/A | N/A |

**实际改善是功能覆盖、天气响应、稀有事件数值计算、维修模式与客户恢复排程，不是已经证明准确率更高。** 新版做了更多计算，比 v2 常常立即返回不可用的分支慢。默认单电路仍可交互使用。v2 的数量条件模拟与新版天气条件参考模型不是同一个统计估计量，因此不能把两者差值当作误差。

The measured improvements are usable output coverage, weather responsiveness, rare-event integration and dependency-aware restoration. Additional computation costs time. Different v2/v2.1 estimands must not be compared as predictive errors. No local outcome accuracy is claimed.

24 组包括 **8 组真实损坏背景回放 + 16 组人工天气/边界情景**。历史资产身份仍是未确认的空间候选，客户停电比例与小时级恢复真值缺失；所以真正的客户结果回测为 **0**。所有实际停电比例、实际 ERT、Brier/MAE/准确率都为 **N/A**。

There are eight real-report contextual replays and sixteen synthetic weather/edge cases on real GIS. There are zero genuine customer-outcome backtests. Missing reports are not negative labels; date subtraction is not hourly ERT truth.

每组同一输入/种子运行 3 次，中间清空结果内存缓存。表中是暖进程计算中位延迟，不含下载、Ollama、网页渲染、HTTP 传输和首次导入；第一次物理模型请求实测 1027.4 ms，服务初始化 2.29 s。场景期间共享只读输入索引，v2 快照未替换其原有逻辑。

Each same-input case runs three times with result memory caches cleared. Median warm compute timings exclude network download, Ollama, browser/HTTP overhead and first imports. Source v2 code hashes are preserved in the snapshot manifest.

## 24 组结果 / Measured results

`Impact %` = 模型内期望受影响比例；`Sensitivity` 是参数/角度/树木后果的工程敏感性包络，不是校准置信区间。`ERT` 为有损坏条件下工作完成范围，逐客户窗口与阶段见 JSON。所有行真实结果/误差 N/A，可信度均“转移参数、未本地验证”。

Impact is expected modeled customer fraction, not a validated complete-system forecast. Sensitivity is a scenario envelope, not demonstrated confidence coverage. ERT is outage-conditioned workload P10–P90, with separate per-customer windows. Ground truth/error are N/A in every row.

| ID | Date / circuit | Hazard | v2 impact % | New impact % | Sensitivity % | v2 work h | New ERT h | v2 ms | New ms | Stages | Evidence |
|---|---|---|---:|---:|---|---|---|---:|---:|---:|---|
| H01 | 2025-03-16 · C-083 | Real positive report, assumed asset identity | 0.30 | 0.30 | N/A–N/A | 10.61–10.61 | 7.98–14.87 | 31.1 | 81.0 | 1 | 历史背景 / no outcome truth |
| H02 | 2024-11-23 · C-010 | Real positive report, assumed asset identity | 1.95 | 1.95 | N/A–N/A | 2.73–2.73 | 2.00–3.47 | 34.2 | 87.5 | 1 | 历史背景 / no outcome truth |
| H03 | 2024-01-10 · C-005 | Real positive report, assumed asset identity | 0.19 | 0.19 | N/A–N/A | 2.73–2.73 | 1.90–3.92 | 43.1 | 99.4 | 1 | 历史背景 / no outcome truth |
| H04 | 2024-08-03 · C-002 | Real positive report, assumed asset identity | 0.31 | 0.31 | N/A–N/A | 2.73–2.73 | 1.75–3.30 | 88.4 | 164.6 | 1 | 历史背景 / no outcome truth |
| H05 | 2025-01-06 · C-035 | Real positive report, assumed asset identity | 5.98 | 5.98 | N/A–N/A | 2.73–2.73 | 2.29–4.54 | 35.8 | 92.4 | 1 | 历史背景 / no outcome truth |
| H06 | 2024-08-09 · C-084 | Real positive report, assumed asset identity | 0.24 | 0.24 | N/A–N/A | 10.61–10.61 | 6.90–15.55 | 35.8 | 88.5 | 1 | 历史背景 / no outcome truth |
| H07 | 2025-05-17 · C-015 | Real positive report, assumed asset identity | 0.55 | 0.55 | N/A–N/A | 2.73–2.73 | 2.15–4.21 | 22.8 | 66.8 | 1 | 历史背景 / no outcome truth |
| H08 | 2025-12-19 · C-010 | Real positive report, assumed asset identity | 0.93 | 0.93 | N/A–N/A | 2.73–2.73 | 2.00–3.77 | 37.0 | 89.0 | 1 | 历史背景 / no outcome truth |
| W01 | 2025-01-15 · C-052 | Rain and gusts | N/A | 0.31 | 0.01–0.51 | 31.88–31.88 | 4.61–4.61 | 2.8 | 24.2 | 1 | 工程情景 / uncalibrated |
| W02 | 2025-02-15 · C-020 | East wind | N/A | 2.03 | 0.01–2.91 | 31.88–31.88 | 2.87–20.20 | 11.5 | 94.2 | 2 | 工程情景 / uncalibrated |
| W03 | 2025-03-15 · C-041 | West wind | N/A | 1.87 | 0.01–2.91 | 31.88–31.88 | 5.77–50.35 | 10.8 | 89.8 | 2 | 工程情景 / uncalibrated |
| W04 | 2025-04-15 · C-062 | Snow and wind | N/A | 0.86 | 0.01–1.08 | 31.88–31.88 | 3.99–26.34 | 8.7 | 59.9 | 3 | 冬季部分 / partial winter |
| W05 | 2025-05-15 · C-003 | Freezing rain | 15.20 | 0.66 | 0.01–0.76 | 36.38–36.38 | 4.58–92.62 | 65.0 | 112.6 | 4 | 冬季部分 / partial winter |
| W06 | 2025-06-15 · C-017 | Severe gusts | N/A | 3.74 | 0.03–4.89 | 31.88–31.88 | 19.09–210.72 | 10.3 | 117.5 | 18 | 工程情景 / uncalibrated |
| W07 | 2025-07-15 · C-094 | Mountain access delay | 4.77 | 1.29 | 0.01–1.55 | 21.69–29.69 | 6.49–66.42 | 46.5 | 93.7 | 7 | 冬季部分 / partial winter |
| W08 | 2025-08-15 · C-002 | Crew shortage | 4.83 | 2.62 | 0.02–3.15 | 62.76–62.76 | 21.74–834.65 | 103.1 | 200.1 | 19 | 工程情景 / uncalibrated |
| W09 | 2025-09-15 · C-012 | Calm | N/A | 0.06 | 0.00–0.09 | 31.88–31.88 | 5.00–9.12 | 11.7 | 86.0 | 4 | 工程情景 / uncalibrated |
| W10 | 2025-10-15 · C-017 | Missing LiDAR | N/A | 1.48 | 0.01–1.78 | 31.88–31.88 | 4.22–54.02 | 10.1 | 100.3 | 4 | 工程情景 / uncalibrated |
| W11 | 2025-11-15 · C-012 | Conductor exposure | N/A | 1.13 | 0.01–1.69 | N/A–N/A | 5.18–54.44 | 9.7 | 113.7 | 9 | 冬季部分 / partial winter |
| W12 | 2025-12-15 · C-025 | Zero wind | N/A | 0.00 | 0.00–0.00 | 31.88–31.88 | 0.00–0.00 | 5.2 | 25.8 | 0 | 工程情景 / uncalibrated |
| E01 | 2025-09-27 · C-001 | Maximum API gust | N/A | 11.32 | 0.10–15.57 | 31.88–31.88 | 22.09–257.86 | 8.0 | 159.2 | 20 | 工程情景 / uncalibrated |
| E02 | 2025-09-27 · C-001 | Six-crew sensitivity | N/A | 2.68 | 0.03–3.54 | 16.44–16.44 | 6.34–47.77 | 7.5 | 98.2 | 9 | 工程情景 / uncalibrated |
| E03 | 2025-09-27 · C-001 | One-crew sensitivity | N/A | 2.68 | 0.03–3.54 | 62.76–62.76 | 10.53–202.67 | 7.8 | 104.3 | 6 | 工程情景 / uncalibrated |
| E04 | 2025-09-27 · C-001 | Unverified backup rejected | N/A | 1.34 | 0.01–1.74 | 31.88–31.88 | 4.76–47.85 | 8.3 | 89.8 | 3 | 工程情景 / uncalibrated |

## 位置、条件与失效原因 / Locations, conditions and reliability gaps

精确 GIS 私下参与算法；下表只给泛化坐标。P10–P90 只描述假设模型的抽样变化，不覆盖所有真实不确定性。未匹配的上游线路、未建模非木材、变电站、树种/健康与冻雨仍可能导致实际影响更大。

| ID | Lat, lng (generalized) | Gust mph / wind-from ° | Rain mm / snow cm | Coverage %* | Missing evidence / failure reason |
|---|---|---|---|---:|---|
| H01 | 37.24, -79.98 | 46.1 / 169 | 4.2 / 0.0 | N/A | No customer outcome truth / asset identity assumed |
| H02 | 37.17, -79.98 | 45.6 / 281 | 0.0 / 0.0 | N/A | No customer outcome truth / asset identity assumed |
| H03 | 37.22, -80.10 | 49.2 / 278 | 0.5 / 0.0 | N/A | No customer outcome truth / asset identity assumed |
| H04 | 37.26, -79.77 | 20.8 / 246 | 12.4 / 0.0 | N/A | No customer outcome truth / asset identity assumed |
| H05 | 37.29, -79.95 | 31.8 / 297 | 19.5 / 1.5 | N/A | No customer outcome truth / asset identity assumed |
| H06 | 37.24, -79.96 | 27.5 / 66 | 15.5 / 0.0 | N/A | No customer outcome truth / asset identity assumed |
| H07 | 37.28, -80.14 | 44.5 / 260 | 4.5 / 0.0 | N/A | No customer outcome truth / asset identity assumed |
| H08 | 37.18, -79.94 | 44.5 / 278 | 9.8 / 0.0 | N/A | No customer outcome truth / asset identity assumed |
| W01 | 37.27, -79.94 | 40.0 / 225 | 50.0 / 0.0 | 80.15 | Partial vegetation/asset coverage; transferred coefficients |
| W02 | 37.29, -80.05 | 70.0 / 90 | 3.0 / 0.0 | 100.00 | Partial vegetation/asset coverage; transferred coefficients |
| W03 | 37.28, -79.90 | 70.0 / 270 | 3.0 / 0.0 | 100.00 | Partial vegetation/asset coverage; transferred coefficients |
| W04 | 37.23, -80.01 | 55.0 / 315 | 0.0 / 30.0 | 100.00 | Ice/snow severity not quantified |
| W05 | 37.12, -80.17 | 35.0 / 45 | 20.0 / 0.0 | 100.00 | Ice/snow severity not quantified |
| W06 | 37.43, -80.08 | 95.0 / 180 | 65.0 / 0.0 | 99.94 | Partial vegetation/asset coverage; transferred coefficients |
| W07 | 37.43, -79.78 | 60.0 / 300 | 40.0 / 5.0 | 99.48 | Ice/snow severity not quantified |
| W08 | 37.25, -79.73 | 75.0 / 210 | 30.0 / 0.0 | 99.57 | Partial vegetation/asset coverage; transferred coefficients |
| W09 | 37.07, -79.82 | 8.0 / 0 | 0.0 / 0.0 | 92.75 | Partial vegetation/asset coverage; transferred coefficients |
| W10 | 37.38, -80.20 | 65.0 / 135 | 10.0 / 0.0 | 99.94 | Partial vegetation/asset coverage; transferred coefficients |
| W11 | 37.20, -79.85 | 60.0 / 180 | 25.0 / 20.0 | 92.75 | Ice/snow severity not quantified |
| W12 | 37.32, -79.98 | 0.0 / 15 | 0.0 / 0.0 | 100.00 | Partial vegetation/asset coverage; transferred coefficients |
| E01 | 37.22, -80.21 | 120.0 / 225 | 0.0 / 0.0 | 100.00 | Partial vegetation/asset coverage; transferred coefficients |
| E02 | 37.22, -80.21 | 75.0 / 225 | 0.0 / 0.0 | 100.00 | Partial vegetation/asset coverage; transferred coefficients |
| E03 | 37.22, -80.21 | 75.0 / 225 | 0.0 / 0.0 | 100.00 | Partial vegetation/asset coverage; transferred coefficients |
| E04 | 37.22, -80.21 | 55.0 / 225 | 0.0 / 0.0 | 100.00 | Partial vegetation/asset coverage; transferred coefficients |

*Coverage means customers with at least one modeled support on their original path, not complete modeling of all assets/hazards. 覆盖率不是全链路、全灾害完整性。

## 可靠性证据与基线 / Reliability evidence and baselines

- 已知故障影响保持与 v2 一致；回放组与独立原始路径扫描最大差仅浮点误差，非准确率证明。
- 发布参数、m/s 转换和零风条件截断有数值单元测试；共享位置标识和全部支撑组客户并集有一致性测试。
- 公共因子积分与独立解析结果/大样本模拟对照；测试确认小概率不会因为未抽中而被强行归零。
- 队伍资源、访问等待、依赖最晚完成、客户目标不重复计数、冰雪部分模型、无效备用容量和缓存复现均有测试。
- 已经跑过 XGBoost 训练/校准代码的合成检查；没有把合成结果当真实预测准确率，也没有用未报告资产制造健康标签。

Known-failure path logic is unchanged and independently checked. Published coefficients, units, zero-wind behavior, shared-ID associations, rare-event quadrature, resource feasibility and dependency-aware objectives are tested. Synthetic XGBoost plumbing remains separate from real validation. No higher predictive accuracy is inferred.

### 排程实际比较 / Actual scheduling comparison

对同一任务与客户依赖比较 FIFO 和新增排程。指标为带显式关键客户优先政策的客户恢复小时目标，不是实际 ERT 误差。仅选不劣于可行基线的解；大规模使用可行启发式，不谎称全局最优。

| ID | FIFO weighted customer-hours | Selected objective | Improvement | Interpretation |
|---|---:|---:|---:|---|
| H01 | 30.06 | 30.06 | 0.00 | Model objective only, not outcome accuracy |
| H02 | 55.66 | 55.66 | 0.00 | Model objective only, not outcome accuracy |
| H03 | 7.77 | 7.77 | 0.00 | Model objective only, not outcome accuracy |
| H04 | 24.97 | 24.97 | 0.00 | Model objective only, not outcome accuracy |
| H05 | 194.60 | 194.60 | 0.00 | Model objective only, not outcome accuracy |
| H06 | 30.33 | 30.33 | 0.00 | Model objective only, not outcome accuracy |
| H07 | 8.70 | 8.70 | 0.00 | Model objective only, not outcome accuracy |
| H08 | 29.70 | 29.70 | 0.00 | Model objective only, not outcome accuracy |
| W01 | 258.16 | 258.16 | 0.00 | Model objective only, not outcome accuracy |
| W02 | 72.08 | 72.08 | 0.00 | Model objective only, not outcome accuracy |
| W03 | 164.19 | 164.19 | 0.00 | Model objective only, not outcome accuracy |
| W04 | 162.82 | 162.82 | 0.00 | Model objective only, not outcome accuracy |
| W05 | 22.64 | 22.64 | 0.00 | Model objective only, not outcome accuracy |
| W06 | 1128.97 | 713.71 | 415.26 | Model objective only, not outcome accuracy |
| W07 | 238.54 | 231.48 | 7.06 | Model objective only, not outcome accuracy |
| W08 | 1577.27 | 1123.60 | 453.67 | Model objective only, not outcome accuracy |
| W09 | 158.12 | 158.12 | 0.00 | Model objective only, not outcome accuracy |
| W10 | 43.62 | 37.80 | 5.82 | Model objective only, not outcome accuracy |
| W11 | 157.40 | 153.00 | 4.40 | Model objective only, not outcome accuracy |
| W12 | N/A | 0.00 | N/A | Model objective only, not outcome accuracy |
| E01 | 1054.32 | 554.36 | 499.96 | Model objective only, not outcome accuracy |
| E02 | 526.65 | 514.50 | 12.15 | Model objective only, not outcome accuracy |
| E03 | 7552.46 | 7552.09 | 0.37 | Model objective only, not outcome accuracy |
| E04 | 25.83 | 25.83 | 0.00 | Model objective only, not outcome accuracy |

## 全区域运行 / Full supplied extract

另外实际计算全部 **117,642** 客户：影响行 117,642，ERT 行 117,642，70 mph、20 队伍、32 次故障模拟与 8 次恢复情景。首次全流程 **26.28 s**，缓存 **0.23 s**。这比单电路慢很多，是全量计算/逐客户输出的实际成本，不应在演示中当作 100 ms 全区实时预测宣传。结果仍是人工天气驱动的真实 GIS 工程情景，无真实结果验证。

Full-extract integration emits both output tables for all 117,642 customers. Measured cold and cache latencies above include this much larger calculation/output workload. Do not advertise circuit timings as full-region timings. No repair tasks are silently dropped; large task sets reuse feasible list scheduling.

## 仍无法解决的资料限制 / Remaining limitations

1. **本地准确率 / Local accuracy:** 没有完整设备×风暴暴露、已检查 0/1 标签和客户停电/复电时间；不能计算真实 Brier、MAE、校准率。
2. **模型迁移 / Transfer:** 原研究的木材、树种、土壤、季节及组件设计与 Roanoke 不同。未知年龄/腐朽、非参考等级/相数、导线规格须声明替代参考。10 m 是位置质量门槛，不是文献失效参数。
3. **连接完整性 / Connectivity:** 共享位置标识关联支撑组件，不是完整 pole-span/protection model；只用已有客户路径，未建模故障可能增加实际停电比例。非木材、未挂载杆线与上游变电站危害不完整。
4. **天气与植被 / Weather and vegetation:** 再分析/预报不是现场实测；完整风暴轨迹、局地阵风、树冠/健康/种类/完整覆盖、覆冰和积雪载荷、雨土耦合缺失。地形只作环境诊断，不能凭空当作已标定风速放大器。
5. **恢复 / Restoration:** CV、接触后果、安全等待及可用班组是工程情景；真实工班、材料、行车/封路与作业隔离未接入。单故障预案不是实际停电确认。
6. **关键设施与备用 / Critical facilities and backup:** 113 个生命支持标记可用，52 个设施供电关系未确认；不得用最近客户替代。缺少经核验的备用路径、电压、容量与保护计划时不自动送电。
7. **性能 / Performance:** 单电路已可交互；全区精细恢复明显更慢。大型结果使用有界私有压缩缓存，后续仍可优化静态空间特征和跨电路恢复并行。

## 文件 / Artifacts

`24-scenarios.csv` / `24-scenarios.json` 含 24 组输入、种子、完整逐客户结果、缺失说明与计时；`comparison-summary.json`、`tests-new.txt`（19 项）、`tests-all.txt`（59 项通过）、`tests-frontend.txt`、`full-scope-check.json` 提供证据。原 v2 报告保留，不覆盖历史测试记录。来源和命令见 `Explanation-中英文.md`。Source snapshot hashes and cached public-paper table hashes support reproduction.
