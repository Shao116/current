"""Generate short bilingual method and measured 24-scenario comparison reports."""
import json,csv,hashlib,datetime,html
from pathlib import Path
import markdown
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'reports/v21'
def f(x,n=2):return 'N/A' if x is None else f'{x:.{n}f}'
def main():
 s=json.loads((OUT/'comparison-summary.json').read_text());cases=json.loads((OUT/'24-scenarios.json').read_text());full=json.loads((OUT/'full-scope-check.json').read_text());audit=s['supportAssociationAudit'];now=datetime.datetime.now(datetime.timezone.utc).isoformat()
 method=f'''# Stormi v2.1 / current · 算法说明 / How the algorithms work

{now}

## 中文

**这是 v2 的增量改进，不是重建。** 原始 GIS、客户路径、AEP 工时、CP-SAT、SimPy、Ollama、地图和接口继续使用；v2 源码快照及 SHA256 保留用于对比。

**算法 1：天气 → 组件 → 客户。** 先用唯一共享 AEP 位置标识，把电杆支撑组件关联到已有路径中的安装设备，并进行 ≤10 m 的坐标质量检查；不添加猜测的电气边。识别出 **{audit['supportGroups']:,} 个木质支撑组件**，{audit['identifierMatchesQuarantinedOver10m']} 个设备匹配因位置不一致被隔离。一个组件出问题，影响的是其已有上游路径关联客户的并集。

使用 Hou & Muraleetharan (2023) 的 Table 4 杆线逻辑脆弱性系数，输入为电杆等级、相数、阵风 m/s 和线路迎风角；Table 2 的树高/风速系数只用于明确标注的 Bur-oak 夏季参考树木情景。没有本地相数、等级或方向时，使用声明的参考类别并给出敏感性范围。对零风时的逻辑回归截距进行“容量大于零”的条件截断，避免平静天气凭空出现背景损坏。

在给定天气下，名义情景按独立模式并集 `1−(1−P杆)(1−P线)(1−P接触)` 合成，区别于原论文 Eq.10 的 max；这是明确的工程改写，不是已拟合模式依赖。LiDAR 树高、距离及倒向用于支撑组件接触筛选。接触后造成中断是保守工程假设，不是已验证树木倒伏或实际导线断裂。树种/健康/树冠、完整覆盖及支撑以外线路路径未知，均保留为限制。默认每个选中电路使用同一输入阵风/风向，未模拟真实风暴路径。文献参考为 3 秒阵风；再分析/预报的阵风持续时长不保证完全匹配，不伪造换算。1 m 倒向接触走廊是可配置几何假设，不是论文回归参数。雨量、DEM 坡度/遮挡、历史损坏和前一年同月风向用于环境解释与缺失检查；没有可靠参数时不把它们随意乘成概率系数。历史记录只计场景日期之前的报告。

失效相关性用公共因子高斯 copula 表达，默认 0.35 是声明的场景假设。32 点 Gauss–Hermite 积分计算客户模型期望，避免稀有事件被有限抽样误报为零；Monte Carlo 给出模拟分位区间；均值数值误差使用保守 Hoeffding 界，避免零次抽中时错误宣称零误差。**输出是文献迁移的工程情景期望和敏感性范围，不是 AEP 本地校准概率，也不是对完整电网所有故障源的预测。** 冻雨/积雪只量化风与参考树木部分，冬季总风险明确不完整，不会显示成已验证的低风险。

**算法 2：损坏 → 维修任务 → 客户恢复。** 继续以 AEP 部件安装、拆除工时和 ILM=4.5 为主，不重复计入参考行车与准备。工作簿没有导线总维修时长时，可使用论文 §2.5 的 **4 小时转移参考均值**，与 AEP 工时严格区分，不再乘 ILM。维修模式可为电杆替换、导线或接触故障；明确的 `damageDetails/components` 优先于模型推断。电杆尺寸来自实际高度；未知变压器规格仍保留 50 kVA 默认假设。

使用均值保持的对数正态维修时长；默认 CV=0.5 是显式工程情景假设，未从 AEP 数据拟合。队伍、访问延迟、安全等待及关键客户影响排程。CP-SAT 的新增目标是客户所有故障依赖完成的最晚时间之和，避免把一客户重复算成多个已修任务；超大任务集继续使用可行优先队列，SimPy 验证资源占用。真实生命支持标记用于优先级；医院等设施只有调用方确认客户关联后才参与，附近客户不能冒充供电关联。

返回有损坏条件下工作完成的 P10–P90、每客户条件恢复窗口和真实排程产生的恢复阶段。样本太少时，补充明确标注的单组件故障预案窗口，而不是编造已发生停电。没有可核验备用拓扑/容量/保护时，不应用备用送电。所有时间都不是 AEP 官方 ERT。

## English

This is an incremental v2 extension. Existing GIS ingestion, source paths, workbook labor, CP-SAT, SimPy, indexes, caches, APIs and frontend remain in use. A frozen v2 snapshot supports same-input comparisons.

**Prediction:** unique shared AEP location identifiers, with a 10 m coordinate QA gate, associate {audit['supportGroups']:,} wooden support assemblies with already mapped devices. Existing customer paths determine downstream impact; no proximity-based electrical edge is created. Published wind fragility coefficients drive reference pole/wire failure scenarios. Tree height and downwind reach add a conservative contact contingency. Within-assembly mode union assumes conditional independence, an explicit adaptation differing from the paper’s Eq.10 max rule; local mode dependence is unverified. Unobserved classes/phases use declared reference alternatives; unknown species, health and complete span coverage remain limitations. A positive-capacity truncation makes the wind-induced increment zero at zero wind.

Common-factor Gaussian simulation represents assumed dependence. Conditional quadrature computes rare-event expected customer impact without Monte Carlo zero-count bias; Monte Carlo supplies simulated variability; conservative Hoeffding mean-error bounds avoid false zero-error claims when no failure is sampled. Outputs are **transferred, uncalibrated engineering estimates**, not locally validated probabilities. DEM, prior damage, rainfall and preceding-year seasonal direction provide context and identify missing effects; no arbitrary probability multiplier is added. Winter output explicitly excludes unquantified snow/ice damage. Hazards are uniform within the selected-circuit scenario; an observed storm track is not simulated. Published 3-second gust and modeled-weather gust definitions may differ. The 1 m contact corridor is a declared geometric assumption.

**Restoration:** actual workbook components and ILM anchor repair effort. A documented published conductor-duration reference fills the workbook gap without being called AEP data or receiving a second ILM. Mean-preserving lognormal duration variability, explicit crew/access/hold assumptions, latest failed dependencies and critical-customer policy drive the existing scheduler/simulator. Customer-completion objectives replace the v2 task-only proxy when dependencies are known. Large jobs fall back to feasible list scheduling, not silent task truncation. Outputs include outage-conditioned P10–P90 workload ranges, customer windows and staged restoration. Rare-event contingency windows are labeled separately. Unknown critical-facility supply links and unverified alternate feeds are never invented.

## 实际使用的来源 / Sources actually used

1. [Hou & Muraleetharan (2023)](https://doi.org/10.1007/s13753-023-00478-x), Table 2/4 and §2.5: traceable tree/wind reference coefficients, connectivity consequence and conductor repair-duration reference. Original study population: Oklahoma Southern Pine/Bur oak, not calibrated Roanoke assets. Exact numerical registry: `algorithms/literature.json`; downloaded primary-source tables retained privately with hashes.
2. [Arif et al. (2018)](https://arxiv.org/html/1806.11076): stochastic crew/restoration formulation and lognormal duration model family. Its numerical test-case distribution is not misrepresented as AEP repair data; CV=0.5 here is an explicit assumption.
3. [Oracle Storm Management engineering documentation](https://docs.oracle.com/en/industries/energy-water/network-management-system/2602x/nms-users-guide/NMS/07_Storm_Management.08.8.html): separation of assessment, repair, backlog and available crew resources; no Oracle numeric parameters transferred.
4. [UConn/Eversource outage research](https://www.eversource.uconn.edu/grid-resilience/predicting-outages/): weather/vegetation/geographic context and limitations of empirical storm prediction; no claimed transfer of its trained model or accuracy.
5. [FEMA distribution wind/ice loading checklist](https://www.fema.gov/sites/default/files/documents/AppendicesA-D.pdf): missing ice, conductor and bracing variables are substantive gaps, not interchangeable with snowfall/rain totals.

数值误差界 / Numerical error reference: [Hoeffding (1963)](https://doi.org/10.1080/01621459.1963.10500830), bounded independent-trial concentration; no outage parameters transferred.

## 接口与复现 / API and reproduction

`POST /api/evaluate` and `/api/impact` keep their existing envelopes. Add `predictionMode: "weather"` for weather-driven reference scenarios; explicit legacy quantities/failed nodes keep conditional-damage semantics. Frontend explicitly uses weather mode. `risk.score` and unconditional calibrated probability remain null; `impact.expectedAffectedPercentage`, `modelSensitivityRangePercentage`, `riskAssessment`, `ert.perCustomer` and `ert.stages` carry useful results. `repairCV`, `hazardHoldHours`, `damageDetails`, confirmed `facilityLinks` and existing crew/access bounds are explicit inputs.

Run from `outage-concierge`:

```sh
.venv/bin/python -m unittest discover -v
.venv/bin/python algorithms/benchmark_v21.py
.venv/bin/python algorithms/full_scope_v21.py
.venv/bin/python algorithms/report_v21.py
```

新大结果使用源码/源缓存签名和有界私有压缩磁盘缓存。Large full-extract results use a bounded private compressed cache keyed by source-code/data-cache signatures. No new paid service or package is required. Read `Validation-中英文.md` for measured comparisons and remaining limitations.
'''
 (OUT/'Explanation-中英文.md').write_text(method)
 report=f'''# Stormi v2.1 · 24 组实测与 v2 对比 / 24-scenario comparison

{now} · {s['platform']} · Python {s['python']}

## 结论 / Findings

| 实测项目 / Measure | v2 | v2.1 |
|---|---:|---:|
| 可输出数值影响比例 / Numeric impact cases | {s['v2NumericImpactCases']}/{s['cases']} | {s['v21NumericImpactCases']}/{s['cases']} |
| 有客户恢复阶段 / Customer-stage cases | 0 | {s['newCustomerStageCases']} |
| 暖进程未命中缓存中位 / Warm uncached median | {s['v2MedianMs']:.1f} ms | {s['v21MedianMs']:.1f} ms |
| v2.1 P95 / P95 across case medians | — | {s['v21P95Ms']:.1f} ms |
| v2.1 缓存中位 / Cached median | — | {s['v21MedianCacheMs']:.1f} ms |
| 真实停电/ERT 准确率 / Real accuracy | N/A | N/A |

**实际改善是功能覆盖、天气响应、稀有事件数值计算、维修模式与客户恢复排程，不是已经证明准确率更高。** 新版做了更多计算，比 v2 常常立即返回不可用的分支慢。默认单电路仍可交互使用。v2 的数量条件模拟与新版天气条件参考模型不是同一个统计估计量，因此不能把两者差值当作误差。

The measured improvements are usable output coverage, weather responsiveness, rare-event integration and dependency-aware restoration. Additional computation costs time. Different v2/v2.1 estimands must not be compared as predictive errors. No local outcome accuracy is claimed.

24 组包括 **8 组真实损坏背景回放 + 16 组人工天气/边界情景**。历史资产身份仍是未确认的空间候选，客户停电比例与小时级恢复真值缺失；所以真正的客户结果回测为 **0**。所有实际停电比例、实际 ERT、Brier/MAE/准确率都为 **N/A**。

There are eight real-report contextual replays and sixteen synthetic weather/edge cases on real GIS. There are zero genuine customer-outcome backtests. Missing reports are not negative labels; date subtraction is not hourly ERT truth.

每组同一输入/种子运行 3 次，中间清空结果内存缓存。表中是暖进程计算中位延迟，不含下载、Ollama、网页渲染、HTTP 传输和首次导入；第一次物理模型请求实测 {s['firstPhysicsRequestMs']:.1f} ms，服务初始化 {s['coldServiceStartupSeconds']:.2f} s。场景期间共享只读输入索引，v2 快照未替换其原有逻辑。

Each same-input case runs three times with result memory caches cleared. Median warm compute timings exclude network download, Ollama, browser/HTTP overhead and first imports. Source v2 code hashes are preserved in the snapshot manifest.

## 24 组结果 / Measured results

`Impact %` = 模型内期望受影响比例；`Sensitivity` 是参数/角度/树木后果的工程敏感性包络，不是校准置信区间。`ERT` 为有损坏条件下工作完成范围，逐客户窗口与阶段见 JSON。所有行真实结果/误差 N/A，可信度均“转移参数、未本地验证”。

Impact is expected modeled customer fraction, not a validated complete-system forecast. Sensitivity is a scenario envelope, not demonstrated confidence coverage. ERT is outage-conditioned workload P10–P90, with separate per-customer windows. Ground truth/error are N/A in every row.

| ID | Date / circuit | Hazard | v2 impact % | New impact % | Sensitivity % | v2 work h | New ERT h | v2 ms | New ms | Stages | Evidence |
|---|---|---|---:|---:|---|---|---|---:|---:|---:|---|
'''
 for c in cases:
  r=c['metrics'];mark='历史背景 / no outcome truth' if r['case'].startswith('H') else '冬季部分 / partial winter' if r['winterPartial'] else '工程情景 / uncalibrated'
  report+=f"| {r['case']} | {r['date']} · {r['circuit']} | {r['name']} | {f(r['v2ImpactPct'])} | {f(r['v21ImpactPct'])} | {f(r['modelLowPct'])}–{f(r['modelHighPct'])} | {f(r['v2ERTLowH'])}–{f(r['v2ERTHighH'])} | {f(r['v21ERTLowH'])}–{f(r['v21ERTHighH'])} | {f(r['v2MedianMs'],1)} | {f(r['v21MedianMs'],1)} | {r['restorationStages']} | {mark} |\n"
 report+='''
## 位置、条件与失效原因 / Locations, conditions and reliability gaps

精确 GIS 私下参与算法；下表只给泛化坐标。P10–P90 只描述假设模型的抽样变化，不覆盖所有真实不确定性。未匹配的上游线路、未建模非木材、变电站、树种/健康与冻雨仍可能导致实际影响更大。

| ID | Lat, lng (generalized) | Gust mph / wind-from ° | Rain mm / snow cm | Coverage %* | Missing evidence / failure reason |
|---|---|---|---|---:|---|
'''
 for c in cases:
  r=c['metrics'];w=c['result']['physicsFeatures']['weather'];gap='No customer outcome truth / asset identity assumed' if r['case'].startswith('H') else 'Ice/snow severity not quantified' if r['winterPartial'] else 'Partial vegetation/asset coverage; transferred coefficients'
  report+=f"| {r['case']} | {r['lat']:.2f}, {r['lng']:.2f} | {f(r['gustMph'],1)} / {f(r['direction'],0)} | {f(w.get('rainMm'),1)} / {f(w.get('snowfallCm'),1)} | {f(r['coveragePct'])} | {gap} |\n"
 report+='''
*Coverage means customers with at least one modeled support on their original path, not complete modeling of all assets/hazards. 覆盖率不是全链路、全灾害完整性。

## 可靠性证据与基线 / Reliability evidence and baselines

- 已知故障影响保持与 v2 一致；回放组与独立原始路径扫描最大差仅浮点误差，非准确率证明。
- 发布参数、m/s 转换和零风条件截断有数值单元测试；共享位置标识和全部支撑组客户并集有一致性测试。
- 公共因子积分与独立解析结果/大样本模拟对照；测试确认小概率不会因为未抽中而被强行归零。
- 队伍资源、访问等待、依赖最晚完成、客户目标不重复计数、冰雪部分模型、无效备用容量和缓存复现均有测试。
- 已经跑过 XGBoost 训练/校准代码的合成检查；没有把合成结果当真实预测准确率，也没有用未报告资产制造健康标签。

Known-failure path logic is unchanged and independently checked. Published coefficients, units, zero-wind behavior, shared-ID associations, rare-event quadrature, resource feasibility and dependency-aware objectives are tested. Synthetic XGBoost plumbing remains separate from real validation. No higher predictive accuracy is inferred.

### 排程实际比较 / Actual scheduling comparison

对同一任务与客户依赖比较 FIFO 和新增排程。指标为带显式关键客户优先政策的客户恢复小时目标，不是实际 ERT 误差。仅选不劣于可行基线的解；大规模使用可行启发式，不谎称全局最优。

| ID | FIFO weighted customer-hours | Selected objective | Improvement | Interpretation |
|---|---:|---:|---:|---|
'''
 for c in cases:
  r=c['metrics'];report+=f"| {r['case']} | {f(r['fifoCustomerObjective'])} | {f(r['optimizedCustomerObjective'])} | {f(r['customerObjectiveImprovement'])} | Model objective only, not outcome accuracy |\n"
 report+=f'''
## 全区域运行 / Full supplied extract

另外实际计算全部 **{full['scopeCustomers']:,}** 客户：影响行 {full['impactCustomerRows']:,}，ERT 行 {full['ertCustomerRows']:,}，70 mph、20 队伍、32 次故障模拟与 {full['sampledRepairScenarios']} 次恢复情景。首次全流程 **{full['secondsIncludingColdInitialization']:.2f} s**，缓存 **{full.get('cachedSeconds',float('nan')):.2f} s**。这比单电路慢很多，是全量计算/逐客户输出的实际成本，不应在演示中当作 100 ms 全区实时预测宣传。结果仍是人工天气驱动的真实 GIS 工程情景，无真实结果验证。

Full-extract integration emits both output tables for all 117,642 customers. Measured cold and cache latencies above include this much larger calculation/output workload. Do not advertise circuit timings as full-region timings. No repair tasks are silently dropped; large task sets reuse feasible list scheduling.

## 仍无法解决的资料限制 / Remaining limitations

1. **本地准确率 / Local accuracy:** 没有完整设备×风暴暴露、已检查 0/1 标签和客户停电/复电时间；不能计算真实 Brier、MAE、校准率。
2. **模型迁移 / Transfer:** 原研究的木材、树种、土壤、季节及组件设计与 Roanoke 不同。未知年龄/腐朽、非参考等级/相数、导线规格须声明替代参考。10 m 是位置质量门槛，不是文献失效参数。
3. **连接完整性 / Connectivity:** 共享位置标识关联支撑组件，不是完整 pole-span/protection model；只用已有客户路径，未建模故障可能增加实际停电比例。非木材、未挂载杆线与上游变电站危害不完整。
4. **天气与植被 / Weather and vegetation:** 再分析/预报不是现场实测；完整风暴轨迹、局地阵风、树冠/健康/种类/完整覆盖、覆冰和积雪载荷、雨土耦合缺失。地形只作环境诊断，不能凭空当作已标定风速放大器。
5. **恢复 / Restoration:** CV、接触后果、安全等待及可用班组是工程情景；真实工班、材料、行车/封路与作业隔离未接入。单故障预案不是实际停电确认。
6. **关键设施与备用 / Critical facilities and backup:** 113 个生命支持标记可用，52 个设施供电关系未确认；不得用最近客户替代。缺少经核验的备用路径、电压、容量与保护计划时不自动送电。
7. **性能 / Performance:** 单电路已可交互；全区精细恢复明显更慢。大型结果使用有界私有压缩缓存，后续仍可优化静态空间特征和跨电路恢复并行。

## 文件 / Artifacts

`24-scenarios.csv` / `24-scenarios.json` 含 24 组输入、种子、完整逐客户结果、缺失说明与计时；`comparison-summary.json`、`tests-new.txt`（19 项）、`tests-all.txt`（59 项通过）、`tests-frontend.txt`、`full-scope-check.json` 提供证据。原 v2 报告保留，不覆盖历史测试记录。来源和命令见 `Explanation-中英文.md`。Source snapshot hashes and cached public-paper table hashes support reproduction.
'''
 (OUT/'Validation-中英文.md').write_text(report)
 css='body{margin:0;background:#f5f2e7;color:#203d2d;font:16px/1.7 system-ui}main{max-width:1220px;margin:24px auto;padding:30px;background:#fffef8;border-radius:16px}h1,h2,h3{color:#285e3d;line-height:1.3}h2{margin-top:32px}table{display:block;overflow:auto;border-collapse:collapse;font-size:13px;margin:18px 0}th,td{border:1px solid #d4dfcf;padding:8px 10px;vertical-align:top}th{background:#e7eedc}tr:nth-child(even){background:#faf8ed}a{color:#286640}pre{background:#eaf0e2;padding:16px;overflow:auto}code{font-size:14px}@media(max-width:700px){main{margin:0;padding:16px}}'
 for source,target in [('Explanation-中英文.md','v21-explanation.html'),('Validation-中英文.md','v21-validation.html')]:
  body=markdown.markdown((OUT/source).read_text(),extensions=['tables','fenced_code']);(ROOT/'reports'/target).write_text(f'<!doctype html><html lang="zh"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Stormi v2.1 · {html.escape(source)}</title><style>{css}</style><main><nav><a href="/">← current</a> · <a href="/reports/v21-explanation.html">Method 中英文</a> · <a href="/reports/v21-validation.html">24 scenarios 中英文</a></nav>{body}</main></html>')
 (ROOT/'reports/v21-scenarios.csv').write_bytes((OUT/'24-scenarios.csv').read_bytes());(ROOT/'reports/v21-summary.json').write_bytes((OUT/'comparison-summary.json').read_bytes())
 provenance={'generatedUTC':now,'primaryTables':[{'url':f'https://link.springer.com/article/10.1007/s13753-023-00478-x/tables/{i}','sha256':hashlib.sha256((ROOT/f'private/algorithm/research/hou2023-table{i}.html').read_bytes()).hexdigest()} for i in [2,4,5]],'parameters':str(ROOT/'algorithms/literature.json'),'statement':'Only Tables 2/4 coefficients and section 2.5 conductor reference are used. Table 5 was inspected but not used: conductor diameter/span/tree impact load are not verified.'}
 (OUT/'research-provenance.json').write_text(json.dumps(provenance,indent=2));print('Generated bilingual v2.1 explanation, validation report and served HTML/CSV.')
if __name__=='__main__':main()
