"""Local API regression: source points, precise pins, and real crew comparison."""
import json,urllib.request,unittest,pickle
from pyproj import Transformer
BASE='http://127.0.0.1:8765'
def get(path):return json.load(urllib.request.urlopen(BASE+path))
def run(s):
 req=urllib.request.Request(BASE+'/api/evaluate',data=json.dumps({'scenario':s}).encode(),headers={'Content-Type':'application/json'})
 return json.load(urllib.request.urlopen(req))
class MapTests(unittest.TestCase):
 def test_source_points_and_selection(self):
  rows=get('/api/customer-points?west=-79.96&south=37.26&east=-79.92&north=37.29')['features'];self.assertGreater(len(rows),1000)
  with open('private/algorithm/network.pkl','rb') as f:network=pickle.load(f)
  p=rows[0];i=int(p['properties']['id'].split('-')[1])-1;expected=Transformer.from_crs(26917,4326,always_xy=True).transform(*network['customers'][i]['xy'])
  self.assertAlmostEqual(p['geometry']['coordinates'][0],expected[0],places=9);self.assertAlmostEqual(p['geometry']['coordinates'][1],expected[1],places=9)
  r=run({'contextType':'premise','contextId':p['properties']['id'],'predictionMode':'conditional'})
  self.assertAlmostEqual(r['location']['lat'],expected[1],places=9);self.assertAlmostEqual(r['location']['lng'],expected[0],places=9)
 def test_arbitrary_point_and_crews(self):
  s={'contextType':'map','lat':37.274321,'lng':-79.939876,'predictionMode':'conditional','asset':'pole','quantity':3,'upstream':1,'crews':1}
  one=run(s);six=run(dict(s,crews=6))
  self.assertEqual(one['location']['lat'],s['lat']);self.assertEqual(one['location']['lng'],s['lng']);self.assertLess(six['restoration']['high'],one['restoration']['high'])
 def test_invalid_viewport(self):
  with self.assertRaises(urllib.error.HTTPError) as e:get('/api/customer-points?west=nan&south=37&east=-79&north=38')
  self.assertEqual(e.exception.code,400)
if __name__=='__main__':unittest.main()
