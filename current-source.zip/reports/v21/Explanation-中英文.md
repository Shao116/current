# Stormi v2.1 / current · 算法说明 / How the algorithms work

2026-10-25T02:15:29.716706+00:00

## 中文

**这是 v2 的增量改进，不是重建。** 原始 GIS、客户路径、AEP 工时、CP-SAT、SimPy、Ollama、地图和接口继续使用；v2 源码快照及 SHA256 保留用于对比。

**算法 1：天气 → 组件 → 客户。** 先用唯一共享 AEP 位置标识，把电杆支撑组件关联到已有路径中的安装设备，并进行 ≤10 m 的坐标质量检查；不添加猜测的电气边。识别出 **25,118 个木质支撑组件**，90 个设备匹配因位置不一致被隔离。一个组件出问题，影响的是其已有上游路径关联客户的并集。

使用 Hou & Muraleetharan (2023) 的 Table 4 杆线逻辑脆弱性系数，输入为电杆等级、相数、阵风 m/s 和线路迎风角；Table 2 的树高/风速系数只用于明确标注的 Bur-oak 夏季参考树木情景。没有本地相数、等级或方向时，使用声明的参考类别并给出敏感性范围。对零风时的逻辑回归截距进行“容量大于零”的条件截断，避免平静天气凭空出现背景损坏。

在给定天气下，名义情景按独立模式并集 `1−(1−P杆)(1−P线)(1−P接触)` 合成，区别于原论文 Eq.10 的 max；这是明确的工程改写，不是已拟合模式依赖。LiDAR 树高、距离及倒向用于支撑组件接触筛选。接触后造成中断是保守工程假设，不是已验证树木倒伏或实际导线断裂。树种/健康/树冠、完整覆盖及支撑以外线路路径未知，均保留为限制。默认每个选中电路使用同一输入阵风/风向，未模拟真实风暴路径。文献参考为 3 秒阵风；再分析/预报的阵风持续时长不保证完全匹配，不伪造换算。1 m 倒向接触走廊是可配置几何假设，不是论文回归参数。雨量、DEM 坡度/遮挡、历史损坏和前一年同月风向用于环境解释与缺失检查；没有可靠参数时不把它们随意乘成概率系数。历史记录只计场景日期之前的报告。

失效相关性用公共因子高斯 copula 表达，默认 0.35 是声明的场景假设。32 点 Gauss–Hermite 积分计算客户模型期望，避免稀有事件被有限抽样误报为零；Monte Carlo 给出模拟分位区间；均值数值误差使用保守 Hoeffding 界，避免零次抽中时错误宣称零误差。**输出是文献迁移的工程情景期望和敏感性范围，不是 AEP 本地校准概率，也不是对完整电网所有故障源的预测。** 冻雨/积雪只量化风与参考树木部分，冬季总风险明确不完整，不会显示成已验证的低风险。

**算法 2：损坏 → 维修任务 → 客户恢复。** 继续以 AEP 部件安装、拆除工时和 ILM=4.5 为主，不重复计入参考行车与准备。工作簿没有导线总维修时长时，可使用论文 §2.5 的 **4 小时转移参考均值**，与 AEP 工时严格区分，不再乘 ILM。维修模式可为电杆替换、导线或接触故障；明确的 `damageDetails/components` 优先于模型推断。电杆尺寸来自实际高度；未知变压器规格仍保留 50 kVA 默认假设。

使用均值保持的对数正态维修时长；默认 CV=0.5 是显式工程情景假设，未从 AEP 数据拟合。队伍、访问延迟、安全等待及关键客户影响排程。CP-SAT 的新增目标是客户所有故障依赖完成的最晚时间之和，避免把一客户重复算成多个已修任务；超大任务集继续使用可行优先队列，SimPy 验证资源占用。真实生命支持标记用于优先级；医院等设施只有调用方确认客户关联后才参与，附近客户不能冒充供电关联。

返回有损坏条件下工作完成的 P10–P90、每客户条件恢复窗口和真实排程产生的恢复阶段。样本太少时，补充明确标注的单组件故障预案窗口，而不是编造已发生停电。没有可核验备用拓扑/容量/保护时，不应用备用送电。所有时间都不是 AEP 官方 ERT。

## English

This is an incremental v2 extension. Existing GIS ingestion, source paths, workbook labor, CP-SAT, SimPy, indexes, caches, APIs and frontend remain in use. A frozen v2 snapshot supports same-input comparisons.

**Prediction:** unique shared AEP location identifiers, with a 10 m coordinate QA gate, associate 25,118 wooden support assemblies with already mapped devices. Existing customer paths determine downstream impact; no proximity-based electrical edge is created. Published wind fragility coefficients drive reference pole/wire failure scenarios. Tree height and downwind reach add a conservative contact contingency. Within-assembly mode union assumes conditional independence, an explicit adaptation differing from the paper’s Eq.10 max rule; local mode dependence is unverified. Unobserved classes/phases use declared reference alternatives; unknown species, health and complete span coverage remain limitations. A positive-capacity truncation makes the wind-induced increment zero at zero wind.

Common-factor Gaussian simulation represents assumed dependence. Conditional quadrature computes rare-event expected customer impact without Monte Carlo zero-count bias; Monte Carlo supplies simulated variability; conservative Hoeffding mean-error bounds avoid false zero-error claims when no failure is sampled. Outputs are **transferred, uncalibrated engineering estimates**, not locally validated probabilities. DEM, prior damage, rainfall and preceding-year seasonal direction provide context and identify missing effects; no arbitrary probability multiplier is added. Winter output explicitly excludes unquantified snow/ice damage. Hazards are uniform within the selected-circuit scenario; an observed storm track is not simulated. Published 3-second gust and modeled-weather gust definitions may differ. The 1 m contact corridor is a declared geometric assumption.

**Restoration:** actual workbook components and ILM anchor repair effort. A documented published conductor-duration reference fills the workbook gap without being called AEP data or receiving a second ILM. Mean-preserving lognormal duration variability, explicit crew/access/hold assumptions, latest failed dependencies and critical-customer policy drive the existing scheduler/simulator. Customer-completion objectives replace the v2 task-only proxy when dependencies are known. Large jobs fall back to feasible list scheduling, not silent task truncation. Outputs include outage-conditioned P10–P90 workload ranges, customer windows and staged restoration. Rare-event contingency windows are labeled separately. Unknown critical-facility supply links and unverified alternate feeds are never invented.

## 实际使用的来源 / Sources actually used

1. [Hou & Muraleetharan (2023)](https://doi.org/10.1007/s13753-023-00478-x), Table 2/4 and §2.5: traceable tree/wind reference coefficients, connectivity consequence and conductor repair-duration reference. Original study population: Oklahoma Southern Pine/Bur oak, not calibrated Roanoke assets. Exact numerical registry: `algorithms/literature.json`; downloaded primary-source tables retained privately with hashes.
2. [Arif et al. (2018)](https://arxiv.org/html/1806.11076): stochastic crew/restoration formulation and lognormal duration model family. Its numerical test-case distribution is not misrepresented as AEP repair data; CV=0.5 here is an explicit assumption.
3. [Oracle Storm Management engineering documentation](https://docs.oracle.com/en/industries/energy-water/network-management-system/2602x/nms-users-guide/NMS/07_Storm_Management.08.8.html): separation of assessment, repair, backlog and available crew resources; no Oracle numeric parameters transferred.
4. [UConn/Eversource outage research](https://www.eversource.uconn.edu/grid-resilience/predicting-outages/): weather/vegetation/geographic context and limitations of empirical storm prediction; no claimed transfer of its trained model or accuracy.
5. [FEMA distribution wind/ice loading checklist](https://www.fema.gov/sites/default/files/documents/AppendicesA-D.pdf): missing ice, conductor and bracing variables are substantive gaps, not interchangeable with snowfall/rain totals.

数值误差界 / Numerical error reference: [Hoeffding (1963)](https://doi.org/10.1080/01621459.1963.10500830), bounded independent-trial concentration; no outage parameters transferred.

## 接口与复现 / API and reproduction

`POST /api/evaluate` and `/api/impact` keep their existing envelopes. Add `predictionMode: "weather"` for weather-driven reference scenarios; explicit legacy quantities/failed nodes keep conditional-damage semantics. Frontend explicitly uses weather mode. `risk.score` and unconditional calibrated probability remain null; `impact.expectedAffectedPercentage`, `modelSensitivityRangePercentage`, `riskAssessment`, `ert.perCustomer` and `ert.stages` carry useful results. `repairCV`, `hazardHoldHours`, `damageDetails`, confirmed `facilityLinks` and existing crew/access bounds are explicit inputs.

Run from `outage-concierge`:

```sh
.venv/bin/python -m unittest discover -v
.venv/bin/python algorithms/benchmark_v21.py
.venv/bin/python algorithms/full_scope_v21.py
.venv/bin/python algorithms/report_v21.py
```

新大结果使用源码/源缓存签名和有界私有压缩磁盘缓存。Large full-extract results use a bounded private compressed cache keyed by source-code/data-cache signatures. No new paid service or package is required. Read `Validation-中英文.md` for measured comparisons and remaining limitations.
