"""Read all five supplied workbook sheets into an auditable runtime catalog.
Run with bundled Python; does not modify the organizer workbook.
"""
from pathlib import Path
import hashlib,json
import openpyxl
ROOT=Path(__file__).resolve().parents[1]
def build(source):
 w=openpyxl.load_workbook(source,read_only=True,data_only=True);out={'source':'Install_Labor_HackOHIO.xlsx','sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'sheets':{},'connectors':{},'material':{},'poleSizes':{},'transformerKVA':{},'adders':{},'descriptions':{}}
 for s in w:
  out['sheets'][s.title]={'rows':s.max_row,'columns':s.max_column,'nonemptyRows':sum(any(x is not None for x in r) for r in s.values)}
 for i,r in enumerate(w['CNC'].values,1):
  if isinstance(r[0],str) and r[0].startswith('CNC-'):out['connectors'][r[0]]={'install':r[1],'remove':r[2],'sheet':'CNC','row':i}
 s=w['Labor time material related']
 for key,row in {'crossarm':3,'bracket':7,'anchor':35,'lead':40,'ground':45,'guy':50,'deadend':55,'insulator':60,'pin':65,'recloser':70,'secondary_attachment':75,'service':80,'switch':85,'fuse':90}.items():
  vals=[x.value for x in s[row]];off=1 if key=='anchor' else 0;out['material'][key]={'install':vals[off],'remove':vals[off+1],'sheet':s.title,'row':row}
 for row in [12,13,14]:
  vals=[x.value for x in s[row]];out['poleSizes'][vals[0].lower()]={'install':vals[2],'remove':vals[3],'heightRange':vals[1],'sheet':s.title,'row':row}
 for row in range(19,31):
  vals=[x.value for x in s[row]];out['transformerKVA'][str(vals[0])]={'install':vals[2],'remove':vals[3],'sheet':s.title,'row':row}
 for i,r in enumerate(w['Labor only work'].values,1):
  if i>1 and r[0]:out['adders'][r[0]]={'hours':r[3],'unit':r[4] or 'per declared occurrence','sheet':'Labor only work','row':i}
 out['indirectMultiplier']=w['Indirect Labor Multiplier']['B1'].value
 for i,r in enumerate(w['CU Group descriptions'].values,1):
  if i>1 and r[0]:out['descriptions'][r[0]]={'description':r[1],'sheet':'CU Group descriptions','row':i}
 return out
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('source',type=Path);args=p.parse_args();out=build(args.source);(ROOT/'algorithms/labor_catalog.json').write_text(json.dumps(out,indent=2));print({k:len(out[k]) for k in ['connectors','material','poleSizes','transformerKVA','adders','descriptions']})
