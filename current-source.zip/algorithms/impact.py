"""Exact source-path impact and reproducible correlated Monte Carlo.
Unconditional probabilities require a separately validated/calibrated model.
"""
import numpy as np
from scipy.special import ndtri
from scipy.stats import norm

def exact_customers(nodes,failures,total):
 mask=np.zeros(total,dtype=bool)
 for n in failures:
  if n not in nodes:raise ValueError('Unknown failure node')
  mask[nodes[n]['customers']]=True
 return mask

def simulate(nodes,customers,scope,candidates,count=1,trials=256,seed=20261024,correlation=.35,marginals=None,known_failures=None):
 scope=np.asarray(scope,dtype=np.int32);N=len(scope)
 if not N:raise ValueError('No customers in scope')
 rng=np.random.default_rng(seed);mapping=np.full(len(customers),-1,dtype=np.int32);mapping[scope]=np.arange(N)
 reach=[]
 for n in candidates:
  loc=mapping[nodes[n]['customers']];reach.append(loc[loc>=0])
 overlap_index=[[] for _ in range(N)]
 for j,ix in enumerate(reach):
  for i in ix:overlap_index[int(i)].append(j)
 overlap_cache={}
 probabilities=np.zeros(N);fractions=[];failure_draws=[]
 # Gaussian common storm factor imposes dependence; rho is a sensitivity assumption, not fitted.
 if marginals is not None:
  p=np.asarray(marginals,dtype=float)
  if len(p)!=len(candidates) or np.any(~np.isfinite(p)) or np.any((p<0)|(p>1)):raise ValueError('Invalid calibrated marginals')
  threshold=ndtri(p)
 for _ in range(trials):
  if known_failures is not None:chosen=[candidates.index(n) for n in known_failures if n in candidates]
  elif marginals is not None:
   z=np.sqrt(correlation)*rng.normal()+np.sqrt(1-correlation)*rng.normal(size=len(candidates));chosen=np.flatnonzero(z<threshold).tolist()
  elif count and candidates:
   # Conditional on a caller-assumed failure count. Correlated mode chooses connected
   # customer-overlap blocks, with a uniform seed; no weather-weighted fake probabilities.
   k=min(count,len(candidates));first=int(rng.integers(len(candidates)));chosen=[first]
   if k>1:
    remaining=np.array([j for j in range(len(candidates)) if j!=first]);same=overlap_cache.get(first)
    if same is None:
     shared=set(j for i in reach[first] for j in overlap_index[int(i)]);shared.discard(first);same=sorted(shared);overlap_cache[first]=same
    if rng.random()<correlation and same:
     add=rng.choice(same,min(k-1,len(same)),replace=False).tolist();chosen+=add
    remaining=np.array([j for j in remaining if j not in chosen]);chosen+=rng.choice(remaining,k-len(chosen),replace=False).tolist()
  else:chosen=[]
  mask=np.zeros(N,dtype=bool)
  for j in chosen:mask[reach[j]]=True
  probabilities+=mask;fractions.append(float(mask.mean()));failure_draws.append([candidates[j] for j in chosen])
 probabilities/=trials;a=np.array(fractions);se=float(a.std(ddof=1)/np.sqrt(trials)) if trials>1 else 0
 missing=sum(not customers[i]['path'] for i in scope)/N
 return {'basis':'conditional_known_failures' if known_failures is not None else 'calibrated_marginals' if marginals is not None else 'conditional_assumed_failure_count','unconditionalProbabilityAvailable':marginals is not None,'expectedAffectedPercentage':float(a.mean()*100),'scenarioInterval95Percentage':(np.quantile(a,[.025,.975])*100).tolist(),'monteCarloMeanCI95Percentage':[max(0,float(a.mean()-1.96*se))*100,min(1,float(a.mean()+1.96*se))*100],'unmappedCustomerFraction':missing,'missingTopologyUpperBoundPercentage':min(100,float(a.mean()*100+missing*100)),'trials':trials,'seed':seed,'correlationAssumption':correlation,'effectiveFailureCount':len(set(known_failures)) if known_failures is not None else min(count,len(candidates)) if marginals is None else None,'failureCountAssumption':count if marginals is None and known_failures is None else None,'scopeCustomers':N,'candidateDevices':len(candidates),'intervalMeaning':'Simulation distribution and Monte Carlo numerical-error CI; neither is calibrated real-world forecast coverage.','perCustomer':[{'id':customers[i]['id'],'outageProbability':float(probabilities[j]) if marginals is not None and customers[i]['path'] else None,'conditionalOutageProbability':float(probabilities[j]) if customers[i]['path'] else None,'monteCarloProbabilitySE':float(np.sqrt(probabilities[j]*(1-probabilities[j])/trials)) if customers[i]['path'] and known_failures is None else 0. if customers[i]['path'] else None,'topologyAvailable':bool(customers[i]['path'])} for j,i in enumerate(scope)],'_draws':failure_draws}


def scenario_impact(nodes,customers,scope,candidates,marginals,trials=128,seed=20261024,correlation=.35):
 """Sparse source-path exposure + Gaussian common-factor model.
 Gauss-Hermite conditional integration avoids zero estimates for rare failures;
 MC supplies the distribution of impact, not an alleged calibration interval.
 """
 from scipy.sparse import csr_matrix
 from numpy.polynomial.hermite import hermgauss
 scope=np.asarray(scope,dtype=np.int32);mapping=np.full(len(customers),-1,dtype=np.int32);mapping[scope]=np.arange(len(scope));rows=[];cols=[]
 for j,n in enumerate(candidates):
  loc=mapping[nodes[n]['customers']];loc=loc[loc>=0];rows.extend(loc.tolist());cols.extend([j]*len(loc))
 exposure=csr_matrix((np.ones(len(rows)),(rows,cols)),shape=(len(scope),len(candidates)));p=np.array(marginals,float)
 if np.any(~np.isfinite(p)) or np.any((p<0)|(p>1)):raise ValueError('Invalid scenario marginals')
 if not 0<=correlation<1:raise ValueError('Invalid correlation')
 def expected(ps):
  threshold=ndtri(np.array(ps,float));z,w=hermgauss(32);cp=norm.cdf((threshold[:,None]-np.sqrt(correlation)*z[None,:]*np.sqrt(2))/np.sqrt(1-correlation));cp=np.clip(cp,0,1-1e-15)
  survival_log=exposure @ np.log1p(-cp);return (-np.expm1(survival_log)) @ (w/np.sqrt(np.pi))
 analytic=expected(p);rng=np.random.default_rng(seed);z=np.sqrt(correlation)*rng.normal(size=(trials,1))+np.sqrt(1-correlation)*rng.normal(size=(trials,len(p)));fail=z<ndtri(p)[None,:]
 affected=(exposure @ fail.T.astype(float))>0;fraction=affected.mean(axis=0);samples=fraction*100;mc_se=float(samples.std(ddof=1)/np.sqrt(trials));hoeffding_radius=100*np.sqrt(np.log(40)/(2*trials));covered=np.asarray(exposure.sum(axis=1)).ravel()>0
 result={'status':'transferred_physics_scenario','basis':'published_reference_fragility_NOT_local_calibration','outageProbability':None,'unconditionalProbabilityAvailable':False,'expectedAffectedPercentage':float(analytic.mean()*100),'scenarioInterval95Percentage':np.quantile(samples,[.025,.975]).tolist(),'monteCarloMeanCI95Percentage':[max(0,float(samples.mean()-hoeffding_radius)),min(100,float(samples.mean()+hoeffding_radius))],'monteCarloMeanCIMethod':'Conservative Hoeffding bound for independent bounded simulation trials; not real forecast calibration','monteCarloMeanNumericalSEPercentage':mc_se,'monteCarloMeanAffectedPercentage':float(samples.mean()),'expectedValueMethod':'32-point Gauss-Hermite integration of common-factor copula; avoids rare-event zero-count estimates','scopeCustomers':len(scope),'candidateDevices':len(candidates),'modeledCustomerCoveragePercentage':float(covered.mean()*100),'unmappedCustomerFraction':sum(not customers[i]['path'] for i in scope)/len(scope),'unmodeledCustomerPercentage':float((~covered).mean()*100),'trials':trials,'seed':seed,'correlationAssumption':correlation,'probabilityNoModeledDamageMC':float((~fail.any(axis=1)).mean()),'intervalMeaning':'Simulated reference-model variability; NOT locally validated probability or calibrated forecast coverage. Separate model sensitivity envelope is provided.','perCustomer':[{'id':customers[i]['id'],'outageProbability':None,'conditionalOutageProbability':float(analytic[j]) if customers[i]['path'] and covered[j] else None,'scenarioOutageProbability':float(analytic[j]) if customers[i]['path'] and covered[j] else None,'topologyAvailable':bool(customers[i]['path']),'modeledSupportCoverage':bool(covered[j])} for j,i in enumerate(scope)],'_draws':[[candidates[j] for j in np.flatnonzero(row)] for row in fail],'_expected':expected,'_coverage':covered}
 return result
