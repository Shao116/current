import unittest,json,math,tempfile
from pathlib import Path
import numpy as np
from engine import evaluate
from algorithms.service import get_service
from algorithms.impact import exact_customers,simulate
from algorithms.restoration import schedule,labor,customer_restore,feasible_backup
from algorithms.model import train,FEATURES
ROOT=Path(__file__).parent
D=json.loads((ROOT/'private/data.json').read_text());D['premiseIndex']={p['id']:p for p in D['premises']};D['circuitIndex']={p['id']:p for p in D['circuits']}
class AlgorithmTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.svc=get_service();cls.net=cls.svc.d
 def test_inventory_and_geography(self):
  a=self.net['audit'];self.assertEqual(a['customers'],117642);self.assertEqual(sum(a['assetKinds'].values()),333010);self.assertEqual(a['matchedCustomers'],117595);self.assertEqual(a['criticalCodes']['LS Life Support'],113);self.assertIn('Virginia',a['region'])
 def test_full_source_path_reference(self):
  # Full reverse index equivalence, not model accuracy.
  forward={n:set() for n in self.net['nodes']}
  for i,p in enumerate(self.net['customers']):
   for n in p['path']:forward[n].add(i)
  for n,v in self.net['nodes'].items():self.assertEqual(forward[n],set(v['customers']))
 def test_known_failure_exact_graph(self):
  nodes=self.net['nodes'];n=next(iter(nodes));mask=exact_customers(nodes,[n],117642);ref=[i for i,p in enumerate(self.net['customers']) if n in p['path']];self.assertEqual(set(np.flatnonzero(mask)),set(ref))
 def test_monte_carlo_analytic_independent_oracle(self):
  ns={'a':{'customers':np.array([0,1])},'b':{'customers':np.array([1,2])}};cs=[{'id':str(i),'path':['x']} for i in range(3)]
  r=simulate(ns,cs,[0,1,2],['a','b'],trials=20000,correlation=0,marginals=[.2,.3]);observed=[p['outageProbability'] for p in r['perCustomer']]
  np.testing.assert_allclose(observed,[.2,.44,.3],atol=.015)
 def test_correlated_failures_preserve_marginals(self):
  ns={'a':{'customers':np.array([0])},'b':{'customers':np.array([1])}};cs=[{'id':str(i),'path':['x']} for i in range(2)];r=simulate(ns,cs,[0,1],['a','b'],trials=20000,correlation=.7,marginals=[.3,.3]);np.testing.assert_allclose([p['outageProbability'] for p in r['perCustomer']],[.3,.3],atol=.015)
 def test_missing_labels_abstain(self):
  r=evaluate({'asset':'transformer'},D);self.assertIsNone(r['risk']['score']);self.assertIsNone(r['impact']['outageProbability']);self.assertTrue(all(p['outageProbability'] is None for p in r['impact']['perCustomer']));json.dumps(r,allow_nan=False)
 def test_reproducibility_and_cache(self):
  s={'asset':'transformer','seed':77};a=evaluate(s,D);b=evaluate(s,D);self.assertEqual(a['impact'],b['impact']);self.assertTrue(b['performance']['cacheHit'])
 def test_no_pole_nearest_customer_inference(self):
  r=evaluate({'asset':'pole','quantity':3},D);self.assertEqual(r['impact']['status'],'unavailable');self.assertIsNone(r['impact']['expectedAffectedPercentage'])
 def test_tree_outside_coverage_is_missing_not_zero(self):
  f=self.svc.features.at(-80.2,37.4,{'gustMph':50,'windDirection':90});self.assertFalse(f['lidar']['withinSourceBounds']);self.assertIsNone(f['lidar']['pointsWithin100m']);self.assertTrue(f['terrain']['available'])
 def test_real_terrain_and_weather(self):
  f=self.svc.features;w=f.historical('2024-09-27',-79.94,37.27);self.assertIsNotNone(w);self.assertIn('reanalysis',w['source']);self.assertIsNone(w['iceAccretionMm']);t=f.at(-79.94,37.27,w)['terrain'];self.assertGreater(t['elevationM'],100);self.assertEqual(len(t['horizonAnglesDeg']),8)
 def test_wind_pressure_physics(self):
  f=self.svc.features;a=f.at(-79.94,37.27,{'gustMph':20,'windDirection':90});b=f.at(-79.94,37.27,{'gustMph':40,'windDirection':270});self.assertAlmostEqual(b['dynamicPressurePa']/a['dynamicPressurePa'],4)
 def test_no_wire_rate_fabricated(self):self.assertFalse(labor('wire')['available']);self.assertAlmostEqual(labor('wire',rate_override=2)['taskHours'],9)
 def test_workbook_and_components(self):
  a=labor('pole',components=[{'kind':'crossarm','quantity':2},{'kind':'insulator','quantity':3}]);expected=(2*(.3741146496815283+.21217834394904417)+3*(.04923076923076923+.0393846153846154))*4.5;self.assertAlmostEqual(a['taskHours'],expected)
 def test_crew_constraints_and_release(self):
  tasks=[{'hours':2,'weight':i+1,'release':1} for i in range(5)];s=schedule(tasks,2)
  for c in range(2):
   events=sorted([e for e in s['events'] if e['crew']==c],key=lambda e:e['start']);self.assertTrue(all(e['start']>=1 for e in events));self.assertTrue(all(a['end']<=b['start'] for a,b in zip(events,events[1:])))
  self.assertLessEqual(s['objective'],s['fifoObjective'])
 def test_more_crews_and_zero_tasks(self):
  ts=[{'hours':3} for _ in range(6)];self.assertGreater(schedule(ts,1)['makespan'],schedule(ts,3)['makespan']);self.assertEqual(schedule([],3)['makespan'],0)
 def test_staged_upstream_energization(self):
  c=[{'path':['up','down']},{'path':['up']},{'path':[]}];self.assertEqual(customer_restore(c,[0,1,2],['up','down'],{'up':2,'down':5}),[5,2,None])
 def test_backup_requires_engineering_constraints(self):
  self.assertFalse(feasible_backup({})['feasible']);a=dict.fromkeys(['verifiedTopology','voltageCompatible','protectionApproved','isolationVerified','radialityVerified'],True);a.update(spareCapacityKW=100,loadKW=50);self.assertTrue(feasible_backup(a)['feasible']);a['loadKW']=101;self.assertFalse(feasible_backup(a)['feasible'])
 def test_label_gate_rejects_damage_only(self):
  with self.assertRaises(ValueError):train([{'label':1}]*200,tempfile.mkdtemp())
 def test_xgboost_training_calibration_plumbing_synthetic_only(self):
  rng=np.random.default_rng(914);rows=[]
  for event in range(12):
   for j in range(100):
    x=rng.normal(size=len(FEATURES));label=int((x[0]*x[1]>0) != (rng.random()<.06))
    rows.append({'asset_id':f'A{j}','event_id':f'E{event:02}','timestamp':f'2025-{event+1:02}-01T00:00:00Z','observed':True,'label':label,'features':x.tolist()})
  with tempfile.TemporaryDirectory() as td:
   report=train(rows,td);self.assertIn('xgboostCalibrated',report['metrics']);self.assertTrue((Path(td)/'candidate.joblib').exists())
   (ROOT/'reports/xgboost-synthetic-plumbing.json').write_text(json.dumps({'notice':'SYNTHETIC pipeline verification only. Not AEP validation, not outage prediction accuracy. Never deployed.','result':report},indent=2))
 def test_invalid_inputs(self):
  for s in [{'crews':0},{'wind':float('nan')},{'crewSize':0},{'asset':'unknown'},{'correlation':1},{'failedNodes':['bad']},{'trials':2},{'repairHours':-1}]:
   with self.subTest(s=s),self.assertRaises((ValueError,TypeError)):evaluate(s,D)
 def test_legacy_interface_keys(self):
  r=evaluate({},D)
  for k in ['scenario','location','risk','restoration','alerts','actions','messages','message','limitations','confirmedFacts','assumptions']:self.assertIn(k,r)
  for k in ['low','high','rate','formula','note','firstRestoration']:self.assertIn(k,r['restoration'])
 def test_unknown_topology_not_safe(self):
  p=next(p for p in D['premises'] if not p['path']);r=evaluate({'contextType':'premise','contextId':p['id'],'asset':'transformer'},D);row=next(p for p in r['impact']['perCustomer'] if p['id']==r['location']['label']);self.assertIsNone(row['conditionalOutageProbability'])
if __name__=='__main__':unittest.main(verbosity=2)
