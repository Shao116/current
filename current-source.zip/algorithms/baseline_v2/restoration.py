"""Workbook task accounting, resource-feasible scheduling and staged energization."""
import math
import numpy as np
import simpy
from ortools.sat.python import cp_model
RATES={'pole':(2.50295207667732,.9274888178913726),'transformer':(1.2445957446808502,.890893617021277),'fuse':(.256,.128),'switch':(1.7579459459459466,1.0097297297297296),'recloser':(.5726238532110097,.5253577981651364),'crossarm':(.3741146496815283,.21217834394904417),'bracket':(.6172394366197178,.25442253521126756),'anchor':(.3972,.1188),'lead':(.6501904761904762,.20609523809523825),'ground':(.5319565217391303,.15296086956521746),'guy':(.36703448275862083,.16220689655172402),'deadend':(.10760784313725497,.064),'insulator':(.04923076923076923,.0393846153846154),'pin':(.06606451612903229,.042322580645161305),'secondary_attachment':(.23258536585365866,.12682926829268298),'service':(1.692981132075472,.48)}

def labor(kind,size='medium',components=None,access=False,rate_override=None,labor_basis='crew_hours',crew_size=1):
 if components is None:components=[{'kind':kind,'quantity':1}]
 direct=0;details=[]
 for c in components:
  if not isinstance(c,dict) or not isinstance(c.get('kind'),str):raise ValueError('Each component must have a string kind')
  k=c['kind'];q=c.get('quantity',1)
  if not isinstance(q,(int,float)) or not math.isfinite(q) or q<0:raise ValueError('Invalid component quantity')
  rate=RATES.get(k)
  if k=='pole':rate={'small':(1.9416103896103902,.763636363636363),'medium':RATES['pole'],'large':(3.368367816091952,1.153195402298852)}[size]
  if rate is None:
   if rate_override is None:return {'available':False,'reason':f'No verified workbook rate for {k}. Supply an explicit engineering rate; no invented wire rate.'}
   if not math.isfinite(float(rate_override)) or float(rate_override)<=0:raise ValueError('repairHours must be positive and finite')
   rate=(float(rate_override),0)
  v=sum(rate)*q;direct+=v;details.append({'component':k,'quantity':q,'installHours':rate[0],'removeHours':rate[1],'hours':v})
 if access:direct+=.5
 if labor_basis not in ['crew_hours','person_hours']:raise ValueError('Unknown labor basis')
 divisor=crew_size if labor_basis=='person_hours' else 1
 return {'available':True,'directHours':direct,'taskHours':direct*4.5/divisor,'components':details,'indirectMultiplier':4.5,'basis':labor_basis,'crewSize':crew_size,'note':'Workbook ILM 4.5 already includes drive, safety and setup. No duplicate default travel allowance. Crew-hour interpretation is an explicit assumption pending AEP confirmation. Default transformer rate is the 50 kVA workbook row; actual kVA is not established. Pole size is caller-selected, not automatically inferred damage.'}

def schedule(tasks,crews,policy='optimized',time_limit=.2):
 if not tasks:return {'makespan':0.,'objective':0.,'events':[],'solverStatus':'EMPTY'}
 scale=100;dur=[max(1,math.ceil(t['hours']*scale)) for t in tasks];release=[math.ceil(t.get('release',0)*scale) for t in tasks];horizon=max(release)+sum(dur)
 def greedy(order):
  available=[0]*crews;events=[]
  for j in order:
   c=min(range(crews),key=lambda i:(max(available[i],release[j]),i));start=max(available[c],release[j]);end=start+dur[j];available[c]=end;events.append({'task':j,'crew':c,'start':start/scale,'end':end/scale})
  return events
 def objective(events):return sum(e['end']*tasks[e['task']].get('weight',1) for e in events)
 fifo=greedy(range(len(tasks)));priority=greedy(sorted(range(len(tasks)),key=lambda j:-(tasks[j].get('weight',1)/dur[j])))
 best=min([fifo,priority],key=objective);status='GREEDY';bound=None
 if policy=='optimized' and len(tasks)<=40:
  m=cp_model.CpModel();starts=[];ends=[];intervals=[]
  for j in range(len(tasks)):
   st=m.new_int_var(release[j],horizon,f's{j}');en=m.new_int_var(0,horizon,f'e{j}');it=m.new_interval_var(st,dur[j],en,f'i{j}');starts.append(st);ends.append(en);intervals.append(it)
  m.add_cumulative(intervals,[1]*len(tasks),crews);m.minimize(sum(ends[j]*max(1,int(tasks[j].get('weight',1))) for j in range(len(tasks))))
  for e in best:m.add_hint(starts[e['task']],round(e['start']*scale));m.add_hint(ends[e['task']],round(e['end']*scale))
  solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=time_limit;solver.parameters.num_search_workers=1;solver.parameters.random_seed=20261024
  st=solver.solve(m);status=solver.status_name(st)
  if st in [cp_model.OPTIMAL,cp_model.FEASIBLE]:
   candidate=[];avail=[0]*crews
   for j in sorted(range(len(tasks)),key=lambda j:solver.value(starts[j])):
    start=solver.value(starts[j])/scale;end=solver.value(ends[j])/scale;c=next(i for i in range(crews) if avail[i]<=start+1e-8);avail[c]=end;candidate.append({'task':j,'crew':c,'start':start,'end':end})
   if objective(candidate)<=objective(best)+1e-8:best=candidate
   bound=solver.best_objective_bound/scale
 # Replay the proposed schedule using discrete events and check crew feasibility.
 env=simpy.Environment();resources=[simpy.Resource(env,capacity=1) for _ in range(crews)];events=[]
 def work(e):
  yield env.timeout(e['start'])
  with resources[e['crew']].request() as req:
   yield req
   if abs(env.now-e['start'])>1e-7:raise RuntimeError('Resource conflict')
   yield env.timeout(e['end']-e['start']);events.append(dict(e))
 for e in best:env.process(work(e))
 env.run()
 return {'makespan':max(e['end'] for e in best),'objective':objective(best),'fifoObjective':objective(fifo),'improvementAgainstFIFO':objective(fifo)-objective(best),'objectiveMeaning':'Weighted task-completion hours, a surrogate for customer restoration; weights are explicit priority policy.','events':sorted(events,key=lambda e:e['end']),'solverStatus':status,'bestBound':bound,'timeResolutionHours':.01}

def customer_restore(customers,scope,failures,finish):
 failed=set(failures);out=[]
 for i in scope:
  p=customers[i];dep=failed.intersection(p['path']);out.append(None if not p['path'] else max([finish[n] for n in dep],default=0))
 return out

def feasible_backup(tie):
 required=['verifiedTopology','voltageCompatible','protectionApproved','isolationVerified','radialityVerified']
 if not all(tie.get(k) is True for k in required):return {'feasible':False,'reason':'Topology, voltage, protection, isolation and radiality must all be verified.'}
 if tie.get('spareCapacityKW',-1)<tie.get('loadKW',float('inf')):return {'feasible':False,'reason':'Insufficient verified spare capacity.'}
 return {'feasible':True,'reason':'Caller-provided engineering constraints passed; field authorization still required.'}
