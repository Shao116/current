"""Build privacy-filtered challenge data. Raw attributes never enter the web root."""
from pathlib import Path
from zipfile import ZipFile
import struct, json, math, collections, hashlib
import openpyxl
ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'materials/aep_challenge_hack26-main'

def dbf(z,name):
 b=z.read(name+'.dbf'); n=struct.unpack_from('<I',b,4)[0]; h,r=struct.unpack_from('<HH',b,8); fields=[]; off=1
 for i in range((h-33)//32):
  d=b[32+i*32:64+i*32]; fields.append((d[:11].split(b'\0')[0].decode(),off,d[16])); off+=d[16]
 for i in range(n):
  row=b[h+i*r:h+(i+1)*r]
  yield {k:row[o:o+l].decode('utf-8',errors='replace').strip() for k,o,l in fields}
def shapes(z,name):
 b=z.read(name+'.shp');o=100
 while o<len(b):
  _,ln=struct.unpack_from('>2i',b,o);o+=8;d=b[o:o+ln*2];o+=ln*2;t=struct.unpack_from('<i',d)[0]
  if t in (1,11,21):yield list(struct.unpack_from('<2d',d,4))
  elif t in (3,13,23):
   parts,points=struct.unpack_from('<2i',d,36);start=44+4*parts
   xy=[list(struct.unpack_from('<2d',d,start+16*j)) for j in range(points)]
   yield xy
  else:yield None

def cell(x,y):return f'{round(x,2):.2f},{round(y,2):.2f}'
def anon(kind,value):return kind+'-'+hashlib.sha256(value.encode()).hexdigest()[:8].upper()
def main():
 (ROOT/'private').mkdir(exist_ok=True)
 premises=[]; lookup={}; circuits={};damage=[];grid={};inventory=[];lines=[];device_counts=collections.Counter()
 with ZipFile(SRC/'data/raw/Data1.zip') as z:
  for i,(r,xy) in enumerate(zip(dbf(z,'Customer_Clip'),shapes(z,'Customer_Clip'))):
   c=r['circuit_id'];circuits.setdefault(c,{'id':f'C-{len(circuits)+1:03}','count':0,'sx':0,'sy':0})
   ci=circuits[c];ci['count']+=1;ci['sx']+=xy[0];ci['sy']+=xy[1]
   p={'id':f'P-{i+1:06}','circuit':ci['id'],'lng':round(xy[0],2),'lat':round(xy[1],2),'path':[]}
   premises.append(p);lookup[r['premise_nu']]=p
   k=cell(*xy);g=grid.setdefault(k,{'lng':round(xy[0],2),'lat':round(xy[1],2),'customers':0,'damage':0,'types':{}});g['customers']+=1
  for i,(r,xy) in enumerate(zip(dbf(z,'arcos_prod_damage_09_28_Clip'),shapes(z,'arcos_prod_damage_09_28_Clip'))):
   d={'id':f'D-{i+1:04}','lng':round(xy[0],2),'lat':round(xy[1],2),'asset':r['Asset_Type'] or 'Unspecified','work':r['Inform_Wor'],'access':r['Access_Iss']=='Yes','reported':r['Report_Tim'],'repaired':r['Repaired_D']}
   damage.append(d); k=cell(*xy);g=grid.setdefault(k,{'lng':d['lng'],'lat':d['lat'],'customers':0,'damage':0,'types':{}});g['damage']+=1;g['types'][d['work']]=g['types'].get(d['work'],0)+1
  # Aggregate to a coarse grid: never publish exact infrastructure geometry.
  edges=collections.Counter()
  for xy in shapes(z,'Primary_ExportFeatures'):
   if not xy:continue
   a=(round(xy[0][0],2),round(xy[0][1],2));b=(round(xy[-1][0],2),round(xy[-1][1],2))
   if a!=b:edges[tuple(sorted([a,b]))]+=1
  lines=[{'points':[[a[1],a[0]],[b[1],b[0]]],'count':n} for (a,b),n in edges.items()]
 for fn in ['Data1.zip','Data2.zip']:
  with ZipFile(SRC/'data/raw'/fn) as z:
   for n in z.namelist():
    if n.endswith('.dbf'):
     h=z.read(n)[:32];inventory.append({'layer':n[:-4],'records':struct.unpack_from('<I',h,4)[0],'archive':fn})
 paths=0;matched=0;unique=set();lengths=collections.Counter()
 with ZipFile(SRC/'data/raw/matched_upstream.zip') as z:
  for line in z.read('matched_upstream.txt').decode().splitlines():
   paths+=1;parts=line.split('\t');p=lookup.get(parts[0]);path=[]
   for item in parts[1:]:
    bits=item.split('*')
    if len(bits)<3:continue
    node={'id':anon('N',item),'type':bits[2]};path.append(node);unique.add(node['id']);device_counts[node['type']]+=1
   lengths[len(path)]+=1
   if p is not None:p['path']=path;matched+=1
 w=openpyxl.load_workbook(SRC/'data/Install_Labor_HackOHIO.xlsx',data_only=True)
 labor={s.title:[[v for v in row] for row in s.iter_rows(values_only=True) if any(v is not None for v in row)] for s in w}
 data={'premises':premises,'damage':damage,'grid':list(grid.values()),'lines':lines,'circuits':[{'id':v['id'],'count':v['count'],'lng':round(v['sx']/v['count'],2),'lat':round(v['sy']/v['count'],2)} for v in circuits.values()],'inventory':inventory,'labor':labor,'stats':{'premises':len(premises),'damage':len(damage),'circuits':len(circuits),'topologyRows':paths,'matchedPremises':matched,'upstreamNodes':len(unique),'pathLengths':dict(lengths),'assetCategories':dict(collections.Counter(d['asset'] for d in damage)),'workCategories':dict(collections.Counter(d['work'] for d in damage))}}
 (ROOT/'private/data.json').write_text(json.dumps(data,separators=(',',':')))
 print(json.dumps({'stats':data['stats'],'gridCells':len(grid),'generalizedConnections':len(lines)},indent=2))
if __name__=='__main__':main()
