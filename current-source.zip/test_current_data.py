"""Integrity checks for new public nature, weather and generalized asset inputs."""
import unittest,json,urllib.request,gzip
from pathlib import Path
ROOT=Path(__file__).resolve().parent
class CurrentDataTests(unittest.TestCase):
 def test_lidar_count_ids_and_region(self):
  d=json.loads((ROOT/'public/data/lidar-trees.geojson').read_text());fs=d['features'];self.assertEqual(len(fs),36778);self.assertEqual(len({f['properties']['id'] for f in fs}),36778)
  for f in fs:
   x,y=f['geometry']['coordinates'][:2];self.assertTrue(-80.289<=x<=-79.603 and 36.975<=y<=37.510)
 def test_other_nature_counts_and_attribution(self):
  for name,count in [('woodland',798),('canopy',95)]:
   d=json.loads((ROOT/f'public/data/{name}.geojson').read_text());self.assertEqual(len(d['features']),count);self.assertTrue(all(f['properties'].get('source') for f in d['features']))
 def test_gzip_matches_current_source(self):
  for f in (ROOT/'public/data').glob('*.geojson'):
   with gzip.open(str(f)+'.gz','rb') as z:self.assertEqual(z.read(),f.read_bytes())
 def test_nearby_output_is_generalized_and_filtered(self):
  with urllib.request.urlopen('http://127.0.0.1:8765/api/nearby?lat=37.27&lng=-79.94') as r:d=json.load(r)
  self.assertTrue(0<len(d['features'])<=1600);self.assertGreater(d['vegetation'].get('lidar-trees',0),0)
  for f in d['features']:
   self.assertEqual(set(f['properties']),{'id','count','material','height'})
   for v in f['geometry']['coordinates']:self.assertAlmostEqual(v,round(v,3))
 def test_weather_has_usable_horizon(self):
  with urllib.request.urlopen('http://127.0.0.1:8765/api/weather',timeout=25) as r:d=json.load(r)
  self.assertEqual(d['source'],'Open-Meteo');self.assertGreaterEqual(len(d['points']),1)
  for p in d['points']:
   self.assertGreaterEqual(len(p['hourly']['time']),72);self.assertEqual(p['current_units']['temperature_2m'],'°F');self.assertEqual(p['current_units']['wind_speed_10m'],'mp/h')
if __name__=='__main__':unittest.main(verbosity=2)
