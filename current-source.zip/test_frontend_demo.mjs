import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const src=fs.readFileSync(new URL('./public/experience.js',import.meta.url),'utf8');
const ctx=vm.createContext({});vm.runInContext(src,ctx);
const days=JSON.parse(vm.runInContext('JSON.stringify(DEMO_DAYS)',ctx));
assert.equal(days.length,4);assert.equal(new Set(days.map(d=>d.date)).size,4);
assert.deepEqual(days.map(d=>d.type),['thunder','rain','wind','snow']);
assert.equal(days[0].date,'2012-06-29');assert.equal(days[0].gust,81);assert.equal(days[3].snowfallCm,38.1);
const impacts=[];
for(const d of days){
 assert.match(d.source,/^https:\/\/(www\.weather\.gov|www\.nhc\.noaa\.gov|www\.nesdis\.noaa\.gov)/);assert.match(d.weatherUrl,/archive-api\.open-meteo/);
 const scenario={predictionMode:'weather',date:d.date,windDirection:d.direction,rainMm:d.rainMm,snowfallCm:d.snowfallCm,contextType:'premise',contextId:'P-020015',wind:d.gust,asset:'pole',crews:3,accessDelay:1};
 const response=await fetch('http://127.0.0.1:8765/api/evaluate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({scenario})});assert.ok(response.ok);const r=await response.json();impacts.push(r.impact.expectedAffectedPercentage);assert.equal(r.model.status,'transferred_physics_active');assert.equal(r.risk.score,null);assert.ok(r.restoration.high>=r.restoration.low);assert.ok(r.impact.expectedAffectedPercentage>=0);if(d.type==='snow')assert.equal(r.riskAssessment.status,'partial_winter_hazard');console.log(`${d.title} ${d.date}: ${r.impact.expectedAffectedPercentage.toFixed(3)}% circuit impact, ${r.restoration.low}–${r.restoration.high} hrs; outcome truth absent`);
}
assert.ok(impacts[0]>impacts[3],'Derecho wind component must exceed low-wind snow component; snow total remains unquantified');
vm.runInContext('experience.demo=true;experience.day=3',ctx);const snow=vm.runInContext('demoForecastPoint()',ctx);assert.equal(snow.current.weather_code,75);assert.equal(snow.hourly.time.length,24);assert.ok(snow.current.temperature_2m<32);
console.log('Four documented event inputs, source attribution, snow partial-model warning and weather/API integration verified.');
