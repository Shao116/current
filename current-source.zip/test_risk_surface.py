import unittest,base64,io
import numpy as np
from PIL import Image
from algorithms.risk_surface import expected_customers,raster,band
from algorithms.impact import scenario_impact
class SurfaceTests(unittest.TestCase):
 def test_surface_uses_same_topology_marginals(self):
  nodes={'a':{'customers':np.array([0,1])},'b':{'customers':np.array([1,2])}};customers=[{'id':str(i),'path':['n']} for i in range(4)]
  values,known=expected_customers(nodes,customers,['a','b'],np.array([.2,.3]),.35);r=scenario_impact(nodes,customers,list(range(4)),['a','b'],[.2,.3],trials=32,correlation=.35)
  self.assertAlmostEqual(values.mean()*100,r['expectedAffectedPercentage'],places=10);self.assertFalse(known[3]);self.assertEqual(values[3],0)
 def test_constant_probability_not_density_heat(self):
  ll=np.array([[-80.,37.],[-79.99,37.],[-80.,37.01],[-79.99,37.01],[-79.995,37.005]]);d=raster(ll,np.full(5,.1),np.ones(5,bool),60,60);image=np.array(Image.open(io.BytesIO(base64.b64decode(d['image'].split(',')[1]))));rgb=image[:,:,:3][image[:,:,3]==166];self.assertGreater(len(rgb),100);self.assertLess(np.ptp(rgb,axis=0).max(),2)
 def test_missing_coverage_not_green(self):
  ll=np.array([[-80.,37.],[-79.99,37.],[-80.,37.01],[-79.99,37.01]]);d=raster(ll,np.zeros(4),np.zeros(4,bool),30,30);image=np.array(Image.open(io.BytesIO(base64.b64decode(d['image'].split(',')[1]))));self.assertFalse((image[:,:,3]==166).any());self.assertTrue((image[:,:,3]==90).any())
 def test_planning_band_boundaries(self):
  self.assertEqual(band(4.2)['label'],'Moderate impact');self.assertEqual(band(5)['label'],'Elevated impact');self.assertEqual(band(15)['label'],'High impact');self.assertEqual(band(30)['label'],'Severe impact');self.assertEqual(band(None)['label'],'Coverage unavailable')
if __name__=='__main__':unittest.main()
