"""Download all mapped OSM tree points/rows and woodland ways within the challenge extent."""
from pathlib import Path
import json,urllib.request,urllib.parse,datetime,concurrent.futures,time
ROOT=Path(__file__).resolve().parent
BBOX='36.975,-80.289,37.510,-79.603'
QUERIES={
 'trees':f'[out:json][timeout:90];(node["natural"="tree"]({BBOX});way["natural"="tree_row"]({BBOX}););out body geom;',
 'woodland':f'[out:json][timeout:90];(way["natural"="wood"]({BBOX});way["landuse"="forest"]({BBOX});way["landuse"="orchard"]({BBOX}););out body geom;'
}
def fetch(item):
 key,query=item;cache=ROOT/f'private/osm-{key}.json'
 if cache.exists():return key,json.loads(cache.read_text())
 last=None
 for host in ['https://overpass-api.de/api/interpreter','https://overpass.kumi.systems/api/interpreter']:
  try:
   req=urllib.request.Request(host,data=urllib.parse.urlencode({'data':query}).encode(),headers={'User-Agent':'current-hackohio-local-prototype/2.0 (regional vegetation research)'})
   with urllib.request.urlopen(req,timeout=110) as r:d=json.load(r)
   if 'remark' in d:print(key,'Overpass remark',d['remark'],flush=True)
   cache.write_text(json.dumps(d));print(key,'downloaded',len(d.get('elements',[])),flush=True);return key,d
  except Exception as e:last=e;print(key,host,str(e)[:130],flush=True)
 raise RuntimeError(f'{key}: {last}')
def main():
 sources={};results={}
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
  for key,d in ex.map(fetch,QUERIES.items()):results[key]=d
 trees=[];rows=[];woods=[]
 for key,d in results.items():
  sources[key]={'provider':'OpenStreetMap contributors / Overpass API','url':'https://www.openstreetmap.org/copyright','license':'ODbL 1.0','queriedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bbox':[ -80.289,36.975,-79.603,37.510],'osmTimestamp':d.get('osm3s',{}).get('timestamp_osm_base'),'count':len(d.get('elements',[]))}
  for e in d.get('elements',[]):
   tags=e.get('tags',{});props={'id':f"osm-{e['type']}-{e['id']}",'species':tags.get('species:en') or tags.get('species') or tags.get('genus') or 'Not recorded','height':tags.get('height'),'source':'OpenStreetMap','kind':'tree' if e['type']=='node' else 'tree_row' if tags.get('natural')=='tree_row' else 'woodland','name':tags.get('name') or ('Mapped tree' if e['type']=='node' else 'Tree row' if tags.get('natural')=='tree_row' else 'Woodland')}
   if e['type']=='node':trees.append({'type':'Feature','geometry':{'type':'Point','coordinates':[e['lon'],e['lat']]},'properties':props})
   elif e.get('geometry'):
    xy=[[x['lon'],x['lat']] for x in e['geometry'] if 'lon' in x]
    if props['kind']=='tree_row' and len(xy)>1:rows.append({'type':'Feature','geometry':{'type':'LineString','coordinates':xy},'properties':props})
    elif len(xy)>3 and xy[0]==xy[-1]:woods.append({'type':'Feature','geometry':{'type':'Polygon','coordinates':[xy]},'properties':props})
 out=ROOT/'public/data';out.mkdir(exist_ok=True)
 for name,features in [('trees',trees),('tree-rows',rows),('woodland',woods)]:
  (out/f'{name}.geojson').write_text(json.dumps({'type':'FeatureCollection','features':features},separators=(',',':')))
 meta={'sources':sources,'treeCount':len(trees),'treeRowCount':len(rows),'woodlandCount':len(woods),'note':'Mapped public OSM features, not a complete tree census. Absence of a mapped tree does not imply no trees. Woodland polygons are land cover, not individual tree positions. Polygons intersecting the boundary may extend outside it.'}
 (out/'nature-meta.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta,indent=2),flush=True)
if __name__=='__main__':main()
