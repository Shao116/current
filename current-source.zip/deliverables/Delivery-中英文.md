# current — Presentation delivery / 展示版交付核验

## Delivered / 已交付

- Operations web: `/workspace/index.html`. Separate navy / slate / teal interface; equipment exposure priorities, linked map, explicit load-budget recommendations, customer search, continuous risk layer, source dependencies, adjustable scenario parameters, CP-SAT scheduling and SimPy feasibility replay. Existing consumer homepage and APIs are preserved.
- Android: `deliverables/current-android.apk`, Android 8.0+, portrait, four tabs (Home / Map / Explore / Ask), NOTES widget layout, local preferences, battery calculation, household risk, exact upstream dependencies, real parameter recalculation. No DEMO banner; historical replay remains visible.
- 离线数据：117,642 个匿名客户、25,118 个支撑设备组、32,600 个匿名上游节点。无原始账号、姓名、地址、医疗标志或关键设施身份。设备坐标约 100 米概化；普通客户坐标保留供点选。

## What the numbers mean / 数字的含义

2012 Derecho peak gust (81 mph, NWS) and reanalysis wind direction (297°) are replayed uniformly over the **supplied present-day Roanoke, Virginia network**, not an observed 2012 outage footprint. This is not Ohio GIS. Model coefficients and contact geometry reuse the existing physics model; no new arbitrary vulnerability weights and no claimed local calibration.

先按设备类别、相位、线路与风向夹角及实际 LiDAR 树木落倒接触几何，算出参考损坏情景。再沿主办方真实客户上游依赖，用 32 点 Gauss–Hermite 对共同风暴因子的相关故障积分，得到住户情景概率和区域预计影响比例。未覆盖客户显示不可用，不显示零风险。网页及 App 中的危险分档是展示规划政策，不是经验证的生命安全阈值。

Repair is a **separate explicit-damage contingency**. The quantity slider assumes damaged support assemblies on the selected circuit. AEP workbook component rates × ILM 4.5 (already includes setup / travel / safety) produce task durations; available crews and access / safety holds constrain the schedule. Connected mode reuses CP-SAT and SimPy, with source critical-customer priority. Offline mode uses a feasible downstream-benefit list schedule, without exporting sensitive critical-customer identities. Customer stages come from the last completed failed ancestor, not invented percentages. Pole / transformer size defaults remain declared references.

维修时间的上下界来自声明的对数正态维修工时 CV：所有任务工时一起改变后的敏感性范围，**不是已校准的置信区间**。在线、离线优先顺序可能不同，因为在线还使用原始关键客户优先策略及优化器。Selected connection first 是显式用户假设，不表示已获 AEP 医疗优先认证。

Load reduction uses explicitly assumed demand per customer, available aggregate supply, participation and flexible-load share. It conserves the declared MW budget and reports any remaining deficit; it is **not measured feeder load, AC power flow or an actual control command**. It does not change wind fragility merely because demand is reduced.

负荷削减只是可调的负荷预算计算，没有实时 MW、容量、开关或潮流数据，不能宣称已验证转供或已下发控制。网页左侧设备是检查优先级，不是已确认受损设备。

## Measured validation / 实测核验

- Existing regression: **83 tests passed** after integration (see regression.txt).
- **20 actual executable scenario checks**, listed below; no crew overlap, no premature work before access/safety release, valid cumulative restoration stages, missing coverage preserved, zero-wind and zero-job edges, invalid inputs rejected.
- Offline default region: 2.7382978315%; Python reference: 2.7382940816%; difference 0.0000037499 percentage points. This verifies implementation parity, **not predictive accuracy**.
- With 12 identical pole tasks at the selected circuit: 1 crew = 186.28 h; 6 crews = 31.88 h in the offline mean schedule. More crews do not alter the wind outage likelihood.
- Installed APK on Pixel 6 Pro API 31 arm64 emulator: offline and connected checks passed, 4 tabs, portrait=true, content width = viewport width = 412 CSS pixels, no JavaScript console errors. First recorded cold run 1676 ms; later offline 491 ms, final signed-build offline 371 ms, and connected 311 ms. These are emulator measurements, not claims for every phone.
- Browser interaction verified customer search, exact upstream path, changing crews, map layers, portrait navigation, and 3000 Wh / 50 W = 60 h backup calculation. Screenshots in reports/launch.

**真实结果 / Ground truth:** none available for these customer/time combinations. Every row below is a scenario test, not a historical outcome backtest. Accuracy, calibration error and real-world ERT error are unavailable. Rain/ice/snow/soil and terrain amplification remain incomplete. Risk is uncalibrated; ERT is conditional; no official AEP estimate is claimed.

## 20 scenarios / 20 组情景

All weather rows use the historical event as reference; altered gust/direction values are explicit counterfactuals, not claims of recorded weather at those locations. 所有修改后的气象参数均为反事实条件。

| # | Customer 客户 | Gust 风 mph / ° | Crews 队伍 / Jobs 假设损坏 | Home % 住户 | Region % 区域 | Online repair h 在线维修 | Physics ms | API ms | Solver |
|---|---|---|---|---|---|---|---|---|---|
| 1 | P-094125 | 0 / 0 | 1 / 0 | 0.000 | 0.000 | 0.00–0.00 | 126.3 | 43.7 | EMPTY |
| 2 | P-000001 | 0 / 0 | 3 / 3 | 0.000 | 0.000 | 2.95–7.55 | 50.5 | 4.6 | OPTIMAL |
| 3 | P-020015 | 0 / 0 | 6 / 6 | Unavailable / 无覆盖 | 0.000 | 7.69–18.75 | 48.1 | 4.2 | OPTIMAL |
| 4 | P-040000 | 0 / 0 | 12 / 12 | 0.000 | 0.000 | 6.84–8.83 | 42.8 | 6.3 | OPTIMAL |
| 5 | P-117642 | 0 / 0 | 20 / 20 | 0.000 | 0.000 | 30.08–44.42 | 43.3 | 7.9 | OPTIMAL |
| 6 | P-094125 | 40 / 90 | 1 / 0 | 0.649 | 0.634 | 0.00–0.00 | 85.9 | 2.2 | EMPTY |
| 7 | P-000001 | 40 / 90 | 3 / 3 | 1.285 | 0.634 | 2.95–7.55 | 66.4 | 3.5 | OPTIMAL |
| 8 | P-020015 | 40 / 90 | 6 / 6 | Unavailable / 无覆盖 | 0.634 | 7.69–18.75 | 65.6 | 4.8 | OPTIMAL |
| 9 | P-040000 | 40 / 90 | 12 / 12 | 0.255 | 0.634 | 6.84–8.83 | 77.8 | 7.7 | OPTIMAL |
| 10 | P-117642 | 40 / 90 | 20 / 20 | 0.647 | 0.634 | 30.08–44.42 | 77.4 | 9.1 | OPTIMAL |
| 11 | P-094125 | 81 / 297 | 1 / 0 | 3.232 | 2.738 | 0.00–0.00 | 79.2 | 2.5 | EMPTY |
| 12 | P-000001 | 81 / 297 | 3 / 3 | 3.980 | 2.738 | 2.95–7.55 | 77.9 | 4.4 | OPTIMAL |
| 13 | P-020015 | 81 / 297 | 6 / 6 | Unavailable / 无覆盖 | 2.738 | 7.69–18.75 | 81.2 | 4.0 | OPTIMAL |
| 14 | P-040000 | 81 / 297 | 12 / 12 | 1.377 | 2.738 | 6.84–8.83 | 67.2 | 6.0 | OPTIMAL |
| 15 | P-117642 | 81 / 297 | 20 / 20 | 2.366 | 2.738 | 30.08–44.42 | 67.9 | 7.7 | OPTIMAL |
| 16 | P-094125 | 100 / 270 | 1 / 0 | 7.054 | 5.016 | 0.00–0.00 | 66.3 | 2.5 | EMPTY |
| 17 | P-000001 | 100 / 270 | 3 / 3 | 9.830 | 5.016 | 2.95–7.55 | 66.1 | 3.8 | OPTIMAL |
| 18 | P-020015 | 100 / 270 | 6 / 6 | Unavailable / 无覆盖 | 5.016 | 7.69–18.75 | 66.1 | 3.5 | OPTIMAL |
| 19 | P-040000 | 100 / 270 | 12 / 12 | 1.629 | 5.016 | 6.84–8.83 | 66.1 | 6.2 | OPTIMAL |
| 20 | P-117642 | 100 / 270 | 20 / 20 | 6.995 | 5.016 | 36.08–50.42 | 67.7 | 7.8 | OPTIMAL |

## Use / 使用

Start existing server with `.venv/bin/python server.py`; open http://127.0.0.1:8765/workspace/index.html . Consumer browser companion: http://127.0.0.1:8765/mobile/index.html . The existing root homepage remains available.

Install APK on Android 8.0+. Risk, source paths, personal plan and repair sensitivity work from bundled data. Free road tiles need internet; no paid key. Mac Ollama / full optimizer require the existing Mac server connection. Over USB with Android debugging enabled, run `adb reverse tcp:8765 tcp:8765`; reopen current. No LAN exposure is enabled. Without the Mac, Ask gives explicitly labeled on-device deterministic guidance, not a fake LLM response. No live SMS, emails or utility control commands are sent.

手机无需 Mac 也可计算。连接 Mac 后可使用原来的完整优化服务和 Ollama；未连接时 Ask 明确显示 On-device guidance。路网底图需联网，离线仅提供现有 GIS 覆盖回退，不保证完整街道。当前是历史事件峰值回放，未编造未来 72 小时逐小时气象。

Rebuild: `android/build-apk.sh`. Verify: `node algorithms/test_presentation.cjs`; Python regression command in reports/launch/regression.txt generation script. Android: `adb install -r deliverables/current-android.apk`; `adb shell am instrument -w com.current.storm/.CurrentChecks`.

Sources actually reused: [Hou et al. 2023 vulnerability model](https://doi.org/10.1007/s13753-023-00478-x), [NWS 2012 Derecho assessment](https://www.weather.gov/media/publications/assessments/derecho12.pdf), organizer GIS and matched_upstream, Install_Labor_HackOHIO.xlsx, and the existing documented Open-Meteo / LiDAR acquisition. NOTES.pdf supplies layout direction, not evidence of outage probabilities or operational capacity.
