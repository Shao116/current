from pathlib import Path
import json,hashlib,csv,re,html,datetime,statistics
import markdown
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'reports/technical';p=OUT/'项目技术全解-中文.md';text=p.read_text();text=text.split('\n## 附录 A.')[0]
R=json.loads((ROOT/'algorithms/literature.json').read_text());L=json.loads((ROOT/'algorithms/labor_catalog.json').read_text());C=json.loads((ROOT/'reports/fusion/data-coverage.json').read_text());D=json.loads((ROOT/'reports/launch/20-scenarios.json').read_text())
def table(head,rows):return '\n| '+' | '.join(head)+' |\n|'+'|'.join(['---']*len(head))+'|\n'+''.join('| '+' | '.join(str(v).replace('|','/') for v in row)+' |\n' for row in rows)
text+='\n## 附录 A. 当前物理概率系数全表\n\n来源分类：论文参考迁移，不是主办方参数，也不是本地重新拟合。每个系数的对应含义见式(15)、(17)。\n'
rows=[]
for kind in ['pole','wire']:
 for phase,classes in R[kind+'Coefficients'].items():
  for cl,b in classes.items():rows.append([kind,phase,cl,*b])
text+=table(['模式','相位参考','杆类别参考','b0','b1','b2'],rows)
text+='\n树断裂系数 (-17.28,0.42,0.13)，连根倒伏 (-2.22,-0.43,0.11)；其余接触／组合改动是本项目假设。当前不使用论文表5建立完整树撞导线力学模型。\n'
text+='\n## 附录 B. Excel 实际读取的全部工时目录\n\n以下列出运行目录中的精确原值；空值保留为 None，不伪造为零。它们是“可以按实际组件选择”的目录，不是每次把所有工项累加。安装／拆卸工时的 crew-hour 解释仍是声明假设。\n'
for key,title in [('poleSizes','电杆尺寸'),('transformerKVA','变压器容量'),('material','材料组件'),('connectors','95 个 CNC 精确编码')]:
 text+='\n### B.'+title+'\n';text+=table(['键／类别','安装 h','拆卸 h','Sheet','Excel 行'],[[k,v.get('install'),v.get('remove'),v.get('sheet'),v.get('row')] for k,v in L[key].items()])
text+='\n### B.附加工项\n';text+=table(['名称','原值 h','单位','Sheet','行'],[[k,v['hours'],v['unit'],v['sheet'],v['row']] for k,v in L['adders'].items()]);text+='\n### B.CU 组说明（不是额外工时）\n';text+=table(['键','说明','行'],[[k,v['description'],v['row']] for k,v in L['descriptions'].items()])
params=[
('wind','55；新客户端81','mph','API 0–120','用户／气象','活跃风灾输入'),('windDirection','0；回放297','° 来向','UI 0–360；服务非负','气象／声明','活跃方向'),('crews','3','支队伍','1–20整数','声明','维修资源'),('quantity','3；新客户端6','个','API 0–50；UI 0–40','声明','显式损坏模式，不反改天气概率'),('upstream','1','个','0–10整数','声明','旧模式额外损坏数'),('accessDelay','1','h','API 0–48；UI 0–24','声明','释放延迟'),('hazardHoldHours','0','h','API 0–168；UI 0–24','声明','安全等待'),('repairCV','0.5','无量纲','API 0–2；UI 0–1.5','假设','维修工时变异'),('correlation / rho','0.35','潜在正态相关','0≤rho<1；UI≤0.9','假设','共同风暴因子'),('fallCorridorM / corridor','1','m','UI 0.5–5；风险栅格接口>0且≤100','假设','树接触几何'),('rainMm','0；回放0.6','mm','非负；UI≤100','气象／声明','上下文，未标定雨土破坏系数'),('snowfallCm','0','cm','非负；UI≤60','气象／声明','冬季不完整标记'),('snowDepthM','0','m','非负','气象／声明','冬季不完整标记'),('freezingRain','false','布尔','true/false','天气码／声明','冬季不完整标记'),('iceAccretionMm','缺失','mm','非负或缺失','未知','未形成已验证冰荷载模型'),('trials','128','次','天气16–2048整数','数值设置','Monte Carlo'),('seed','20261024','整数','RNG 可接受整数','数值设置','复现；维修流+917'),('asset','pole','类型','pole/wire/transformer/fuse/switch','声明','维修工项'),('size','medium','类别','small/medium/large','GIS 或声明','对应 Excel 行'),('crewSize','1','人／队参考','person_hours 才作为除数','声明','非队伍数量'),('laborBasis','crew_hours','解释','crew_hours/person_hours','声明','工时单位解释'),('components','缺省为主组件×1','列表','验证组件和非负数量','声明','实际选择的损坏部件'),('damageDetails','{}','字典','每节点覆盖','声明','具体损坏证据'),('laborAdders','[]','列表','最多20个；不能重复；挖掘需体积','声明','Excel 附加工项'),('drawingPage','无','页','1–9整数','声明','图纸参考，不自动BOM'),('crewRange','[crews,crews]','队伍数','两项1–20整数','声明','天气恢复情景'),('accessDelayRange','[delay,delay]','h','两项0–72','声明','天气恢复情景'),('repairHours','无','h','显式正工时覆盖','声明','无目录工项需说明'),('facilityLinks','[]','核验链接','最多52条；存在且verified=true','核验声明','设施到客户关联'),('scope','所选回路','范围','all 或回路','请求','更换分母和计算范围'),('predictionMode','由请求解析','模式','weather/conditional','请求','不可混用估计对象'),('priority','customers','政策','customers/critical','政策','新客户端选中连接优先'),('load','2','kW/户','UI 0.2–6','假设','运营负荷预算'),('capacity','200','MW','UI 0–800','假设','聚合可用供电预算'),('participation','30','%','UI 0–100','假设','参与率'),('flexible','25','%','UI 0–80','假设','灵活负荷比例'),('battery','500 usable','Wh','UI 0–3000','用户','个人电池可用能量'),('watts','50','W','UI 10–500','用户','必需负载'),('medical/accessible/critical','false','布尔','用户自述','偏好／政策','不从坐标推断健康'),('stage','pre','阶段','pre/outage/update/restored','声明','原消费者沟通状态'),('channel','SMS；客户端可另选','类别','SMS/Email/In-app','偏好','仅本地预览'),('optIn','false','布尔','用户选择','偏好','不等于已发送通知'),('contextType','map','类型','map/premise/circuit','请求','选择数据范围'),('contextId','无','匿名ID','匹配已有记录','请求','不接受虚构客户'),('lat/lng','37.27/-79.94','°','36.95–37.53 / -80.32–-79.58','位置','计算区域约束'),('date','旧服务回退2026-10-24；回放2012-06-29','日期','显式请求优先','时间','不是实时钟自动更新时间'),('historicalWeather','false','布尔','缓存有对应年时可读取','请求','2012另由回放资料提供'),('backup','未验证','字典','五项核验+容量约束','声明／证据','不实际应用替代馈线'),('step','false','布尔','true/false','兼容显示','恢复阶段仍由依赖计算')]
text+='\n## 附录 C. 输入与工程假设登记\n\n表中区分代码缺省值、新客户端初值与范围；不是所有字段都进入风险公式。前端参数名 rho/corridor 等在调用服务时映射为 correlation/fallCorridorM。\n';text+=table(['参数','默认／初值','单位','范围／约束','来源分类','作用'],params)
with (OUT/'参数登记.csv').open('w',newline='') as f:w=csv.writer(f);w.writerow(['parameter','default','unit','constraint','source','role']);w.writerows(params)
text+='\n## 附录 D. 最近20组实际场景输出\n\n所有行真实结果均缺失；无准确率可计算。以下是实际执行的工程场景，不是20场实际停电回测。完整精度见 JSON。\n';rows=[]
for v in D['cases']:rows.append([v['case'],v['customer'],v['windMph'],v['direction'],v['crews'],v['damageCount'],v['asset'],'不可用' if v['homeModeledPercent'] is None else f"{v['homeModeledPercent']:.6f}",f"{v['regionalExpectedPercent']:.6f}",f"{v['onlineRepairLow']:.3f}–{v['onlineRepairHigh']:.3f}",f"{v['physicsMs']:.2f}",f"{v['fullServiceMs']:.2f}",v['onlineSolver']])
text+=table(['#','客户','mph','风向°','队伍','假设损坏','组件','个人参考%','全区参考%','在线计划h','本地风险ms','在线请求ms','求解器'],rows)
text+='\n## 附录 E. 106个已审计来源文件\n\n此表只是文件存在性、哈希和去重证据，不把文件数当作模型参数或独立训练样本数。文件详情另保存在来源审计 JSON。\n'
files=C['sourceFiles'];fileRows=[]
if isinstance(files,dict):files=[{'path':k,**(v if isinstance(v,dict) else {'value':v})} for k,v in files.items()]
for v in files:
 if isinstance(v,dict):fileRows.append([v.get('path',v.get('file',v.get('source',''))),v.get('bytes',v.get('sizeBytes',v.get('size',''))),v.get('sha256',''),v.get('role',v.get('classification',''))])
 else:fileRows.append([v,'','',''])
text+=table(['文件','字节','SHA256（若已登记）','已有分类'],fileRows)
with (OUT/'来源文件清单.csv').open('w',newline='') as f:w=csv.writer(f);w.writerow(['file','bytes','sha256','existingRole']);w.writerows(fileRows)
text+='\n## 附录 F. GIS 原始字段可用性（不输出个人属性值）\n\n这是字段是否出现／非空的审计，不等于每个字段已经进入概率公式。实际数值角色见正文和数据融合审计。\n'
for layer,v in C['assetSchemaAudit'].items():
 text+='\n### F.'+layer+'\n';items=v.get('fieldsPresentCounts',{});text+=table(['字段','非空／存在记录数','图层记录数'],[[k,n,v.get('records')] for k,n in items.items()])
text+='\n## 附录 G. 当前代码与可复核来源\n\n代码是本文对实际实现的主要证据，外部论文提供参考而非本项目准确率。\n'
for name in ['build_data.py','features.py','vulnerability.py','impact.py','weather_engine.py','restoration.py','restoration_ensemble.py','operations_plan.py','model.py','customer_view.py','risk_surface.py','export_presentation.py','export_mobile_paths.py']:
 text+=f'- [`algorithms/{name}`](../../algorithms/{name})\n'
text+='''
外部一手资料：

- Hou & Muraleetharan, 2023, *Modeling the Resilience of Power Distribution Systems Subjected to Extreme Winds Considering Tree Failures: An Integrated Framework*. DOI: https://doi.org/10.1007/s13753-023-00478-x 。系数登记和本项目适配分别列明。
- Arif et al., 2018, *Optimizing Service Restoration in Distribution Systems With Uncertain Repair Time and Demand*: https://www.anl.gov/argonne-scientific-publications/pub/149277 ；只支持所参考的模型家族，不把其数值实验当本地验证。
- NWS, *The Historic Derecho of June 29, 2012*: https://www.weather.gov/media/publications/assessments/derecho12.pdf 。Roanoke 81 mph 记载在正文8页。
- Open-Meteo historical documentation: https://open-meteo.com/en/docs/historical-weather-api 。再分析与观测的区别。
- OR-Tools: https://developers.google.com/optimization/scheduling/job_shop 。资源与区间建模。
- SimPy: https://simpy.readthedocs.io/en/latest/simpy_intro/shared_resources.html 。共享资源事件。
- USGS 3DEP 下载地址、时间与哈希见 `private/algorithm/dem.tif.source.json`；Roanoke LiDAR 源见 `public/data/roanoke-nature-meta.json`；OSM 请求结果见 `public/data/nature-meta.json`。
'''
p.write_text(text)
paths=list((ROOT/'algorithms').glob('*.py'))+list((ROOT/'algorithms').glob('*.json'))+[ROOT/x for x in ['engine.py','server.py','weather.py','public/workspace/model.js','public/workspace/ui.js','public/workspace/worker.js','public/workspace/replay.json','android/AndroidManifest.xml','android/build-apk.sh','android/app/src/main/java/com/current/storm/MainActivity.java','android/app/src/main/java/com/current/storm/CurrentChecks.java']]
manifest={'date':'2026-10-25 America/New_York','sourceHashes':{str(x.relative_to(ROOT)):hashlib.sha256(x.read_bytes()).hexdigest() for x in paths if x.is_file()},'paperSha256':hashlib.sha256(text.encode()).hexdigest(),'scope':'Current implementation audit; not real-world predictive calibration','sourceFileAuditCount':C['sourceFilesAudited'],'scenarioCases':len(D['cases']),'realOutcomeBacktests':0}
(OUT/'实现快照.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False));(OUT/'完整参数与数据角色.json').write_text(json.dumps({'inputParameters':[dict(zip(['name','default','unit','constraint','source','role'],v)) for v in params],'literature':R,'labor':L,'dataRoles':C['roles'],'features':__import__('algorithms.model',fromlist=['FEATURES']).FEATURES},indent=2,ensure_ascii=False))
maths=[]
def protect(m):
 maths.append(html.escape(m.group(0)));return 'MATHPROTECTEDTOKEN'+str(len(maths)-1)+'ENDTOKEN'
protected=re.sub(r'\\\[(.*?)\\\]',protect,text,flags=re.S);protected=re.sub(r'\\\((.*?)\\\)',protect,protected,flags=re.S)
body=markdown.markdown(protected,extensions=['tables','fenced_code','toc'],output_format='html')
for i,x in enumerate(maths):body=body.replace('MATHPROTECTEDTOKEN'+str(i)+'ENDTOKEN',x)
page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>current 项目技术全解</title><style>body{font:16px/1.85 system-ui,-apple-system,sans-serif;color:#173547;background:#f6f8fa;margin:0}article{max-width:1180px;margin:30px auto;background:#fff;padding:42px 50px;border:1px solid #dce4e9;border-radius:18px}h1{font-size:34px;line-height:1.4}h2{font-size:25px;margin-top:2em;border-bottom:1px solid #ccd9e0;padding-bottom:10px}h3{font-size:20px;margin-top:1.7em}table{border-collapse:collapse;width:100%;display:block;overflow:auto;font-size:12px;line-height:1.6}td,th{padding:8px 10px;border:1px solid #d2dfe5;vertical-align:top}th{background:#eaf1f4;white-space:nowrap}a{color:#176979}code{background:#edf3f5;padding:2px 4px;border-radius:4px;word-break:break-word}pre{background:#edf3f5;padding:18px;overflow:auto}blockquote{margin:15px 0;border-left:4px solid #176979;padding:5px 18px}.toolbar{position:sticky;top:0;background:#142e40;color:white;padding:12px 25px;z-index:2}.toolbar a{color:#d9f3ee;margin-right:20px}.toc ul{list-style:none;padding-left:18px}.toc{font-size:13px;max-height:400px;overflow:auto;background:#f3f7f8;padding:20px}@media(max-width:700px){article{padding:20px;margin:10px}body{font-size:15px}h1{font-size:28px}}@media print{body{background:white;font-size:10pt}article{border:0;margin:0;padding:0}.toolbar,.toc{display:none}h2{break-before:page}table{font-size:8pt;display:table}tr{break-inside:avoid}a{color:inherit}}</style><script>window.MathJax={tex:{inlineMath:[['\\\\(','\\\\)']],displayMath:[['\\\\[','\\\\]']]},options:{skipHtmlTags:['script','noscript','style','textarea','pre','code']}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script><div class="toolbar"><strong>current · 技术实现审计</strong>　<a href="#技术目录">目录</a><a href="index.html">运营端</a></div><article>'''
toc=markdown.Markdown(extensions=['toc']);toc.convert(protected);page+='<div id="技术目录" class="toc">'+toc.toc+'</div>'+body+'</article></html>'
(OUT/'项目技术全解-中文.html').write_text(page);(ROOT/'public/workspace/technical.html').write_text(page)
print('Chinese characters:',len(text),'math blocks:',len(maths),'source files:',len(fileRows),'input parameters:',len(params),'bytes:',len(page.encode()))
