from pathlib import Path
import urllib.request,urllib.parse,json,concurrent.futures,datetime
ROOT=Path(__file__).resolve().parent
BASE='https://services.arcgis.com/jIL9msH9OI208GCb/arcgis/rest/services/Roanoke_Trees_3D/FeatureServer/0'
CITY='https://services.arcgis.com/KII0S5XRkpE66Ngk/arcgis/rest/services/TreePlotter_Canopy_Roanoke_Census_Block_Groups/FeatureServer/0'
def get(url,params):
 req=urllib.request.Request(url+'?'+urllib.parse.urlencode(params),headers={'User-Agent':'current-hackohio-prototype/2.0'})
 with urllib.request.urlopen(req,timeout=45) as f:return json.load(f)
def page(off):
 d=get(BASE+'/query',{'f':'geojson','where':'1=1','outFields':'OBJECTID,HEIGHT,Units','outSR':4326,'resultOffset':off,'resultRecordCount':2000,'orderByFields':'OBJECTID ASC','geometryPrecision':6})
 if 'error' in d:raise RuntimeError(d['error'])
 print('Tree batch',off,len(d.get('features',[])),flush=True);return d['features']
def main():
 count=get(BASE+'/query',{'f':'json','where':'1=1','returnCountOnly':'true'})['count'];features=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  for batch in pool.map(page,range(0,count,2000)):features.extend(batch)
 seen=set();out=[]
 for f in features:
  p=f['properties'];ident=p['OBJECTID']
  if ident in seen:continue
  seen.add(ident);height=p.get('HEIGHT');units=p.get('Units');p.clear();p.update({'id':f'lidar-{ident}','kind':'lidar_tree','name':'LiDAR-derived tree','source':'Public Roanoke 3D demo','height':height,'units':units})
  # Do not infer surveyed species or canopy condition from generated tree models.
  out.append(f)
 if len(out)!=count:raise RuntimeError('Incomplete download')
 (ROOT/'public/data/lidar-trees.geojson').write_text(json.dumps({'type':'FeatureCollection','features':out},separators=(',',':')))
 canopy=get(CITY+'/query',{'f':'geojson','where':'1=1','outFields':'FID,TreeCanopy,Shape__Area','outSR':4326,'geometryPrecision':5,'maxAllowableOffset':8})
 if 'error' in canopy:raise RuntimeError(canopy['error'])
 for f in canopy['features']:
  p=f['properties'];p['name']='City canopy assessment area';p['source']='City of Roanoke / TreePlotter';p['kind']='canopy_area'
 (ROOT/'public/data/canopy.geojson').write_text(json.dumps(canopy,separators=(',',':')))
 meta={'lidarTrees':len(out),'canopyAreas':len(canopy['features']),'downloadedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'lidarSource':BASE,'canopySource':CITY,'lidarItem':'https://www.arcgis.com/home/item.html?id=84a0a604cc514af88f0e2cad30c754af','canopyItem':'https://www.arcgis.com/home/item.html?id=a26b6445f5e441cfa7b76c4acbeb75e2','license':'Publicly accessible ArcGIS services with no access fee or token; no explicit reuse license was supplied in item metadata. Retain attribution and verify permission before redistribution/commercial use.','coverage':'LiDAR-derived trees in selected Roanoke redlining study zones; not a full regional tree inventory or condition survey. Canopy features are census-block assessment areas, not individual crown boundaries.'}
 (ROOT/'public/data/roanoke-nature-meta.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta,indent=2),flush=True)
if __name__=='__main__':main()
