#!/bin/zsh
cd /Users/tony/Desktop/AEP/outage-concierge
if curl -fs http://127.0.0.1:8765/api/health >/dev/null 2>&1; then
 open http://127.0.0.1:8765
 exit 0
fi
./.venv/bin/python server.py &
current_server_pid=$!
trap 'kill "$current_server_pid" 2>/dev/null' INT TERM EXIT
for current_attempt in {1..40}; do
 if curl -fs http://127.0.0.1:8765/api/health >/dev/null 2>&1; then
  open http://127.0.0.1:8765
  break
 fi
 sleep 0.2
done
wait "$current_server_pid"
