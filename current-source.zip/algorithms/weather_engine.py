"""Additive weather-to-impact path for the existing v2 Service."""
import math,time,copy,json,gzip,hashlib,os
from pathlib import Path
import numpy as np
from .vulnerability import PhysicsModel
from .impact import scenario_impact
from .restoration_ensemble import restore_ensemble

def run_weather(service,s,raw):
 start=time.perf_counter();key='weather-v21:'+json.dumps([s,raw],sort_keys=True,allow_nan=False)
 if not hasattr(service,'weather_signature'):
  sources=sorted(Path(__file__).parent.glob('*.py'))+sorted(Path(__file__).parent.glob('*.json'));signature=''.join(hashlib.sha256(p.read_bytes()).hexdigest() for p in sources)
  root=Path(__file__).resolve().parents[1]
  for relative in ['private/algorithm/network.pkl','private/algorithm/dem.tif','public/data/lidar-trees.geojson','public/data/woodland.geojson','public/data/canopy.geojson']:
   path=root/relative;signature+=str(path.stat().st_mtime_ns) if path.exists() else 'missing:'+relative
  signature+=''.join(str(p.stat().st_mtime_ns) for p in sorted((Path(__file__).resolve().parents[1]/'private/algorithm').glob('weather-*.json')))
  service.weather_signature=hashlib.sha256(signature.encode()).hexdigest()
 disk_dir=Path(__file__).resolve().parents[1]/'private/algorithm/results';disk_path=disk_dir/(hashlib.sha256((service.weather_signature+key).encode()).hexdigest()+'.json.gz')
 if raw.get('scope')=='all' and disk_path.exists():
  try:
   with gzip.open(disk_path,'rt') as f:result=json.load(f)
   result['performance'].update(cacheHit=True,cacheTier='private_compressed_disk');return result
  except (OSError,ValueError):pass
 with service.lock:
  if key in service.cache:
   result=copy.deepcopy(service.cache[key]);result['performance']['cacheHit']=True;return result
  if not hasattr(service,'physics'):service.physics=PhysicsModel(service.d,service.features)
 physics=service.physics;customers=service.d['customers']
 if s['contextType']=='premise':ci=int(s['contextId'].split('-')[1])-1
 else:_,ci=service.customer_tree.query(service.project.transform(s['lng'],s['lat']));ci=int(ci)
 circuit=s['contextId'] if s['contextType']=='circuit' else customers[ci]['circuit'];scope=service.circuits[circuit] if raw.get('scope')!='all' else list(range(len(customers)))
 weather={'date':str(raw.get('date','2026-10-24')),'gustMph':s['wind'],'windDirection':float(raw.get('windDirection',0)),'gustDefinitionCaveat':'Published reference uses 3-second gust; forecast/reanalysis duration equivalence is unverified; no invented conversion.','rainMm':float(raw.get('rainMm',0)),'snowfallCm':float(raw.get('snowfallCm',0)),'snowDepthM':float(raw.get('snowDepthM',0)),'freezingRainIndicator':raw.get('freezingRain') is True,'iceAccretionMm':raw.get('iceAccretionMm'),'source':'Caller-selected hazard or frontend forecast; no local observation asserted'}
 if raw.get('historicalWeather'):
  historical=service.features.historical(weather['date'],s['lng'],s['lat'])
  if historical:weather={**historical,'gustDefinitionCaveat':'Published reference uses 3-second gust; reanalysis gust duration equivalence is unverified.'}
  else:weather.update(historicalUnavailable=True,source='Historical weather unavailable: explicit manual fallback')
 precise=(s['lng'],s['lat'])
 if s['contextType']=='premise':
  from pyproj import Transformer
  precise=Transformer.from_crs(26917,4326,always_xy=True).transform(*customers[ci]['xy'])
 feature=service.features.at(*precise,weather);ids=sorted(set(n for i in scope for n in physics.by_customer[i]));p,lo,hi,rows,method=physics.predict(ids,weather,feature,raw)
 weather['inputWindDirection']=raw.get('windDirection')
 if weather['windDirection']!=method['windDirectionUsed']:
  weather['windDirection']=method['windDirectionUsed'];weather['windDirectionSource']=method['windDirectionSource'];feature=service.features.at(*precise,weather)
 trials=raw.get('trials',128);rho=float(raw.get('correlation',.35));seed=raw.get('seed',20261024)
 if not isinstance(trials,int) or not 16<=trials<=2048:raise ValueError('trials must be an integer 16–2048')
 if not isinstance(seed,int) or not 0<=rho<1:raise ValueError('Invalid seed or correlation')
 impact=scenario_impact(physics.nodes,customers,scope,ids,p,trials,seed,rho);draws=impact.pop('_draws');expected=impact.pop('_expected');covered=impact.pop('_coverage');lower=float(expected(lo).mean()*100);upper=float(expected(hi).mean()*100)
 winter=weather.get('freezingRainIndicator') or weather.get('snowfallCm',0)>0 or weather.get('snowDepthM',0)>0
 impact.update({'region':circuit if raw.get('scope')!='all' else 'All supplied customers','scope':'Supplied customer extract' if raw.get('scope')=='all' else 'Selected circuit','modelSensitivityRangePercentage':[lower,max(upper,impact['expectedAffectedPercentage'])],'totalHazardBoundPercentage':[lower,100.] if winter else None,'hazardModelComplete':False,'coverageMeaning':'Customers with at least one modeled support on original paths; not complete coverage of all failure modes or upstream equipment','fullSystemUncertaintyQuantified':False,'modelType':'Transferred pole-wire wind fragility plus conservative LiDAR tree-contact scenario','warnings':['Reference-model scenario estimate, NOT locally calibrated storm outage probability or official AEP forecast.','Shared AEP location identifiers associate mounted assemblies to existing source paths; no nearest-customer links or invented feeder edges.','Published Oklahoma Southern-Pine/Bur-oak assumptions are transferred; age, tree species/health and full-span coverage are unverified.','Quantiles describe reference simulation, not calibrated forecast coverage.','Snow/ice effects unquantified: displayed estimate covers wind/tree only; total winter hazard may be substantially higher.' if winter else 'Rain-soil coupling and terrain wind amplification are not quantified without defensible parameters.']})
 ert=restore_ensemble(service.d,physics.nodes,scope,draws,s,raw,rows,weather_mode=True)
 if not ert.get('perCustomer'):ert['perCustomer']=[{'id':customers[i]['id'],'hoursLow':None,'hoursHigh':None,'basis':'Repair scenario overloaded or unsupported'} for i in scope]
 expected_count=float(p.sum());tree_sum=sum(r['treeContactScenarioProbability'] for r in rows);wind_sum=sum(r['windScenarioProbability'] for r in rows);wire_sum=sum(r['wireScenarioProbability'] for r in rows)
 if not hasattr(service,'damage_tree'):
  from scipy.spatial import cKDTree
  service.damage_tree=cKDTree([d['xy'] for d in service.d['damage']])
 nearby=service.damage_tree.query_ball_point(service.project.transform(*precise),3000)
 datekey=weather['date'].replace('-','')[:8];prior=[j for j in nearby if service.d['damage'][j]['attributes'].get('Report_Tim','99999999')[:8]<datekey]
 assessment={'status':'partial_winter_hazard' if winter else 'uncalibrated_engineering_scenario','label':'Wind/tree engineering scenario · not calibrated','expectedDamagedAssemblies':expected_count,'dominantMode':'tree contact' if tree_sum>max(wind_sum,wire_sum) else 'conductor wind loading' if wire_sum>wind_sum else 'pole wind loading','modeExpectedCountsNotAdditive':{'poleWind':wind_sum,'wireWind':wire_sum,'treeContact':tree_sum},'weather':weather,'terrain':feature['terrain'],'seasonalWind':feature['seasonalWind'],'historicalDamage':{'reports':len(service.d['damage']),'priorReportsWithin3km':len(prior),'dateFilter':'Strictly before scenario date; no future damage leakage','use':'Positive context only; not treated as complete storm exposures or healthy negatives'},'reliability':'Transferred physical parameters; scenario uncertainty is quantified, local predictive accuracy is unknown','criticalFacilities':ert.get('criticalFacilities',{}),'coverage':physics.audit}
 if not ids:
  impact.update(status='unavailable',expectedAffectedPercentage=None,scenarioInterval95Percentage=None,modelSensitivityRangePercentage=None,monteCarloMeanCI95Percentage=None)
  impact['warnings'].insert(0,'No supported overhead assembly coverage in this scope; missing coverage is NOT zero outage risk.')
  ert.update(status='unavailable',low=None,high=None,reason='No supported failure-to-customer model in this scope.')
  for row in ert['perCustomer']:row.update(hoursLow=None,hoursHigh=None,basis='Unmodeled support coverage; unknown, not zero.')
  assessment.update(status='no_model_coverage',expectedDamagedAssemblies=None)
 result={'dataFusion':service.fusion,'impact':impact,'ert':ert,'physicsFeatures':feature,'equipmentPredictions':rows[:100],'equipmentPredictionCount':len(rows),'equipmentFeatures':[],'riskAssessment':assessment,'engineeringModel':method,'model':{'status':'transferred_physics_active','unconditionalProbabilitiesAvailable':False,'reasons':['Published reference fragility parameters are active without local calibration.','No reliable asset-event negative labels or hourly customer outcomes.'],'pipeline':service.status()['model']['pipeline']},'performance':{'cacheHit':False,'seconds':time.perf_counter()-start,'seed':seed},'scopeCircuit':circuit}
 payload=json.dumps(result,allow_nan=False)
 if len(payload)>=8_000_000:
  disk_dir.mkdir(exist_ok=True)
  temporary=disk_path.with_suffix('.'+str(os.getpid())+'.'+str(time.time_ns())+'.tmp')
  with gzip.open(temporary,'wt',compresslevel=1) as f:f.write(payload)
  temporary.replace(disk_path)
  # Bounded, reproducible private artifact cache. No raw GIS identity fields.
  for stale in sorted(disk_dir.glob('*.json.gz'),key=lambda p:p.stat().st_mtime,reverse=True)[8:]:stale.unlink(missing_ok=True)
 with service.lock:
  if len(payload)<8_000_000:service.cache[key]=copy.deepcopy(result)
  while len(service.cache)>32:service.cache.popitem(last=False)
 return result
