"""Read-only data ablation. No production model or frontend modifications."""
import json,time,csv,hashlib
from pathlib import Path
import numpy as np
from algorithms.service import Service
from algorithms.vulnerability import PhysicsModel
from algorithms.impact import scenario_impact
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'reports/ablation';OUT.mkdir(exist_ok=True)
def main():
 started=time.perf_counter();svc=Service();model=PhysicsModel(svc.d,svc.features)
 # Five different circuits selected deterministically by available reachable tree records.
 candidates=[]
 for circuit,scope in sorted(svc.circuits.items()):
  ids=sorted({n for i in scope for n in model.by_customer[i]})
  if ids:
   xy=np.array([svc.d['assets'][model.nodes[n]['asset']]['xy'] for n in ids])
   count=sum(map(len,svc.features.tree.query_ball_point(xy,28)))
   candidates.append((count,circuit,ids,scope))
 chosen=sorted(candidates,key=lambda x:(-x[0],x[1]))[:5]
 rows=[]
 for count,circuit,ids,scope in chosen:
  original=model.context(ids);location=svc.d['customers'][scope[0]];lng,lat=svc.features.project.transform(0,0) if False else svc.d['assets'][model.nodes[ids[0]]['asset']]['lnglat']
  for gust,direction in [(0,0),(40,90),(81,297),(100,180)]:
   weather={'gustMph':gust,'windDirection':direction,'date':'2012-06-29','source':'explicit sensitivity scenario'};feature=svc.features.at(lng,lat,weather);raw={'windDirection':direction};outputs={}
   for variant in ['wind_only','wind_direction','wind_direction_trees','full_context']:
    contexts=[]
    for c in original:
     v=dict(c);v['group']=dict(c['group'])
     if variant=='wind_only':v['group']['bearings']=[]
     if variant in ['wind_only','wind_direction']:v['pairs']=[]
     contexts.append(v)
    model.cache[tuple(ids)]=contexts;t=time.perf_counter();p,lo,hi,details,method=model.predict(ids,weather,feature,raw)
    impact=scenario_impact(model.nodes,svc.d['customers'],scope,ids,p,128,20261024,.35)
    outputs[variant]={'impactPct':impact['expectedAffectedPercentage'],'ms':(time.perf_counter()-t)*1000,'treeExpectedSum':sum(d['treeContactScenarioProbability'] for d in details)}
   model.cache[tuple(ids)]=original
   a,b,c,d=[outputs[k] for k in ['wind_only','wind_direction','wind_direction_trees','full_context']]
   row={'case':len(rows)+1,'circuit':circuit,'date':'2012-06-29','gustMph':gust,'windDirection':direction,'customers':len(scope),'supports':len(ids),'nearbyTreeAssociations':count,'windOnlyPct':a['impactPct'],'directionPct':b['impactPct'],'treesPct':c['impactPct'],'fullContextPct':d['impactPct'],'treeDeltaPercentagePoints':c['impactPct']-b['impactPct'],'directionDeltaPercentagePoints':b['impactPct']-a['impactPct'],'terrainDeltaPercentagePoints':d['impactPct']-c['impactPct'],'windOnlyMs':a['ms'],'directionMs':b['ms'],'treesMs':c['ms'],'fullMs':d['ms'],'groundTruth':None,'accuracyImprovement':None}
   rows.append(row);print(json.dumps(row),flush=True)
 assert len(rows)==20
 assert all(abs(r['terrainDeltaPercentagePoints'])<1e-10 for r in rows)
 assert all(r['treeDeltaPercentagePoints']>=-1e-9 for r in rows)
 assert all(r['treesPct']==0 for r in rows if r['gustMph']==0)
 summary={'cases':20,'realOutcomeBacktests':0,'accuracyImprovement':None,'treeChangedCases':sum(r['treeDeltaPercentagePoints']>1e-10 for r in rows),'maxTreeChangePercentagePoints':max(r['treeDeltaPercentagePoints'] for r in rows),'maxDirectionChangePercentagePoints':max(abs(r['directionDeltaPercentagePoints']) for r in rows),'medianFullMs':float(np.median([r['fullMs'] for r in rows])),'seconds':time.perf_counter()-started,'labelGate':svc.d['audit'].get('labelGate'),'selection':'Five circuits ranked by nearby tree associations; deliberately tree-rich, not representative of full region','timing':'Single execution per variant, shared static context cache warmed; includes 128-trial impact simulation; excludes service startup, context extraction and ERT. Ordered runs may bias timing.','terrain':'Context-only in current production model; no numerical risk multiplier','checks':['20 completed','zero wind gives zero modeled wind/tree impact','adding tree term never lowers impact','terrain context leaves numerical prediction unchanged'],'sourceHashes':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['algorithms/vulnerability.py','algorithms/impact.py','private/algorithm/network.pkl']}}
 (OUT/'results.json').write_text(json.dumps({'summary':summary,'cases':rows},indent=2))
 with (OUT/'results.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
 lines=['# 树木与风向消融实验 / Tree and wind-direction ablation','', '**准确率提升：未知。没有真实客户停电结果，不能计算。 / Accuracy gain: unknown; no observed customer outcomes.**','', '使用同一生产物理模型、真实客户依赖、相同128次模拟与种子，20组受控情景。保留电杆等级与相数，逐步加入线路方向和树木接触项。基础模型方向未知时采用现有最大横风默认；它不是旧版v2。','Same production model, topology and random seed. Baseline retains pole class/phase and uses existing maximum-crosswind fallback, then adds actual line orientation and LiDAR contact exposure. This is not a v2 benchmark.','', '五条线路按附近树木关联数量选取，偏向有树区域；不代表区域总体。日期为统一条件，天气为人工控制输入，非历史回测。','Five tree-rich circuits selected intentionally; synthetic hazards on real GIS, not historical outcome backtests.','', '|Case|Circuit|Gust mph|Wind-only %|+ direction %|+ trees %|Tree change pp|Full ms|','|---|---|---:|---:|---:|---:|---:|---:|']
 for r in rows:lines.append(f"|{r['case']}|{r['circuit']}|{r['gustMph']}|{r['windOnlyPct']:.6f}|{r['directionPct']:.6f}|{r['treesPct']:.6f}|{r['treeDeltaPercentagePoints']:.6f}|{r['fullMs']:.2f}|")
 lines+=['','## Interpretation / 解释',f"加入树木改变了 {summary['treeChangedCases']}/20 组结果；最大变化 {summary['maxTreeChangePercentagePoints']:.6f} 个百分点。这是模型敏感性，不是准确率提升。",'Trees changed modeled exposure, not measured accuracy. Terrain, rain-soil coupling and asset aging currently have no calibrated risk multiplier; adding them cannot honestly be reported as numerical accuracy gains.','地形提供环境解释；当前不直接放大风险。原始损坏阳性记录缺完整暴露分母、负样本与逐户停复电标签，不能替代真值。','运行时间只含风险与影响模拟，不含ERT；不把顺序执行产生的缓存优势当成速度提升。','',json.dumps(summary,ensure_ascii=False,indent=2)]
 (OUT/'Report-中英文.md').write_text('\n'.join(lines));print('SUMMARY',json.dumps(summary,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
