"""Four documented regional storms, actual reanalysis inputs, explicit replay."""
from pathlib import Path
import json,urllib.request,urllib.parse,concurrent.futures
ROOT=Path(__file__).resolve().parents[1]
EVENTS=[
 {'title':'2012 Derecho','date':'2012-06-29','type':'thunder','icon':'bolt','code':95,'gustObservedMph':81,'source':'https://www.weather.gov/media/publications/assessments/derecho12.pdf','sourceNote':'Roanoke ASOS peak gust 81 mph, NWS assessment p.8. Region-wide application is a replay assumption.'},
 {'title':'Helene','date':'2024-09-27','type':'rain','icon':'rain','code':65,'source':'https://www.nhc.noaa.gov/data/tcr/AL092024_Helene.pdf','sourceNote':'Regional event documented by NHC; selected-site hourly weather is Open-Meteo reanalysis, not station truth.'},
 {'title':'Michael','date':'2018-10-11','type':'wind','icon':'wind','code':3,'source':'https://www.weather.gov/rnk/pastevents','sourceNote':'NWS Blacksburg regional October 10–12 Michael event; selected-site reanalysis used for replay.'},
 {'title':'December snow','date':'2018-12-09','type':'snow','icon':'snow','code':75,'snowObservedCm':38.1,'source':'https://www.nesdis.noaa.gov/news/record-december-snowfall-the-mid-atlantic','sourceNote':'NOAA documents 15 inches in Roanoke on Dec 9; wind and temperature from selected-site reanalysis. Snow damage model incomplete.'}]
def fetch(event):
 params={'latitude':37.27,'longitude':-79.94,'start_date':event['date'],'end_date':event['date'],'hourly':'temperature_2m,wind_gusts_10m,wind_direction_10m,rain,snowfall,weather_code','wind_speed_unit':'mph','temperature_unit':'fahrenheit','timezone':'America/New_York'};url='https://archive-api.open-meteo.com/v1/archive?'+urllib.parse.urlencode(params)
 with urllib.request.urlopen(url,timeout=45) as r:raw=json.load(r)
 h=raw['hourly'];i=max(range(len(h['time'])),key=lambda j:h['wind_gusts_10m'][j] or 0)
 gust=event.get('gustObservedMph',h['wind_gusts_10m'][i]);snow=event.get('snowObservedCm',sum(v or 0 for v in h['snowfall']))
 out={**event,'temp':round(h['temperature_2m'][i]),'gust':gust,'direction':h['wind_direction_10m'][i],'rainMm':round(sum(v or 0 for v in h['rain']),2),'snowfallCm':snow,'rain':None,'precip':f'{gust:g} mph gusts','weatherUrl':url,'weatherHour':h['time'][i],'weatherSource':'Open-Meteo reanalysis; regional uniform replay, not observed storm footprint','asset':'pole','quantity':3,'crews':3,'upstream':1,'accessDelay':1,'access':False,'summary':event['sourceNote']}
 return out,raw
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(fetch,EVENTS))
 events=[r[0] for r in results];(ROOT/'public/data/demo-events.json').write_text(json.dumps(events,indent=2));(ROOT/'private/algorithm/demo-event-weather.json').write_text(json.dumps([r[1] for r in results]));print([(e['title'],e['date'],e['gust'],e['temp'],e['snowfallCm']) for e in events])
