"""20 reproducible real-data contextual replays / explicitly synthetic scenarios."""
import sys,json,time,csv,datetime,statistics,platform
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from engine import evaluate
from algorithms.service import get_service
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'reports'
def main():
 d=json.loads((ROOT/'private/data.json').read_text());d['premiseIndex']={p['id']:p for p in d['premises']};d['circuitIndex']={p['id']:p for p in d['circuits']};svc=get_service();net=svc.d;cases=[];used=set()
 # Actual positive damage reports, with unverified spatial asset identity explicitly assumed.
 for report in net['damage']:
  a=report.get('candidate');r=report['attributes'];dt=r.get('Report_Tim','')[:8]
  if not a or a['distanceM']>1 or dt[:4] not in ['2024','2025']:continue
  asset=net['assets'][a['asset']]
  if asset['kind'] not in ['transformer','fuse','switch','recloser'] or not asset['nodes']:continue
  key=(dt[:6],asset['kind'])
  if key in used:continue
  try:date=datetime.datetime.strptime(dt,'%Y%m%d').date().isoformat()
  except ValueError:continue
  used.add(key);node=asset['nodes'][0];cust=int(net['nodes'][node]['customers'][0]);p=net['customers'][cust]
  cases.append({'id':f'H{len(cases)+1:02}','type':'historical_context_replay_NOT_outcome_backtest','hazard':'Actual report date + reanalysis weather; incident hour unknown','sourceDamage':report['id'],'associationDistanceM':a['distanceM'],'scenario':{'contextType':'premise','contextId':p['id'],'asset':asset['kind'],'failedNodes':[node],'date':date,'historicalWeather':True,'quantity':1,'upstream':0,'crews':2+(len(cases)%3),'seed':20261024+len(cases)},'truth':'Actual positive damage report only; snapped asset identity unverified. Customer outages, repair hours and ERT ground truth unavailable.'})
  if len(cases)==8:break
 locations=[(37.27,-79.94),(37.29,-80.05),(37.28,-79.90),(37.23,-80.01),(37.12,-80.17),(37.43,-80.08),(37.43,-79.78),(37.25,-79.73),(37.07,-79.82),(37.38,-80.20),(37.20,-79.85),(37.32,-79.98)]
 hazards=[('Rain',40,225,50,0,False),('Wind east',70,90,3,0,False),('Wind west',70,270,3,0,False),('Snow',55,315,0,30,False),('Freezing rain',35,45,20,0,True),('Severe gust',95,180,65,0,False),('Mountain access',60,300,40,5,False),('Few crews',75,210,30,0,False),('Clear calm',8,0,0,0,False),('Outside tree coverage',65,135,10,0,False),('Missing conductor labor',60,180,25,20,False),('No damaged tasks',15,15,0,0,False)]
 for i,(loc,h) in enumerate(zip(locations,hazards)):
  name,gust,direction,rain,snow,ice=h;lat,lng=loc;kind='wire' if i==10 else 'transformer' if i%3!=1 else 'fuse';count=0 if i==11 else 2+i%5
  s={'contextType':'map','lat':lat,'lng':lng,'asset':kind,'quantity':count,'upstream':0,'date':f'2025-{(i%12)+1:02}-15','wind':gust,'windDirection':direction,'rainMm':rain,'snowfallCm':snow,'freezingRain':ice,'crews':1 if i==7 else 3,'accessDelay':8 if i==6 else 1,'access':i in [4,6],'seed':20261100+i,'crewRange':[1,4] if i==7 else [3,3],'accessDelayRange':[4,12] if i==6 else [1,1]}
  cases.append({'id':f'S{i+1:02}','type':'synthetic_hazard_on_real_network','hazard':name,'scenario':s,'truth':'No observed outcome: weather and failures are explicit scenario inputs.'})
 rows=[];details=[]
 for case in cases:
  samples=[];r=None
  for _ in range(3):
   svc.cache.clear();start=time.perf_counter();r=evaluate(case['scenario'],d);samples.append((time.perf_counter()-start)*1000)
  start=time.perf_counter();evaluate(case['scenario'],d);cached=(time.perf_counter()-start)*1000
  impact=r['impact'];ert=r['ert'];p=r['physicsFeatures'];sch=ert.get('schedules',[{}])[0] if ert.get('schedules') else {};ci=impact.get('scenarioInterval95Percentage');reference=None
  if case['scenario'].get('failedNodes'):
   failed=set(case['scenario']['failedNodes']);ref=[c for c in net['customers'] if c['circuit']==r['scopeCircuit']];reference=sum(bool(failed.intersection(c['path'])) for c in ref)/len(ref)*100
  row={'case':case['id'],'type':case['type'],'place':r['scopeCircuit']+f" ({r['location']['lat']:.2f},{r['location']['lng']:.2f})",'date':case['scenario']['date'],'hazard':case['hazard'],'unconditionalOutageProbability':None,'conditionalImpactPct':impact['expectedAffectedPercentage'],'scenarioLowPct':ci[0] if ci else None,'scenarioHighPct':ci[1] if ci else None,'ertLowH':ert['low'],'ertHighH':ert['high'],'runtimeMedianMs':statistics.median(samples),'runtimeMaxMs':max(samples),'cacheMs':cached,'actualOutagePct':None,'actualERT_H':None,'forecastError':None,'confidence':'Unvalidated; scenario interval only','sourcePathReferencePct':reference,'sourcePathDifferencePct':None if reference is None else abs(reference-impact['expectedAffectedPercentage']),'fifoObjective':sch.get('fifoObjective'),'optimizedObjective':sch.get('objective'),'objectiveImprovement':sch.get('improvementAgainstFIFO'),'treeCoverage':'partial_bounds' if p['lidar']['withinSourceBounds'] else 'missing_outside_bounds','slopeDeg':p['terrain'].get('slopeDeg'),'elevationM':p['terrain'].get('elevationM'),'gustMph':p['weather'].get('gustMph'),'failureReason':'; '.join(impact['warnings'][:1])+(' '+ert['reason'] if ert.get('reason') else ''),'truth':case['truth']}
  rows.append(row);details.append({'case':case,'metrics':row,'result':r});print(case['id'],round(row['runtimeMedianMs'],1),row['conditionalImpactPct'],row['ertHighH'],flush=True)
 with (OUT/'20-cases.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
 (OUT/'20-cases.json').write_text(json.dumps(details,indent=2,allow_nan=False))
 summary={'generatedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'platform':platform.platform(),'python':platform.python_version(),'seedBase':20261024,'caseCount':len(rows),'realContextReplays':sum(r['type'].startswith('historical') for r in rows),'trueOutageOutcomeBacktests':0,'scenarioTests':sum(r['type'].startswith('synthetic') for r in rows),'unconditionalAccuracy':None,'ertMAE':None,'medianUncachedMs':statistics.median(r['runtimeMedianMs'] for r in rows),'p95UncachedMs':float(np.quantile([r['runtimeMedianMs'] for r in rows],.95)),'medianCachedMs':statistics.median(r['cacheMs'] for r in rows),'maxSourcePathDifferencePct':max(r['sourcePathDifferencePct'] or 0 for r in rows),'coldStartupSeconds':svc.startupSeconds,'audit':svc.d['audit']}
 (OUT/'benchmark-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k!='audit'},indent=2))
if __name__=='__main__':main()
