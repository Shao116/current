# current 最终界面验证 / Final UI verification

Risk 使用全区域连续栅格，颜色来自逐客户上游路径的同一物理风险模型；不是客户点或历史报告的密度。可视化使用8个最近的已建模客户进行逆距离插值、1.5像素平滑；只在3公里邻域及客户覆盖凸包内着色，缺失模型覆盖显示灰色。插值只用于显示，不推断电气连接，也不是验证过的空间概率。点击 Risk 自动适配整个提供数据区域，任何缩放级别保留栅格。

Risk is a continuous regional raster of expected customer impact, not point density. Eight-neighbor inverse-distance display interpolation and 1.5-pixel smoothing are limited to within 3 km of modeled customers and the source hull. Gray means unsupported coverage. Display interpolation never creates electrical connections or calibrated spatial probabilities.

分级 / Product planning bands: <1% Limited, 1–5% Moderate, 5–15% Elevated, 15–30% High, ≥30% Severe. 4.2% = 每1000户约42户，是中等“影响范围”，不是单户已验证的停电概率。这些分界为解释性产品设计，不是主办方或科学验证过的危险标准。危险阵风单独提示，不因影响百分比小就推断天气安全。冬季显示 Wind/tree only，不虚构雪冰风险。

Four documented historical event replays:
- 2012-06-29 Derecho: Roanoke measured 81 mph gust, [NWS assessment](https://www.weather.gov/media/publications/assessments/derecho12.pdf). Other selected-site inputs are reanalysis; the model applies a uniform regional vector, not an observed storm track.
- 2024-09-27 Helene: [NHC report](https://www.nhc.noaa.gov/data/tcr/AL092024_Helene.pdf); selected-site weather from Open-Meteo reanalysis.
- 2018-10-11 Michael: [NWS regional archive](https://www.weather.gov/rnk/pastevents); selected-site weather from reanalysis.
- 2018-12-09 snow: [NOAA record](https://www.nesdis.noaa.gov/news/record-december-snowfall-the-mid-atlantic) reports 15 inches in Roanoke; wind/temperature from reanalysis. Snow damage remains unquantified.

事件不是连续四天。删除 Demo 的 Tomorrow/Final demo day 第二个格子。历史天气作用于当前提供的电网；故障和恢复为模拟，没有真实结果回测。所有来源与原始 reanalysis 请求在 public/data/demo-events.json；复现脚本 algorithms/acquire_demo_events.py。

LOCAL WEATHER 后的可调变量 / Adjustable factors:
- Household usable battery Wh and essential-device W: runtime = Wh/W. No invented efficiency factor; available usable energy is user input. Compare only with an explicitly selected customer's conditional window, never regional workload as a home ETA.
- Optional repair response scenarios: crews/access constraints and explicit damage assumptions; not bookings or actual utility dispatch controls. Weather is read-only in these controls.

73 Python regression/unit tests pass. Four historical demo API checks pass. reports/final/actual-tests.json records four full-region rasters, 3 crew scenarios, and 3 wind sensitivities with real measured runtimes; none are true historical outage backtests. 4.2% classification, unknown/gray coverage, raster-density independence, and equality with the existing topology model are tested.

NWS severe thunderstorm wind reference: [58 mph gust threshold](https://www.weather.gov/safety/thunderstorm). This is weather hazard context, not a calibrated outage percentage cutoff or a claim of an active warning.

Browser verification: Risk opens a regional raster at overview scale; last historical event hides the second weather card; changing household usable battery 1,000→2,000 Wh at 100 W updates runtime 10→20h without changing impact. The 81 mph recorded gust is preserved exactly in API inputs (no range-slider rounding). Customer hit targets remain selectable at street zoom without visible dots on Risk.
