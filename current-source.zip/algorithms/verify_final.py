"""Actual regional raster, band and repair sensitivity checks; never outcome accuracy."""
from pathlib import Path
import sys,json,time,urllib.request,base64,io
from PIL import Image
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from algorithms.risk_surface import band
BASE='http://127.0.0.1:8765'
def post(path,s):
 request=urllib.request.Request(BASE+path,data=json.dumps({'scenario':s}).encode(),headers={'Content-Type':'application/json'});t=time.perf_counter()
 with urllib.request.urlopen(request,timeout=120) as r:d=json.load(r)
 return d,(time.perf_counter()-t)*1000
if __name__=='__main__':
 events=json.loads((ROOT/'public/data/demo-events.json').read_text());out=[]
 for event in events:
  s={'predictionMode':'weather','contextType':'premise','contextId':'P-020015','date':event['date'],'wind':event['gust'],'windDirection':event['direction'],'snowfallCm':event['snowfallCm'],'rainMm':event['rainMm'],'crews':3,'accessDelay':1}
  d,ms=post('/api/risk-surface',s);warm,cachems=post('/api/risk-surface',s);assert d['image']==warm['image'];assert warm['performance']['cacheHit'];image=Image.open(io.BytesIO(base64.b64decode(d['image'].split(',')[1])));colors=len(image.getcolors(image.width*image.height));assert image.size==(400,300);assert colors>10;assert d['totalCustomers']==117642;assert d['modeledCustomers']>100000
  r,_=post('/api/evaluate',s);row={'event':event['title'],'date':event['date'],'regionalExpectedPct':d['expectedAffectedPercentage'],'circuitExpectedPct':r['impact']['expectedAffectedPercentage'],'planningBand':band(r['impact']['expectedAffectedPercentage'])['label'],'ERTLow':r['ert']['low'],'ERTHigh':r['ert']['high'],'surfaceMs':ms,'cachedSurfaceMs':cachems,'distinctRGBA':colors,'winterPartial':d['winterPartial'],'realOutcomeBacktest':False};out.append(row);print(row,flush=True)
 first=events[0]
 for crews in [1,3,6]:
  s={'predictionMode':'conditional','contextType':'premise','contextId':'P-020015','asset':'pole','quantity':3,'upstream':1,'crews':crews,'accessDelay':1,'repairCV':0,'wind':first['gust'],'date':first['date'],'windDirection':first['direction']};r,ms=post('/api/evaluate',s);row={'case':'crew sensitivity','crews':crews,'ERTLow':r['ert']['low'],'ERTHigh':r['ert']['high'],'ms':ms,'realOutcomeBacktest':False};out.append(row);print(row,flush=True)
 for wind in [0,40,81]:
  s={'predictionMode':'weather','contextType':'premise','contextId':'P-020015','wind':wind,'date':first['date'],'windDirection':first['direction'],'crews':3};r,ms=post('/api/evaluate',s);row={'case':'wind sensitivity','wind':wind,'circuitExpectedPct':r['impact']['expectedAffectedPercentage'],'band':band(r['impact']['expectedAffectedPercentage'])['label'],'ms':ms,'realOutcomeBacktest':False};out.append(row);print(row,flush=True)
 (ROOT/'reports/final/actual-tests.json').write_text(json.dumps(out,indent=2));print('Actual regional heatmap and parameter tests passed.',flush=True)
