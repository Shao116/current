"""Exact workbook selectors and GIS specification evidence; no inferred damage."""
import json,math,re
from pathlib import Path
CATALOG=json.loads((Path(__file__).parent/'labor_catalog.json').read_text())
DRAWINGS=json.loads((Path(__file__).parent/'drawings.json').read_text())
def number(v,name,positive=False):
 if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v<(1e-12 if positive else 0):raise ValueError('Invalid '+name)
 return v

def select_rate(kind,size,component,attributes=None):
 """Only explicitly requested or actually observed specs select a row.
 No nearest-kVA interpolation, total-bank-kVA/phase-count guesses, or CU inference.
 """
 attributes=attributes or {};source=None;note=None;rate=None
 if component.get('cu') is not None:
  if not isinstance(component['cu'],str):raise ValueError('Connector CU must be a string')
  source=CATALOG['connectors'].get(component['cu'])
  if source is None:raise ValueError('Unknown connector CU')
  if kind!='connector':raise ValueError('Connector CU requires kind=connector')
 elif kind=='transformer':
  kva=component.get('kva');observed=[]
  if kva is not None:
   number(kva,'transformer kVA',positive=True);observed=[float(kva)]
  elif attributes:
   for key in ['a_phase_sp','b_phase_sp','c_phase_sp']:
    text=attributes.get(key,'');m=re.search(r'(?i)\b(\d+(?:\.\d+)?)\s*kVA\b',text)
    if m:observed.append(float(m.group(1)))
  if observed:
   rows=[CATALOG['transformerKVA'].get(format(k,'g')) for k in observed]
   if all(rows):
    rate=(sum(r['install'] for r in rows),sum(r['remove'] for r in rows));source={'sheet':'Labor time material related','rows':[r['row'] for r in rows],'kvaPerUnit':observed};note='All parsed phase units replaced: explicit transformer-bank replacement scenario.' if len(observed)>1 else 'Supplied per-phase GIS kVA or explicit kVA selects exact workbook row.'
   elif kva is not None:raise ValueError('No exact workbook transformer kVA row; supply documented component repair hours instead')
   else:note='Observed GIS kVA has no exact workbook row; declared 50 kVA fallback retained, not locally observed labor.'
  if rate is None:source=CATALOG['transformerKVA']['50'];note=note or 'Default 50 kVA reference; actual transformer specification unavailable.'
 elif kind=='pole':source=CATALOG['poleSizes'].get(size)
 else:source=CATALOG['material'].get(kind)
 if source and rate is None:rate=(source['install'],source['remove'])
 return rate,source,note

def adder_hours(adders,restricted=False):
 if not isinstance(adders,list) or len(adders)>20:raise ValueError('Invalid laborAdders')
 seen=set();hours=0.;details=[]
 # Boolean legacy access flag maps to exactly one workbook row, never twice.
 entries=list(adders)
 if restricted and not any(isinstance(a,dict) and a.get('name')=='Difficult Location' for a in entries):entries.append({'name':'Difficult Location','quantity':1})
 for a in entries:
  if not isinstance(a,dict) or not isinstance(a.get('name'),str) or a.get('name') not in CATALOG['adders']:raise ValueError('Unknown workbook labor adder')
  name=a['name']
  if name in seen:raise ValueError('Duplicate labor adder')
  seen.add(name);row=CATALOG['adders'][name];q=number(a.get('quantity',1),'labor adder quantity')
  if row['hours'] is None:raise ValueError('Workbook labor adder has no supplied duration')
  if row['unit']=='per cubic foot' and a.get('unit')!='cubic_feet':raise ValueError('Excavation adder requires measured cubic_feet quantity')
  if row['unit']!='per cubic foot' and q!=int(q):raise ValueError('Occurrence adder quantity must be a whole number')
  h=row['hours']*q;hours+=h;details.append({'name':name,'quantity':q,'hours':h,'unit':row['unit'],'sourceSheet':row['sheet'],'sourceRow':row['row']})
 return hours,details

def drawing_reference(page):
 if page is None:return None
 if isinstance(page,bool) or not isinstance(page,int) or not 1<=page<=9:raise ValueError('drawingPage must be 1–9')
 return {**DRAWINGS['pages'][page-1],'source':DRAWINGS['source'],'basis':'Caller-selected reference only; not a verified asset assembly or automatic bill of materials'}
