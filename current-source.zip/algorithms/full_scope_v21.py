"""Actually exercise weather prediction and ERT over all supplied customers."""
import sys,json,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from engine import evaluate
from algorithms.service import get_service
ROOT=Path(__file__).resolve().parents[1];d=json.loads((ROOT/'private/data.json').read_text());d['premiseIndex']={p['id']:p for p in d['premises']};d['circuitIndex']={p['id']:p for p in d['circuits']}
t=time.perf_counter();r=evaluate({'predictionMode':'weather','scope':'all','wind':70,'windDirection':225,'crews':20,'trials':32,'seed':20261024},d);elapsed=time.perf_counter()-t
assert len(r['impact']['perCustomer'])==117642 and len(r['ert']['perCustomer'])==117642
assert r['ert']['status']=='engineering_restoration_ensemble'
assert r['impact']['unconditionalProbabilityAvailable'] is False
t=time.perf_counter();cached=evaluate({'predictionMode':'weather','scope':'all','wind':70,'windDirection':225,'crews':20,'trials':32,'seed':20261024},d);cache_seconds=time.perf_counter()-t;assert cached['performance']['cacheHit']
x={'cachedSeconds':cache_seconds,'scopeCustomers':117642,'impactCustomerRows':len(r['impact']['perCustomer']),'ertCustomerRows':len(r['ert']['perCustomer']),'referenceModelAffectedPercentage':r['impact']['expectedAffectedPercentage'],'workloadP10P90Hours':[r['ert']['low'],r['ert']['high']],'sampledRepairScenarios':r['ert']['uncertainty']['samples'],'secondsIncludingColdInitialization':elapsed,'engineSeconds':r['performance']['seconds'],'status':'PASS','calibrated':False,'source':'Real GIS; explicit 70mph/20-crew reference-model scenario, no observed outcome'}
(ROOT/'reports/v21/full-scope-check.json').write_text(json.dumps(x,indent=2));print(json.dumps(x,indent=2))
