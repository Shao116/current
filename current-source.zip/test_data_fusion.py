import unittest,math
import numpy as np
from types import SimpleNamespace
from algorithms.restoration import labor
from algorithms.component_evidence import CATALOG,drawing_reference
from algorithms.vulnerability import PhysicsModel
class FusionTests(unittest.TestCase):
 def test_transformer_exact_kva(self):
  a=labor('transformer',components=[{'kind':'transformer','kva':25}]);b=labor('transformer',components=[{'kind':'transformer','kva':500}]);self.assertLess(a['taskHours'],b['taskHours']);self.assertEqual(a['components'][0]['rateSource']['rows'],[21])
 def test_actual_gis_bank_specs(self):
  attrs={'a_phase_sp':'25 kVA XFR PL','b_phase_sp':'75 kVA XFR PL','c_phase_sp':''};r=labor('transformer',asset_attributes=attrs);self.assertEqual(r['components'][0]['rateSource']['kvaPerUnit'],[25.,75.]);self.assertIn('bank',r['components'][0]['assumption']);self.assertAlmostEqual(r['taskHours'],sum(sum(CATALOG['transformerKVA'][k][f] for f in ['install','remove']) for k in ['25','75'])*4.5)
 def test_unmatched_explicit_kva_rejected(self):
  with self.assertRaises(ValueError):labor('transformer',components=[{'kind':'transformer','kva':37.5}])
 def test_unmatched_gis_fallback_disclosed(self):
  r=labor('transformer',asset_attributes={'a_phase_sp':'37.5 kVA XFR PL'});self.assertIn('fallback',r['components'][0]['assumption'])
 def test_every_connector_row_selectable(self):
  for code,v in CATALOG['connectors'].items():
   r=labor('pole',components=[{'kind':'connector','cu':code,'quantity':2}]);self.assertAlmostEqual(r['taskHours'],2*(v['install']+v['remove'])*4.5)
 def test_access_not_double_counted(self):
  a=labor('pole',access=True);b=labor('pole',access=True,labor_adders=[{'name':'Difficult Location','quantity':1}]);self.assertEqual(a['taskHours'],b['taskHours']);self.assertEqual(len(b['laborAdders']),1)
 def test_excavation_units_required(self):
  with self.assertRaises(ValueError):labor('pole',labor_adders=[{'name':'Hand Dig','quantity':3}])
  base=labor('pole')['taskHours'];r=labor('pole',labor_adders=[{'name':'Hand Dig','quantity':3,'unit':'cubic_feet'}]);self.assertAlmostEqual(r['taskHours']-base,1.5*3*4.5)
 def test_missing_workbook_duration_not_invented(self):
  with self.assertRaises(ValueError):labor('pole',labor_adders=[{'name':'Junction Pole Work'}])
 def test_drawings_do_not_invent_components(self):
  for page in range(1,10):
   a=labor('pole');b=labor('pole',drawing_page=page);self.assertEqual(a['taskHours'],b['taskHours']);self.assertEqual(b['drawingReference']['page'],page)
  with self.assertRaises(ValueError):drawing_reference(10)
 def test_both_endpoints_and_no_spatial_routing(self):
  p=lambda ident,x:{'id':ident,'kind':'pole','xy':(x,0),'attributes':{'location_n':ident,'material':'Pine','height':'35 Feet','class':'4'}}
  # Reversed geometry: each supplied endpoint may occur at either end.
  a=[p('one',0),p('two',100),{'id':'wire','kind':'wire','attributes':{'location_n':'one','location_1':'two','mounting':'Overhead'},'geometry':[[100,0],[0,0]]}]
  d={'assets':a,'nodes':{'n1':{'asset':0,'customers':np.array([0])},'n2':{'asset':1,'customers':np.array([1])}},'customers':[{},{}]};f=SimpleNamespace(project=SimpleNamespace(transform=lambda x,y:(x,y)));m=PhysicsModel(d,f)
  self.assertEqual(m.audit['orientationAvailable'],2);self.assertEqual(set(m.nodes['S-one']['customers']),{0});self.assertEqual(set(m.nodes['S-two']['customers']),{1})
if __name__=='__main__':unittest.main()
