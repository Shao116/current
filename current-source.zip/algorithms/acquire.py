"""Cache public environmental inputs with source URLs and retrieval times."""
from pathlib import Path
import urllib.request,urllib.parse,json,datetime,hashlib
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'private/algorithm';OUT.mkdir(exist_ok=True)
def fetch(url,path,timeout=50):
 if path.exists():return
 try:
  with urllib.request.urlopen(url,timeout=timeout) as r:b=r.read()
  if b.startswith(b'{') and path.suffix=='.tif':raise ValueError(b[:400].decode())
  path.write_bytes(b);(Path(str(path)+'.source.json')).write_text(json.dumps({'url':url,'retrievedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sha256':hashlib.sha256(b).hexdigest()},indent=2))
  print(path.name,len(b),flush=True)
 except Exception as e:print(path.name,'UNAVAILABLE',str(e),flush=True)
def main():
 url='https://elevation.nationalmap.gov/arcgis/rest/services/3DEPElevation/ImageServer/exportImage?'+urllib.parse.urlencode({'f':'image','bbox':'-80.30,36.96,-79.59,37.52','bboxSR':4326,'imageSR':26917,'size':'1600,1600','format':'tiff','pixelType':'F32','renderingRule':json.dumps({'rasterFunction':'None'}),'interpolation':'RSP_BilinearInterpolation'})
 fetch(url,OUT/'dem.tif')
 # Real reanalysis, not station observation; collect whole dates, no guessed incident hour.
 for year in [2024,2025]:
  q={'latitude':'37.27,37.10,37.44','longitude':'-79.94,-80.12,-79.74','start_date':f'{year}-01-01','end_date':f'{year}-12-31','hourly':'temperature_2m,precipitation,rain,snowfall,snow_depth,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m','timezone':'UTC'}
  fetch('https://archive-api.open-meteo.com/v1/archive?'+urllib.parse.urlencode(q),OUT/f'weather-{year}.json')
if __name__=='__main__':main()
