"""Event-separated XGBoost calibration and baseline gate; no fabricated negatives.
Input: one verified asset/event exposure row, features, damage label 0/1,
observed=True, event_id, timestamp. A missing damage report is NOT label 0.
"""
import json,hashlib
from pathlib import Path
import numpy as np
FEATURES=['dynamicPressurePa','crosswindMps','nearestTreeM','nearestTreeHeightM','pointsWithin100m','geometricDownwindReachCandidates','woodlandAreaFraction100m','elevationM','slopeDeg','terrainStdM','flatnessGradient','upwindHorizonDeg','opennessDeg','alongWindRise','rainMm','snowfallCm','snowDepthM','freezingRainIndicator','windSin','windCos','seasonalSin','seasonalCos']
def vector(f):
 w=f['weather'];l=f['lidar'];t=f['terrain'];s=f['seasonalWind'];d=np.radians(w.get('windDirection',0));season=np.radians(s.get('prevailingFromDeg',0))
 values={**f,**l,**t,**w,'windSin':np.sin(d),'windCos':np.cos(d),'seasonalSin':np.sin(season) if s.get('available') else None,'seasonalCos':np.cos(season) if s.get('available') else None}
 return [np.nan if values.get(k) is None else float(values[k]) for k in FEATURES]
def train(rows,out):
 from sklearn.metrics import brier_score_loss,log_loss,roc_auc_score,average_precision_score
 from sklearn.linear_model import LogisticRegression
 from sklearn.impute import SimpleImputer
 from sklearn.pipeline import make_pipeline
 from sklearn.preprocessing import StandardScaler
 from sklearn.isotonic import IsotonicRegression
 from xgboost import XGBClassifier
 import joblib
 if len(rows)<200 or not all(r.get('observed') is True and r.get('label') in [0,1] and r.get('asset_id') and r.get('event_id') and r.get('timestamp') for r in rows):raise ValueError('Need ≥200 verified observed asset-event exposure rows; explicit observed negatives, IDs and timestamps required')
 if len({(r['asset_id'],r['event_id']) for r in rows})!=len(rows):raise ValueError('Duplicate asset-event exposure labels')
 events=sorted({r['event_id'] for r in rows},key=lambda e:min(r['timestamp'] for r in rows if r['event_id']==e))
 if len(events)<10:raise ValueError('Need ≥10 independent events for chronological train/calibration/test separation')
 n=len(events);train_events=set(events[:int(n*.6)]);cal_events=set(events[int(n*.6):int(n*.8)]);test_events=set(events[int(n*.8):])
 # Ensure event windows do not overlap across chronological partitions.
 splits=[[r for r in rows if r['event_id'] in e] for e in [train_events,cal_events,test_events]]
 for left,right in zip(splits,splits[1:]):
  if max(r['timestamp'] for r in left)>=min(r['timestamp'] for r in right):raise ValueError('Overlapping event windows would leak across temporal splits')
 X=[];Y=[]
 for group in splits:
  y=np.array([r['label'] for r in group]);x=np.array([r['features'] for r in group],float)
  if x.shape[1]!=len(FEATURES) or len(np.unique(y))!=2:raise ValueError('Feature schema or per-split class support invalid')
  X.append(x);Y.append(y)
 model=XGBClassifier(n_estimators=160,max_depth=3,learning_rate=.04,subsample=.85,colsample_bytree=.85,tree_method='hist',n_jobs=2,random_state=20261024,eval_metric='logloss')
 model.fit(X[0],Y[0]);cal=IsotonicRegression(out_of_bounds='clip').fit(model.predict_proba(X[1])[:,1],Y[1]);p=np.clip(cal.predict(model.predict_proba(X[2])[:,1]),1e-6,1-1e-6)
 base=make_pipeline(SimpleImputer(add_indicator=True),StandardScaler(),LogisticRegression(max_iter=1000)).fit(X[0],Y[0]);bp=base.predict_proba(X[2])[:,1];constant=np.full(len(Y[2]),Y[0].mean())
 def metrics(p):return {'brier':float(brier_score_loss(Y[2],p)),'logLoss':float(log_loss(Y[2],p)),'rocAUC':float(roc_auc_score(Y[2],p)),'averagePrecision':float(average_precision_score(Y[2],p))}
 metrics_all={'xgboostCalibrated':metrics(p),'logisticBaseline':metrics(bp),'constantBaseline':metrics(constant)}
 # Event-cluster bootstrap prevents reporting individual correlated assets as independent evidence.
 rng=np.random.default_rng(20261024);ev=np.array([r['event_id'] for r in splits[2]]);delta=[];reference=bp if metrics_all['logisticBaseline']['brier']<metrics_all['constantBaseline']['brier'] else constant
 for _ in range(500):
  chosen=rng.choice(sorted(test_events),len(test_events),replace=True);ix=np.concatenate([np.flatnonzero(ev==e) for e in chosen]);delta.append(np.mean((p[ix]-Y[2][ix])**2-(reference[ix]-Y[2][ix])**2))
 ci=np.quantile(delta,[.025,.975]).tolist();approved=ci[1]<0 and metrics_all['xgboostCalibrated']['logLoss']<min(metrics_all[k]['logLoss'] for k in ['logisticBaseline','constantBaseline'])
 report={'schema':FEATURES,'splitEvents':[sorted(train_events),sorted(cal_events),sorted(test_events)],'metrics':metrics_all,'brierDeltaCI95':ci,'approved':approved,'gate':'Approve only if held-out log loss improves both baselines and event-bootstrap Brier-difference upper CI is below zero. This gate is not a guarantee of future accuracy.','nRows':len(rows),'dataSha256':hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest()}
 out=Path(out);out.mkdir(parents=True,exist_ok=True);joblib.dump({'model':model,'calibrator':cal,'report':report},out/'candidate.joblib');(out/'validation.json').write_text(json.dumps(report,indent=2));return report
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('labels');p.add_argument('--out',default='private/algorithm/model');a=p.parse_args();print(json.dumps(train(json.loads(Path(a.labels).read_text()),a.out),indent=2))

class Predictor:
 """Load only an evidence-gated artifact; explain pre-calibration model margins."""
 def __init__(self,path):
  import joblib
  self.bundle=joblib.load(path)
  if not self.bundle['report'].get('approved'):raise ValueError('Candidate failed baseline validation gate')
  if self.bundle['report']['schema']!=FEATURES:raise ValueError('Feature schema mismatch')
 def predict(self,features):
  from xgboost import DMatrix
  x=np.array([vector(f) for f in features]);m=self.bundle['model'];p=self.bundle['calibrator'].predict(m.predict_proba(x)[:,1]);contrib=m.get_booster().predict(DMatrix(x),pred_contribs=True)
  return [{'probability':float(v),'marginContributions':{k:float(c) for k,c in zip(FEATURES,row[:-1])},'marginBias':float(row[-1]),'explanation':'Additive contributions explain pre-calibration log-odds; not causal attribution or additive probability points.'} for v,row in zip(p,contrib)]
