# 数据融合改进 / Data fusion improvements

已核对用户提供目录的 106 个文件；四项核心输入哈希均与现有系统一致。ZIP 和解压副本不重复计数。并非全部字段都能转成有效的概率参数。

Audited 106 source files. All four core source hashes match current ingestion. Duplicate archives/extractions are not independent observations. Ingestion is not calibrated numerical use.

## 已实现 / Implemented

- 从五张 AEP 工时工作表生成带行号、哈希的运行时目录。95 connector CU codes, 14 material categories, 3 pole-size groups, 12 transformer size rows, 11 labor adders, 17 CU descriptions, workbook ILM.
- 变压器按明确指定或 GIS 各相 kVA 选择精确工时行；多相全更换是明确的维修情景，非确认损坏。没有精确匹配时保留显式默认，不做最近规格插值。Actual per-phase kVA selects exact workbook rows; full-bank replacement is a declared scenario.
- 挖掘附加工时要求输入 cubic_feet 数量，缺失工时项拒绝计算；受限通行附加避免重复。Explicit units, no invented missing rates, no duplicate legacy access adder.
- 使用架空主线两端已核验位置标识和 10m 几何检查计算迎风角；支持几何反向，不创造供电边。Both endpoint bearings, reversed geometries supported, no fabricated connectivity.
- 九页结构图可指定参考页，但不推断真实装配或自动生成受损部件。All nine drawing references selectable; no invented asset-specific bill of materials.
- API 返回 dataFusion 使用范围；地图图层来源面板提供数据使用与缺口清单。API and UI expose actual use and gaps.

## 实测 / Actual tests

69 项单元/回归测试通过；四天 Demo API 检查通过。69 unit/regression tests passed; four-day demo API integration passed.

{
  "cases": 24,
  "newMedianMs": 105.17933350638486,
  "newMedianCacheMs": 6.965270993532613,
  "numericOutputCases": 24,
  "impactChangedCases": 15,
  "ertChangedCases": 13,
  "actualOutcomeBacktests": 0,
  "accuracyImprovement": null,
  "runtimeComparisonCaveat": "One current uncached + one cached call; previous persisted v2.1 outputs are same-input prediction references, not fresh speed baselines."
}

|情景 / Case|旧影响% / Old impact|新影响% / New impact|旧维修h / Old repair|新维修h / New repair|运行ms / Runtime|
|---|---:|---:|---|---|---:|
|H01|0.3012048192771085|0.3012048192771085|7.98–14.870000000000001|7.98–14.870000000000001|3740.16|
|H02|1.947502116850127|1.947502116850127|2.005–3.4699999999999998|2.005–3.4699999999999998|82.81|
|H03|0.19193857965451058|0.19193857965451058|1.9–3.92|1.9–3.92|94.29|
|H04|0.31187978451942155|0.31187978451942155|1.75–3.3|1.75–3.3|154.41|
|H05|5.977796754910336|5.977796754910336|2.295–4.54|2.295–4.54|87.53|
|H06|0.24350649350649353|0.24350649350649353|6.904999999999999–15.555|6.904999999999999–15.555|84.80|
|H07|0.5535055350553504|0.5535055350553504|2.1500000000000004–4.21|2.1500000000000004–4.21|66.61|
|H08|0.9314140558848435|0.9314140558848435|2.0–3.7699999999999996|2.0–3.7699999999999996|84.40|
|W01|0.31270251381854014|0.2850179724091887|4.61–4.61|4.61–4.61|2880.69|
|W02|2.028829427055456|1.9557650224303318|2.866–20.202000000000005|2.8640000000000003–18.433999999999994|113.17|
|W03|1.8680772054197121|1.792185595064357|5.765000000000001–50.347999999999985|5.133–49.66799999999999|114.14|
|W04|0.8648355870556182|0.793965891218077|3.994–26.338000000000005|3.994–25.260000000000005|64.31|
|W05|0.6559287295815959|0.6387131265593232|4.585–92.61999999999999|6.6–132.2|218.27|
|W06|3.736926253349429|3.482631024539393|19.085–210.72|13.294–101.69200000000001|204.27|
|W07|1.2892279165543352|1.1976166841449576|6.487–66.41899999999998|7.787–85.44299999999998|134.75|
|W08|2.6232357367465955|2.484566744377295|21.74–834.655|16.55–805.05|364.28|
|W09|0.06465171185417706|0.06410976534902293|5.0040000000000004–9.116000000000001|5.0040000000000004–9.116000000000001|155.14|
|W10|1.4775505106711941|1.3891402597916411|4.218999999999999–54.02299999999997|4.167999999999999–61.01600000000002|101.08|
|W11|1.132469189609957|1.114840517680804|5.184–54.43999999999999|5.184–54.82899999999999|109.28|
|W12|0.0|0.0|0.0–0.0|0.0–0.0|30.45|
|E01|11.319672629882534|11.210067728542732|22.092–257.86400000000015|16.252–216.4660000000001|156.37|
|E02|2.6824640081299664|2.6789832214156304|6.343999999999999–47.76799999999998|6.398–36.36999999999998|98.80|
|E03|2.6824640081299664|2.6789832214156304|10.526–202.6729999999999|10.526–175.2899999999999|100.18|
|E04|1.3425764383505308|1.3437246532632199|4.758–47.85200000000002|5.103–52.98299999999999|86.40|

预测发生变化不代表误差改善；没有真实结果，因此不报告准确率。Changed predictions are not demonstrated accuracy improvements; no outcome truth is available.

## PINN 判断 / PINN decision

目前没有部署 PINN。PINN 需要明确物理方程、边界/初始条件和可识别参数；用模拟曲线训练网络只能证明它复现模拟，不能证明当地停电预测准确。现有解析脆弱性计算没有必要用神经网络近似。

PINN is not deployed. Reproducing a physics simulator with a network does not validate local outage probabilities. Add a PINN only for a well-defined physical subproblem and compare against its numerical solver and observed outcomes.

Research: [Misyris et al., PINNs for power systems](https://arxiv.org/abs/1911.03737) studies rotor-angle/frequency dynamics; this is not validation of storm outage probabilities. [Watson et al. 2024](https://doi.org/10.1109/ACCESS.2024.3396414) supports structural-vulnerability + ML integration, distinct from requiring PINN. [NHESS 2023](https://nhess.copernicus.org/articles/23/1665/2023/index.html) discusses outage prediction and uncertainty/extrapolation limitations.

## 尚不能解决 / Remaining gaps

- **Customer_Clip + matched_upstream [active]**: Exact customer locations and supplied upstream paths; critical LS flags for scheduling. Missing/conflicting paths remain audited.
- **Pole_Clip [active_partial]**: Material, class, height, unique shared location; installation date context only. No unvalidated age decay.
- **Primary_ExportFeatures [active_partial]**: Both verified overhead endpoint identifiers and geometry for exposure bearings; span length/context. No invented ampacity, resistance, or loading.
- **Secondary_ExportFeatures [ingested_partial]**: Private raw geometry and attributes retained; no full-span failure model or invented electrical routing.
- **Transformer_Clip [active_partial]**: Overhead support associations, source paths, actual phase kVA when exact workbook row exists; explicitly declared bank replacement. Missing specs retain stated fallback.
- **Fuse/Switch/Recloser [active_partial]**: Supplied upstream paths and exact task type/workbook rates; fuse support exposure. No claim of remote switching or verified tie feasibility.
- **Damage reports [context_not_calibration]**: Prior-date spatial context; no fabricated undamaged examples, hourly ERT outcomes, or negative labels.
- **Hospital/fire/ambulance [link_gap]**: 52 facilities ingested; critical customer mapping requires verified link, not nearest-neighbor electrical guesses.
- **Install_Labor_HackOHIO.xlsx [all_five_sheets_cataloged]**: 95 exact connector CUs,14 material categories,3 pole size ranges,12 transformer size rows,11 explicit adders (1 missing time rejected),17 descriptions and ILM. Only selected work applied; not all work assumed damaged.
- **structure_drawings.pdf [all_nine_pages_reference_catalog]**: Explicit selected drawing reference + declared components; no GIS-to-drawing key, no automatic BOM or full-assembly damage assumption.
- **LiDAR/OSM/canopy [active_partial]**: Downwind reachable LiDAR trees and heights; woodland context. Missing species, health and verified crowns; canopy units unverified, excluded from probability.
- **DEM [diagnostic]**: Elevation,slope,openness,windward/leeward context; no unsupported speed-up multiplier.
- **Weather [active_partial]**: Wind gust/direction + preceding-year seasonal reference. Rain,freeze,snow flagged; no unsupported accretion or soil-strength multipliers.
- **README/challenge documents [requirements_reference]**: Requirements and data interpretation, not numerical prediction parameters.
- **ZIP/extracted/duplicate copies [deduplicated_sources]**: File hashes recorded; duplicate copies never counted as extra customers, equipment or training evidence.

仍缺完整的设备×风暴事件暴露表、可靠未损坏样本、小时级客户停复电真值、覆冰厚度/土壤参数、设备机械状态及验证过的备用电源容量/保护数据。More complex models cannot manufacture these missing measurements. No claim of fully fused calibrated probability, highest accuracy, or official AEP estimates.
