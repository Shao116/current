"""Customer-specific risk and source-path display; no invented electrical edges."""
import math,re
from pyproj import Transformer
INVERSE=Transformer.from_crs(26917,4326,always_xy=True)
def customer_estimate(result,customer):
 if customer is None:return None
 ident=customer['id'];row=next((p for p in result['impact'].get('perCustomer',[]) if p['id']==ident),None);p=None
 if row is not None:
  p=row.get('scenarioOutageProbability')
  if p is None:p=row.get('conditionalOutageProbability')
  if p is None:p=row.get('outageProbability')
 available=isinstance(p,(int,float)) and math.isfinite(p)
 weather='riskAssessment' in result
 return {'id':ident,'available':available,'scenarioOutagePercentage':float(p)*100 if available else None,'calibratedOutageProbability':None,'basis':'Published-reference wind/tree scenario for this customer, NOT locally calibrated probability' if weather else 'Conditional on the explicitly assumed/known equipment failures','pathDevices':len(customer.get('path',[])),'weatherInput':result.get('physicsFeatures',{}).get('weather',{}),'scope':'Selected customer only; not circuit expected impact','confidence':'Unvalidated scenario estimate','winterPartial':result.get('riskAssessment',{}).get('status')=='partial_winter_hazard','topologyAvailable':bool(customer.get('path')),'modelCoverage':row.get('modeledSupportCoverage') if row else False,'reason':None if available else 'No supported failure exposure or matched customer path; unavailable is not zero risk'}

def supply_path(service,ident):
 if not isinstance(ident,str) or not re.fullmatch(r'P-\d{6}',ident):raise ValueError('Choose a valid anonymized customer')
 i=int(ident[2:])-1
 if not 0<=i<len(service.d['customers']) or service.d['customers'][i]['id']!=ident:raise ValueError('Unknown customer')
 customer=service.d['customers'][i];ordered=list(reversed(customer['path']));steps=[];features=[]
 for index,n in enumerate(ordered):
  node=service.d['nodes'][n];asset=service.d['assets'][node['asset']] if node.get('asset') is not None else None;kind=asset['kind'] if asset else None
  label={'transformer':'Transformer','fuse':'Fuse','switch':'Switch','recloser':'Recloser','pole':'Pole'}.get(kind,node['type']);coords=None
  if asset:
   # Equipment is generalized to 100m; account/address/critical flags never leave server.
   x,y=asset['xy'];coords=list(INVERSE.transform(round(x/100)*100,round(y/100)*100))
  step={'id':n,'label':label,'order':index+1,'coordinates':coords,'locationAvailable':coords is not None,'kind':'device'};steps.append(step)
 lng,lat=INVERSE.transform(*customer['xy']);steps.append({'id':ident,'label':'Your home','order':len(steps)+1,'coordinates':[lng,lat],'locationAvailable':True,'kind':'home'})
 if ordered:
  for index,step in enumerate(steps):
   if step['coordinates'] is not None:features.append({'type':'Feature','geometry':{'type':'Point','coordinates':step['coordinates']},'properties':{'id':step['id'],'label':step['label'],'order':step['order'],'kind':step['kind']}})
  for a,b in zip(steps,steps[1:]):
   # Adjacent source-path edges only: NEVER bridge a missing-location intermediate.
   if a['coordinates'] is not None and b['coordinates'] is not None:features.append({'type':'Feature','geometry':{'type':'LineString','coordinates':[a['coordinates'],b['coordinates']]},'properties':{'from':a['id'],'to':b['id'],'relationship':'supplied_upstream_dependency','surveyedCableRoute':False}})
 return {'customerId':ident,'circuit':customer['circuit'],'topologyAvailable':bool(ordered),'source':'Organizer matched_upstream source path, reversed only to show upstream → customer','direction':'Upstream equipment → home','steps':steps if ordered else [],'mappedDevices':sum(s['locationAvailable'] for s in steps if s['kind']=='device'),'totalDevices':len(ordered),'missingDeviceLocations':sum(not s['locationAvailable'] for s in steps if s['kind']=='device'),'geojson':{'type':'FeatureCollection','features':features},'geometryMeaning':'Equipment generalized to about 100m. Dashed connectors are recorded dependencies, not surveyed cable routes. Unlocated steps remain in the list; generation plant and full substation feed are not supplied.'}
