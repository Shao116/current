# Report 1 · 数据、算法与结果 / Data, algorithms and outputs

版本 Version: current algorithms v2 · 2026-10-24

## 中文

### 1. 这次实际修复了什么

旧版把风速、历史损坏密度、上游设备数、访问条件加成一个分数，再用 −25%/+40% 生成恢复范围。它没有训练或校准依据。v2 删除这些风险分数、固定时间比例和“完成 35% 工作就恢复第一批客户”的假设。

现在实现的是：**真实空间数据与客户路径 → 可解释物理特征 → 有证据门槛的 XGBoost → 条件蒙特卡洛影响分析 → 部件工时与资源排程 → 客户分阶段恢复**。现有数据不足以训练可靠的无条件损坏概率，因此当前运行明确标注为工程基线，`risk.score` 和无条件 `outageProbability` 返回 `null`，不会用看似精确的数字填补缺失信息。

### 2. 输入数据到底有哪些

| 数据 | 已核验内容 | 限制 |
|---|---|---|
| 客户 | 117,642 条，110 条客户电路分组 | 47 条缺少匹配上游路径；不是全 AEP 服务区 |
| 电杆 | 107,013 个 | 有位置、材料、高度等；缺少可信的电杆→客户完整连接键 |
| 一次/二次线路 | 62,788 / 127,403 条 | 完整精确几何私下保存；不能靠距离发明电气连接 |
| 变压器/熔断器/开关/重合器 | 26,959 / 7,616 / 900 / 331 | GIS 节点标识与路径匹配有缺口 |
| 上游关系 | 117,599 行；117,595 客户匹配；32,600 节点 | 60 节点多上游；客户原始路径优先，不能把合并图的所有分支都当成供电路径 |
| 历史损坏 | 1,659 条，2022–2026 | 只有正损坏报告，无完整设备暴露/未损坏标签；日期不是小时级停电/恢复真值 |
| LiDAR 树木 | 36,778 点，米制树高 | Roanoke 局部研究区；不是 Ohio，也不是全区域普查；缺树健康、单株树冠直径和可靠完整覆盖边界 |
| 林地/树冠评估区 | OSM 798 多边形；城市 95 评估区 | 林地不是单株树冠；TreeCanopy 数值单位未确认，因此不用于数值密度计算 |
| 地形 | 实际下载 USGS 3DEP 1600×1600 高程网格，UTM 17N，约 39.79 m | 服务重采样网格；不是声称拥有全区原生 1 m DEM；地形不能独自证明局地风速增幅 |
| 历史天气 | 2024、2025 两个完整年份，3 个区域样本点，逐小时 | Open-Meteo 再分析，非现场实测；真实报告缺事件小时，因此回放使用当天最大阵风所在小时的风向，全天降雨/降雪汇总 |
| 实时天气 | 7 个固定区域预报点 | 风速、风向、阵风、雨量、降雪、雪深及天气代码；预报不是局地实测或雷达路径 |
| 工时与图纸 | 全部 5 张工作表；9 页结构图可视参考目录 | 图纸没有资产对应键和确认部件数量，禁止自动把整套组件都认定损坏 |
| 关键客户与设施 | 113 个 `LS Life Support` 标记；医院 5、消防 37、急救 10 | 设施最近客户仅是候选关联，52 处均无确认的供电关联；原始位置和标记留在私有目录 |

原始电网和树木都在 **Roanoke, Virginia** 附近，不能推广为 Ohio 数据。GIS 精确坐标用于本机算法；网页继续显示泛化位置与匿名 ID。原始客户身份、设施位置不对外提供。

### 3. 数据如何变成物理特征

1. 将精确经纬度转到 EPSG:26917，距离统一用米。客户网页位置的两位小数不会用于精确客户特征计算。
2. 用 KD-tree 查找附近树木，比较树高与距离。风向是“风从哪里来”，倒向按相反方向计算。45° 倒向锥只是公开的几何筛选假设，不是树倒概率。单株树冠和健康状态缺失就保留缺失。
3. 对线路计算方向、横风分量及树高相对几何净距；树点在覆盖边界框以外时返回缺失，绝不把缺树数据解释为零风险。边界框以内也不保证完整。
4. 计算风动压 `q = 0.5 × 1.225 × V²`，V 用 m/s；空气密度 1.225 kg/m³ 是声明的参考假设。动压是 Pa，不是风险百分点。
5. 由真实 DEM 求高程、坡度、局部起伏、梯度平坦度、8 方向地平线遮挡、开阔度及迎风/背风特征。没有随意把“迎风坡”乘上一个损坏概率系数。
6. 将历史风向做速度加权圆周平均，不能把 359° 和 1° 平均成 180°。季节参考仅使用已缓存的**前一年同月**；2024 案例没有更早参考年就标缺失，避免偷看未来天气。这是短期参考，不是几十年的盛行风气候学。
7. 冻雨天气代码只作为发生条件指示，`iceAccretionMm = null`。降雨、积雪、风向与地形都保留来源。没有实测风暴轨迹就标缺失，不伪造局地风暴路径。

### 4. XGBoost 为什么没有立即给出概率

训练入口已经实现，并实际用合成数据验证过代码可运行；合成测试绝不是 AEP 预测验证。正式输入必须是设备×事件记录，包含明确检查过的 0/1 标签、设备 ID、事件 ID、时间和物理特征。未上报损坏的设备不能自动标成“完好”。

训练按完整事件时间顺序分为 60% 训练、20% 校准、20% 测试。XGBoost 使用直方图训练；校准集使用 isotonic calibration；比较逻辑回归和固定发生率两个简单基线。以事件为单位做 bootstrap，只有留出集 log loss 优于两个基线、Brier 差值区间支持改进时才允许加载候选模型。提供逐特征的原始模型 log-odds 贡献；它不是因果解释，也不是直接相加的概率贡献。

当前真实数据缺少事件暴露表、已检查未损坏标签和小时级客户结果，所以没有正式训练/上线概率模型，也没有 GNN。确定性路径比强行训练 GNN 更可验证。候选模型门槛通过也不保证未来泛化，仍需更多独立事件、外部留出地点和可靠资料来源审核。

### 5. A：Outage Impact Percentage 怎样算

**已给定故障节点：**对每个客户，检查其原始上游路径是否含该节点。一个或多个故障命中同一客户只计一次；没有路径的客户保持未知。

**只假定故障数量：**从有真实路径的设备池中抽取故障组合，重复 128 次（可配置 16–2048 次），得到每客户的条件停电频率和区域受影响比例。当前相关性基线是“均匀种子 + 共享客户路径的故障块”，混合比例是显式场景假设；不是从历史拟合的相关系数。没有连通性就不对电杆/线路强行输出客户影响。请求数量超过设备池时会截到可用独立设备数并说明。

**未来有合格损坏概率：**使用经校准设备概率与高斯公共因子 copula 模拟相关故障；相关性仍需要事件证据或敏感性分析，不能冒充已拟合结果。

输出含：每客户无条件概率（当前缺失）、每客户条件频率、平均受影响百分比、模拟结果 2.5%–97.5% 分位区间、蒙特卡洛均值的数值误差区间、拓扑未知比例及未知客户上界。模拟分位区间不是现实预测覆盖率，数值误差区间也不是模型可信度。默认区域是选中电路；`scope: "all"` 可输出全部 117,642 客户，仍不是整个 AEP。

### 6. B：ERT 怎样算

1. 按实际输入的损坏部件数量，取 Excel 安装+拆除工时；可分别输入横担、绝缘子、拉线、锚、接地等，无需把整根电杆所有组件都换掉。
2. 使用工作簿 ILM=4.5。它已经包含行驶、安全讨论和准备时间，因此不默认重复加一次道路行程。
3. 工作簿没有明确导线维修费率，就返回缺失；允许调用方提供明确的工程假设费率。默认变压器是 50 kVA 行、电杆为用户所选尺寸，均明确声明，不能声称已识别所有设备规格。工时作为 crew-hours 的解释也需 AEP 确认；支持 person-hours / crew size 场景。
4. CP-SAT 约束同一时刻使用的队伍数量不超过可用队伍数；用 FIFO 与优先启发式提供可行基线，再进行有限时优化。目标是加权任务完成工时这一代理目标，不假装已经求得真实最优客户停电时间。生命支持标记提供公开的优先级政策；不是损坏概率权重。
5. SimPy 按事件重放排程，检查队伍占用与访问延迟。独立地点可并行修复；客户重新送电时间取其所有故障上游节点的最晚完工时间，自然形成分阶段恢复。没有用工作量除以队伍数代替完整排程，也没有固定的首批恢复比例。
6. ERT 范围来自最多 16 组已采样故障位置和明确输入的队伍/访问参数边界；相同条件可以产生相同上下界。该范围不是 95% 置信区间。`ert.low/high` 是场景维修工作完成范围；客户具体恢复时间在 `ert.perCustomer`。没有可信连接时只能估维修工作，客户 ERT 仍未知。
7. 真实道路、封路、材料与技能、工班、调度/隔离许可缺失；当前没有声称拥有真实道路路由或完整现场可行性。备用方案必须同时确认拓扑、电压、保护、隔离、径向性和容量；真实数据不满足，故不自动应用任何备用送电。代码里的约束筛选可用于将来审核后的方案，不是运行许可。

### 7. 速度、接口与复现

所有原始 GIS 图层均私下读入，保存准确几何、属性与来源哈希；不是把树木或客户坐标舍入后再做算法。使用空间索引、反向客户路径索引、NumPy 批量统计、DEM/天气本地缓存和有界结果缓存。无法可靠验证标签或连接时尽早停止相关分支。

保留 `POST /api/evaluate` 及已有 `scenario/location/risk/restoration/alerts/actions/messages` 字段。新增 `impact`、`ert`、物理特征、模型门槛与性能证据；未知数值允许 null，前端显示“不可用”。新增 `GET /api/algorithm/status` 与 `POST /api/impact`。Ollama 只收到匿名计算摘要，逐客户大表不会塞进聊天上下文。旧的伪风险圆环、分数表尺和低概率误导文案已移除。

运行步骤、标签格式、缓存、依赖与报告生成见 `REPRODUCE.md`。测试结果见 Report 2。高准确率是需要真实留出数据证明的目标，当前不能声称已达到。

## English

### What changed

The old weighted risk score, fixed −25%/+40% restoration envelope and arbitrary 35% first-restoration rule were removed. The implementation now connects exact private GIS, source customer paths, physical descriptors, a gated XGBoost pipeline, conditional correlated Monte Carlo, workbook component labor, CP-SAT scheduling and SimPy event replay. Current real data do not justify unconditional damage probabilities: those fields remain null.

### Inputs and geographic validity

The supplied extract contains 117,642 customers, 333,010 assets/line objects, 1,659 damage reports and 32,600 path nodes. There are 117,595 matched customers and 47 missing paths. The directed aggregate graph is acyclic, but 60 nodes have multiple parents, so original per-customer paths remain authoritative. Of the path nodes, 31,956 join uniquely by asset ID and 49 by location; 595 remain unmatched/ambiguous. Every GIS layer is retained privately. All primary/secondary SHP features in this extract are single-part.

This is Roanoke, Virginia, not Ohio. LiDAR has 36,778 tree-height points in selected study zones, with incomplete coverage and no verified tree-health or crown-diameter data. OSM supplies 798 woodland polygons. Ninety-five city canopy assessment polygons are retained, but unverified field units are excluded from numerical density features. Missing tree coverage is not zero vegetation.

A genuine USGS 3DEP export provides a 1600² regional DEM at approximately 39.79 m spacing. Open-Meteo supplies cached hourly 2024/2025 reanalysis at three regional samples and current forecasts at seven samples. These are modeled weather, not site observations. Freeze-weather codes do not measure ice accretion. Local observed storm tracks are unavailable. Five workbook sheets supply component labor and ILM; nine drawing pages are catalogued as assembly references, not certified asset-specific bills of materials. The data identify 113 life-support flags and 52 emergency/medical facilities; none of the facility-to-customer proximity matches is a verified supply link.

### Physical features and model gate

Coordinates are transformed to UTM metres. Features include tree height, tree distance, a declared 45° downwind geometric reach screen, woodland area, line orientation/crosswind, wind dynamic pressure, rain/snow/freeze indicators, DEM slope/roughness/flatness, directional horizons/openness and wind-facing terrain. Reference air density is explicitly 1.225 kg/m³. These descriptors never become arbitrary probability points. Seasonal direction uses circular statistics from a cached preceding-year month; an earlier year absent from cache remains missing. No future weather is used as a preceding-year reference.

The runnable XGBoost training pipeline requires verified asset-event exposure rows, observed positive and negative labels, event IDs and timestamps. Missing reports are not negatives. Whole events are separated chronologically into training/calibration/test partitions; isotonic calibration uses its own partition. Logistic regression and a constant-rate baseline are measured on held-out events. An event bootstrap evaluates Brier-score differences. A candidate may load only after held-out log loss beats both baselines and the bootstrap Brier-difference gate supports improvement. Feature contributions explain pre-calibration model margins, not causality or additive probability shares.

The current supplied reports fail the real-label gate. An actual synthetic plumbing test exercises training and calibration in a temporary directory and is never deployed. No real-data accuracy is reported. A GNN is deliberately not trained without adequate labels and topology. Deterministic source-path logic is the reliable baseline.

### A. Customer impact

For supplied failure nodes, a customer is affected exactly when its source upstream path includes any failed node. Customers are deduplicated. Unknown paths stay unknown.

For an assumed failure count, the engine samples real connected devices and overlapping customer-path blocks. The default 0.35 block-mixture setting is a declared dependence assumption, not a fitted pairwise correlation. The engine returns conditional customer frequencies, regional affected percentage, simulation quantiles, a separate Monte Carlo mean numerical-error interval and a missing-topology bound. Counts are capped at distinct available devices with a warning. No verified pole/line connectivity means no invented customer impact.

If an approved probability model is supplied later, its calibrated device marginals can drive Gaussian common-factor correlated failure simulation; the correlation still needs evidence or sensitivity testing. The current unconditional customer probability remains null. Default scope is one selected circuit; `scope: "all"` covers all 117,642 supplied customers, not all of AEP. Simulation intervals are not demonstrated forecast coverage.

### B. Restoration

Component removal/installation quantities are multiplied by actual workbook rates and ILM=4.5. ILM already includes reference drive/safety/setup, so travel is not double counted. Unsupported conductor labor remains unavailable unless explicitly provided as an engineering assumption. Transformer 50 kVA and caller-selected pole size are stated defaults; actual ratings/damage are not automatically inferred. Crew-hour interpretation is an assumption; person-hour scenarios with explicit crew size are supported.

FIFO and priority schedules provide feasible baselines. A time-limited CP-SAT model enforces concurrent crew capacity and minimizes weighted task-completion hours, a surrogate objective. Life-support flags influence a declared priority policy. SimPy replays the schedule to verify release times and exclusive crew occupancy. Repairs at independently cleared locations may proceed in parallel; customer energization waits for every failed source-path ancestor to finish. This produces real schedule-based stages rather than a fixed first-group fraction.

The reported range spans up to 16 sampled failure-location and declared crew/access scenarios; it is not a calibrated 95% confidence interval. `ert.low/high` describe workload completion; `ert.perCustomer` supplies customer-specific conditional restoration ranges. Without verified electrical links, workload may be estimable while customer ERT remains unknown. Roads/closures, material logistics, skills, shifts and field clearances are unavailable. Backup screening requires verified topology, voltage compatibility, protection, isolation, radiality and spare capacity. No real alternate supply is automatically applied.

### Performance and integration

KD-tree/STRtree spatial indexes, reverse customer-path indexes, NumPy, persistent DEM/weather caches and bounded result caches support fast repeatable runs. Raw customer identities and exact infrastructure/facility coordinates remain private. Existing API route and envelope keys are retained; missing numbers now legitimately return null and the frontend handles them. New status and impact endpoints expose evidence and per-customer outputs. Ollama receives a compact anonymized calculation summary, not full customer tables. Report 2 contains measured execution evidence and clearly states why forecast accuracy is currently unmeasurable.

## Sources / 来源

- [USGS 3DEP elevation service](https://elevation.nationalmap.gov/arcgis/rest/services/3DEPElevation/ImageServer): terrain source; exact export URL/hash/retrieval time cached alongside the TIFF.
- [Open-Meteo historical weather documentation](https://open-meteo.com/en/docs/historical-weather-api): reanalysis variables, units and resolution context; exact query provenance cached alongside JSON.
- [XGBoost Python API](https://xgboost.readthedocs.io/en/stable/python/python_api.html): implementation API.
- [OR-Tools scheduling documentation](https://developers.google.com/optimization/scheduling/job_shop): interval/resource scheduling approach.
- [Roanoke LiDAR tree source](https://www.arcgis.com/home/item.html?id=84a0a604cc514af88f0e2cad30c754af), [City canopy source](https://www.arcgis.com/home/item.html?id=a26b6445f5e441cfa7b76c4acbeb75e2), and supplied challenge archives/workbook/drawings. Tree-source public access does not establish unrestricted redistribution rights; existing source terms remain recorded.
