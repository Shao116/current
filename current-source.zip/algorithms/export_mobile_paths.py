from pathlib import Path
import pickle,json
from pyproj import Transformer
ROOT=Path(__file__).resolve().parents[1];d=pickle.load(open(ROOT/'private/algorithm/network.pkl','rb'));inv=Transformer.from_crs(26917,4326,always_xy=True);nodes=[];idx={n:i for i,n in enumerate(d['nodes'])}
for n,v in d['nodes'].items():
 a=d['assets'][v['asset']] if v.get('asset') is not None else None;xy=None
 if a:
  x,y=a['xy'];xy=list(inv.transform(round(x/100)*100,round(y/100)*100))
 nodes.append([a['kind'] if a else v['type'],xy])
f=ROOT/'public/workspace/replay.json';out=json.loads(f.read_text());out['nodes']=nodes;out['paths']=[[idx[n] for n in reversed(c['path'])] for c in d['customers']];f.write_text(json.dumps(out,separators=(',',':')));print(len(nodes),'anonymous nodes, bytes',f.stat().st_size)
