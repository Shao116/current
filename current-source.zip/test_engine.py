import unittest,json,urllib.request,urllib.error
from pathlib import Path
from engine import evaluate
D=json.loads((Path(__file__).parent/'private/data.json').read_text());D['premiseIndex']={p['id']:p for p in D['premises']};D['circuitIndex']={c['id']:c for c in D['circuits']}
BASE={'contextType':'premise','contextId':'P-000001'}
class ScenarioTests(unittest.TestCase):
 def run_scenario(self,**changes):return evaluate(dict(BASE,**changes),D)
 def test_crew_resources_reduce_time_but_keep_upstream_bottleneck(self):
  a=self.run_scenario(crews=1);b=self.run_scenario(crews=6)
  self.assertLess(b['restoration']['high'],a['restoration']['high']);self.assertEqual(a['restoration']['predecessorHours'],b['restoration']['predecessorHours']);self.assertGreater(b['restoration']['low'],0)
 def test_storm_and_access_change_risk(self):
  self.assertIsNone(self.run_scenario(wind=10)['risk']['score']);self.assertIsNone(self.run_scenario(wind=90)['risk']['score'])
  self.assertGreater(self.run_scenario(access=True)['restoration']['high'],self.run_scenario(access=False)['restoration']['high'])
 def test_dependency_and_step_scenarios(self):
  a=self.run_scenario(upstream=0);b=self.run_scenario(upstream=2,step=True)
  self.assertGreater(b['restoration']['high'],a['restoration']['high']);self.assertIsNone(b['restoration']['firstRestoration']);self.assertTrue(b['location']['path'])
 def test_zero_damage_means_zero_repair_duration(self):
  r=self.run_scenario(quantity=0,upstream=0,accessDelay=20);self.assertEqual(r['restoration']['high'],0);self.assertIsNone(r['restoration']['firstRestoration'])
 def test_upstream_work_remains_with_no_local_damage(self):
  r=self.run_scenario(quantity=0,upstream=2);self.assertGreater(r['restoration']['low'],0)
 def test_declared_needs_and_alert_opt_in(self):
  r=self.run_scenario(wind=0,medical=True,optIn=True);self.assertTrue(r['alerts']['eligible']);self.assertTrue(r['alerts']['subscribed']);self.assertEqual(r['actions'][0]['id'],'medical')
  self.assertFalse(self.run_scenario(optIn=False)['alerts']['subscribed'])
 def test_four_stages_and_messages(self):
  for stage in ['pre','outage','update','restored']:
   r=self.run_scenario(stage=stage);self.assertEqual(r['message'],r['messages'][stage]);self.assertIn('scenario' if stage=='pre' else 'Demo',r['message'])
 def test_invalid_inputs_rejected(self):
  for k,v in [('crews',0),('quantity',-1),('wind',float('nan')),('crews',1.5),('asset','unknown'),('contextId','P-NOTFOUND')]:
   with self.subTest(k=k,v=v),self.assertRaises(ValueError):self.run_scenario(**{k:v})
 def test_unmatched_premise_fallback(self):
  p=next(p for p in D['premises'] if not p['path']);r=self.run_scenario(contextId=p['id']);self.assertFalse(r['location']['topologyAvailable']);self.assertEqual(r['risk']['confidence'],'Unvalidated')
 def test_circuit_and_map_contexts(self):
  for s in [{'contextType':'circuit','contextId':'C-001'},{'contextType':'map','lat':37.27,'lng':-79.94}]:self.assertTrue(evaluate(s,D)['location']['circuit'])
 def test_sanitized_result(self):
  r=json.dumps(self.run_scenario());self.assertNotIn('address',r);self.assertNotIn('premise_nu',r);self.assertNotIn('Reporting_',r)
 def test_api_and_raw_file_isolation(self):
  for p in ['/private/data.json','/server.py','/../private/data.json','/references/unknown.pdf']:
   with self.subTest(p=p),self.assertRaises(urllib.error.HTTPError):urllib.request.urlopen('http://127.0.0.1:8765'+p)
  req=urllib.request.Request('http://127.0.0.1:8765/api/evaluate',data=b'{"scenario":{}}',headers={'Content-Type':'application/json','Origin':'https://example.com'})
  with self.assertRaises(urllib.error.HTTPError) as e:urllib.request.urlopen(req)
  self.assertEqual(e.exception.code,403)
 def test_overview_aggregates_and_documents(self):
  with urllib.request.urlopen('http://127.0.0.1:8765/api/overview') as r:o=json.load(r)
  self.assertEqual(sum(g['damage'] for g in o['grid']),1659);self.assertEqual(sum(g['customers'] for g in o['grid']),117642);self.assertEqual(len(o['inventory']),12);self.assertNotIn('premises',o)
  for f in ['challenge.pdf','keynote.pdf','structures.pdf']:
   with urllib.request.urlopen('http://127.0.0.1:8765/references/'+f) as r:self.assertEqual(r.read(4),b'%PDF')
if __name__=='__main__':unittest.main(verbosity=2)
