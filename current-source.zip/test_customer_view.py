import unittest,json
from types import SimpleNamespace
import numpy as np
from algorithms.customer_view import customer_estimate,supply_path
from algorithms.customer_guidance import guidance
class CustomerViewTests(unittest.TestCase):
 def test_customer_not_circuit_percentage(self):
  d={'impact':{'expectedAffectedPercentage':4.2,'perCustomer':[{'id':'P-000001','scenarioOutageProbability':.31,'modeledSupportCoverage':True}]},'riskAssessment':{}}
  r=customer_estimate(d,{'id':'P-000001','path':['x']});self.assertEqual(r['scenarioOutagePercentage'],31);self.assertIsNone(r['calibratedOutageProbability'])
 def test_no_coverage_is_not_zero(self):
  r=customer_estimate({'impact':{'perCustomer':[{'id':'P-000001','conditionalOutageProbability':None}]}},{'id':'P-000001','path':[]});self.assertFalse(r['available']);self.assertIsNone(r['scenarioOutagePercentage'])
 def test_explicit_failure_conditional_probability(self):
  r=customer_estimate({'impact':{'perCustomer':[{'id':'P-000001','conditionalOutageProbability':1.}]}},{'id':'P-000001','path':['x']});self.assertEqual(r['scenarioOutagePercentage'],100);self.assertIn('explicitly',r['basis'])
 def test_map_context_never_invents_house(self):self.assertIsNone(customer_estimate({},None))
 def test_zero_modeled_value_retained(self):
  r=customer_estimate({'impact':{'perCustomer':[{'id':'P-000001','scenarioOutageProbability':0.}]},'riskAssessment':{}},{'id':'P-000001','path':['x']});self.assertTrue(r['available']);self.assertEqual(r['scenarioOutagePercentage'],0)
 def fixture(self):
  return SimpleNamespace(d={'customers':[{'id':'P-000001','xy':(590000,4120000),'circuit':'C-001','path':['child','missing','root']}],'nodes':{'child':{'asset':0,'type':'Distribution'},'missing':{'asset':None,'type':'Fuse'},'root':{'asset':1,'type':'Circuit Breaker'}},'assets':[{'kind':'transformer','xy':(590051,4120099)},{'kind':'switch','xy':(591001,4122001)}]})
 def test_order_and_missing_location_no_bridge(self):
  r=supply_path(self.fixture(),'P-000001');self.assertEqual([s['id'] for s in r['steps']],['root','missing','child','P-000001']);lines=[f for f in r['geojson']['features'] if f['geometry']['type']=='LineString'];self.assertEqual(len(lines),1);self.assertEqual(lines[0]['properties']['from'],'child');self.assertEqual(r['missingDeviceLocations'],1);self.assertFalse(lines[0]['properties']['surveyedCableRoute']);self.assertNotIn('attributes',json.dumps(r))
 def test_invalid_customer_rejected(self):
  for ident in ['P-000000','P-999999','P-NOTFOUND','RAW-123']:
   with self.assertRaises(ValueError):supply_path(self.fixture(),ident)
 def test_missing_path_clear_fallback(self):
  svc=self.fixture();svc.d['customers'][0]['path']=[];r=supply_path(svc,'P-000001');self.assertFalse(r['topologyAvailable']);self.assertFalse(r['geojson']['features']);self.assertFalse(r['steps'])
 def test_severe_weather_guidance_and_escalation(self):
  s={'wind':81,'medical':False,'accessible':False,'critical':False,'stage':'pre','optIn':True,'channel':'In-app'};result={'physicsFeatures':{'weather':{'gustMph':81}},'impact':{'expectedAffectedPercentage':2},'ert':{'high':36}};actions,a=guidance(s,result);self.assertTrue(a['eligible']);self.assertTrue(a['subscribed']);self.assertGreater(len(a['escalation']),0);self.assertTrue(any(x['id']=='extended' for x in actions));self.assertIn('not official',a['rule'])
 def test_low_weather_no_unsolicited_preparation(self):
  s={'wind':3,'medical':False,'accessible':False,'critical':False,'stage':'pre','optIn':False,'channel':'In-app'};actions,a=guidance(s,{'impact':{'expectedAffectedPercentage':.1},'ert':{'high':0}});self.assertFalse(a['eligible']);self.assertFalse(actions)
if __name__=='__main__':unittest.main()
