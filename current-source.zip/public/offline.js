'use strict';
(async()=>{if(!('serviceWorker'in navigator))return;const badge=document.createElement('div');badge.id='offlineStatus';badge.setAttribute('role','status');badge.hidden=true;document.body.append(badge);let weatherStamp=null;
function status(){badge.hidden=navigator.onLine;badge.textContent='Offline · saved data'+(weatherStamp?' · weather saved '+new Date(weatherStamp).toLocaleString():'')+' · previously loaded areas & estimates only';}
window.addEventListener('offline',status);window.addEventListener('online',status);
try{await navigator.serviceWorker.register('/sw.js');await navigator.serviceWorker.ready;if(!navigator.serviceWorker.controller)await new Promise(resolve=>{navigator.serviceWorker.addEventListener('controllerchange',resolve,{once:true});setTimeout(resolve,4000)});
await Promise.allSettled(['/api/overview','/api/weather','/data/nature-meta.json','/data/roanoke-nature-meta.json','/data/map-natural.json'].map(async url=>{const r=await fetch(url);if(url==='/api/weather'&&r.ok){const w=await r.json();weatherStamp=w.fetchedAt;localStorage.setItem('current-weather-saved',weatherStamp||'')}}));
weatherStamp=weatherStamp||localStorage.getItem('current-weather-saved');status();
}catch{status()}
})();
