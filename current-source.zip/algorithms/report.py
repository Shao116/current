"""Render bilingual evidence reports from measured benchmark artifacts."""
from pathlib import Path
import json,csv,html
import markdown
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'reports'
def fmt(v,d=2):return 'N/A' if v is None else f'{v:.{d}f}'
def main():
 s=json.loads((OUT/'benchmark-summary.json').read_text());cases=json.loads((OUT/'20-cases.json').read_text());rows=[c['metrics'] for c in cases];full=json.loads((OUT/'full-scope-check.json').read_text())
 text=f'''# Report 2 · 20 组实际运行与验证 / Twenty measured runs and validation

Generated UTC: {s['generatedUTC']} · Python {s['python']} · {s['platform']}

## 中文：先说明能证明什么

这是实际执行代码得到的 20 组结果，不是示意表。**8 组真实历史背景回放 + 12 组合成天气/故障场景；真实客户停电结果回测为 0 组。** 历史组使用真实损坏报告和当日再分析天气，但最近设备的身份未经确认，因此故障节点也只作为明确的回放假设，不能称为已验证的历史停电影响。

全部组的无条件停电概率、实际客户停电比例、实际客户 ERT、预测误差、准确率均为 **N/A**。原因是缺少可配对的客户结果、完整未损坏标签、事件暴露及小时级恢复真值。`Repaired_D - Report_Tim` 不能当作小时级停电时长，最近设备匹配也不是资产身份真值。

每组相同随机种子独立计算 3 次，期间清空结果缓存，表中为暖进程下端到端 Python 计算中位延迟；另测一次命中缓存延迟。不包括网络下载、网页渲染、Ollama、JSON 的 HTTP 传输或首次导入。已下载数据固定缓存，原始压缩包 SHA256 在状态审计中。

- 中位未命中缓存计算：**{s['medianUncachedMs']:.1f} ms**；20 组中位数的 P95：**{s['p95UncachedMs']:.1f} ms**。
- 中位缓存计算：**{s['medianCachedMs']:.1f} ms**；该次进程服务初始化：**{s['coldStartupSeconds']:.2f} s**。
- 另一次全区域测试实际输出 **{full['customers']:,}** 个客户的影响和 ERT 行：**{full['runtimeSeconds']:.2f} s**，47 个客户路径未知。不是全区域天气概率验证。
- H01–H08 条件影响与直接扫描原始客户路径的最大差：**{s['maxSourcePathDifferencePct']:.3g} 个百分点**，仅浮点数误差。这是连接逻辑验证，**不是预测准确率**。

## English: interpretation before numbers

These are actual executions, not illustrative values: **8 historical-context replays, 12 synthetic hazard/failure scenarios, and zero genuine customer-outcome backtests**. Historical replays use real positive reports and reanalysis weather. Nearest-device identity is unverified and is explicitly assumed for the replay. No historical customer outage or restoration outcome is available.

Unconditional outage probability, actual outage percentage, actual ERT, forecast error and accuracy are **N/A for all 20 cases**. Report-to-repair date subtraction is not verified hourly outage duration. Source-path equivalence is a structural correctness test, not predictive accuracy.

Each case is computed three times with identical seeds and the result cache cleared. The table reports median warm-process calculation time. A separate cached call is measured. Network downloads, browser rendering, Ollama, HTTP serialization/transfer and first imports are excluded. Uncached median is {s['medianUncachedMs']:.1f} ms, P95 across case medians {s['p95UncachedMs']:.1f} ms, cached median {s['medianCachedMs']:.1f} ms. The separate full-extract integration run outputs all 117,642 customer rows in {full['runtimeSeconds']:.2f} seconds.

## 预测/条件模拟结果 · Conditional results

`Impact` 是选中电路内、给定/假定设备故障后的客户影响比例，**不是天气导致停电的概率**。`95% sim` 是模拟分位范围，不是现实校准置信度。`Work h` 是维修工作完工范围，客户分阶段结果在 JSON/API。所有行置信度：**U = unvalidated / 未经真实结果验证**。实际结果与预测误差：所有行 **N/A**。

| ID | Date | Circuit / generalized point | Conditional impact % | 95% sim % | Work h | Compute ms | Cache ms | Truth / error | Confidence / gap |
|---|---|---|---:|---|---|---:|---:|---|---|
'''
 for r in rows:
  gap='H' if r['case'].startswith('H') else 'L' if r['conditionalImpactPct'] is None else 'T' if r['treeCoverage']=='missing_outside_bounds' else 'V'
  text+=f"| {r['case']} | {r['date']} | {r['place']} | {fmt(r['conditionalImpactPct'])} | {fmt(r['scenarioLowPct'])}–{fmt(r['scenarioHighPct'])} | {fmt(r['ertLowH'])}–{fmt(r['ertHighH'])} | {fmt(r['runtimeMedianMs'],1)} | {fmt(r['cacheMs'],1)} | N/A / N/A | U / {gap} |\n"
 text+='''
Gap codes / 缺口：

- **H**：真实损坏报告，但资产身份仅空间候选；无客户停电/ERT 真值。Real report, unverified asset identity, no customer-outcome labels.
- **L**：导线无可信客户路径且无工作簿维修费率，返回缺失。Conductor connectivity/labor unavailable; no fabricated fallback.
- **T**：选点在 LiDAR 研究数据边界以外；树木特征缺失。Outside LiDAR source bounds; tree features missing, not zero.
- **V**：条件模拟可运行，但没有真实结果校准；边界内树木仍不完整。Scenario executes; outcome calibration absent and vegetation remains incomplete.

## 每组条件和证据 · Conditions and evidence

H 行风向为当天最大阵风小时的区域再分析风向；降雨/降雪为全天累计，非同一瞬时暴露。S 行天气均为人工假设；日期不代表当天真的发生该灾害。Generalized coordinates are deliberately coarse.

| ID | Type / evidence | Hazard | Gust mph | Wind from ° | Rain mm | Snow cm | Freeze indicator | Terrain slope ° | LiDAR |
|---|---|---|---:|---:|---:|---:|---|---:|---|
'''
 for c in cases:
  r=c['metrics'];f=c['result']['physicsFeatures'];w=f['weather'];e='Real report '+c['case']['sourceDamage'] if r['case'].startswith('H') else 'Synthetic scenario'
  text+=f"| {r['case']} | {e} | {r['hazard']} | {fmt(w.get('gustMph'),1)} | {fmt(w.get('windDirection'),0)} | {fmt(w.get('rainMm'),1)} | {fmt(w.get('snowfallCm'),1)} | {str(w.get('freezingRainIndicator',False))} | {fmt(r['slopeDeg'],1)} | {r['treeCoverage']} |\n"
 text+='''
## 简单基线是否被复杂算法超过？ / Did complexity beat the baselines?

1. **真实风险预测 / Real risk prediction**：没有合格的真实标签，XGBoost、逻辑回归、常数发生率的真实 Brier、log loss、AUC 均 N/A。不能声称复杂模型提升了准确率。实际跑过 XGBoost→独立校准→基线比较→门槛判断的合成代码测试；产物留在临时目录，未部署，合成指标不代表 AEP 结果。
2. **图影响 / Graph impact**：历史背景回放的条件影响与独立原始路径扫描一致。验证覆盖全部 32,600 节点的反向客户索引；未把有 60 个多上游节点的合并图盲目当树。
3. **Monte Carlo**：20,000 次小型独立概率实验对照解析结果 `[0.20, 0.44, 0.30]`，每项误差小于测试容差 0.015；另测公共因子相关模拟保持给定边缘概率。它们证明实现可用，不证明给定概率在现实正确。
4. **ERT 排程 / Scheduling**：对同一场景比较 FIFO 和优化排程的加权任务完成时间。保证仅采用不劣于已有可行基线的解；求解超时保留基线。下表是模型内目标比较，不是实测恢复误差，也不证明得到全局最优客户恢复方案。

| ID | FIFO objective | Selected objective | Improvement | Meaning |
|---|---:|---:|---:|---|
'''
 for r in rows:text+=f"| {r['case']} | {fmt(r['fifoObjective'])} | {fmt(r['optimizedObjective'])} | {fmt(r['objectiveImprovement'])} | weighted task-hours, not observed outage error |\n"
 text+='''
不同案例的目标权重和客户数不同，不能把目标值横向当作灾害严重程度。这里没有可靠标签支持 XGBoost 相对简单风险基线的真实提升；对于给定故障，确定性路径本来就是准确而直接的方法。复杂排程是否改善真实恢复时间，仍需小时级现场结果。

Objective values depend on scope and explicit priority policy and should not be compared across storms as severity scores. There is no evidence here of real predictive improvement by XGBoost over simple risk baselines. Deterministic path logic is the direct baseline for known failures; real restoration improvement remains unverified.

## 实际测试与失败行为 / Executed checks and failure behavior

- `tests-all.txt`：40 个 Python 测试通过（含 22 个 v2 测试），覆盖完整路径反向索引、真实地形/天气、缺树、缺标签、未知拓扑、概率模拟、组件工时、队伍占用、访问延迟、分阶段送电、备用约束、缓存、输入拒绝、隐私与 HTTP 接口。
- `tests-frontend.txt`：四天 Demo fixture 与真实 HTTP API 实测通过；所有旧风险分数保持 null，缺导线工时返回 null，雪天保持雪的天气上下文。
- `full-scope-check.json`：全部 117,642 客户的影响和客户 ERT 输出，通过独立路径基线核对。
- 导线场景 S11 的不可计算是预期的诚实拒绝，不是悄悄用假费率补齐。电杆无客户路径时同样只允许工作量估计。
- 界面已实际打开检查：未知概率不会显示成低风险，固定彩色风险圆环和分数表尺移除；地图、天气、Demo 与本机 Ollama 接口保留。

Forty Python checks pass, including twenty-two v2 checks. Frontend fixtures also pass through the real HTTP API. Missing conductor labor and unverified topology deliberately produce unavailable outputs. Unknown probability never becomes a low-risk claim. Full per-customer integration, actual public input downloads and browser integration are verified separately from outcome accuracy.

## 下一步需要真实补充什么 / Required evidence to measure accuracy

提供设备×风暴事件的完整暴露及已检查 0/1 结果、精确设备连接、客户停电/复电时间、实际班组/工班/材料、道路封闭和真实安全隔离依赖；补齐资产规格/损坏部件、树木覆盖/健康/树冠、冻雨覆冰、历史风暴路径、设施客户关联和经工程审批的备用线路参数。届时才可进行真正独立事件/地点回测、校准与 MAE/Brier 等误差比较。

Required next inputs are complete inspected asset-event exposures, accurate electrical connections, hourly customer outage/restoration outcomes, actual crew/shift/material/road/safety constraints, asset specifications and damaged components, vegetation coverage/health/crowns, icing/storm tracks, verified critical-facility supply links and approved alternate-feed engineering data. These are missing data requirements, not evidence of current accuracy.

## 可复现文件 / Evidence artifacts

- `20-cases.csv`：所有 20 组的机器可读指标，真实结果/误差留空。
- `20-cases.json`：输入、种子、物理特征、逐客户条件影响/恢复输出、排程与缺失原因。
- `benchmark-summary.json` / `benchmark-run.txt`：平台、延迟、冷启动与完整运行记录。
- `xgboost-synthetic-plumbing.json`：**仅合成训练代码检查**，非真实验证。
- `full-scope-check.json` / `tests-all.txt` / `tests-v2.txt` / `tests-frontend.txt`。
- 私有目录中的源数据哈希、DEM/天气 URL/下载时间与全客户示例压缩输出；复现命令见 `REPRODUCE.md`。
'''
 (OUT/'Report-2-Validation-中英文.md').write_text(text)
 css='body{margin:0;background:#f6f3e9;color:#203a2e;font:16px/1.7 system-ui,sans-serif}main{max-width:1180px;margin:36px auto;padding:36px;background:#fffef9;border-radius:16px}h1,h2,h3{color:#245a3e;line-height:1.3}h1{font-size:30px}h2{margin-top:36px;border-top:1px solid #d3dfce;padding-top:24px}table{display:block;overflow:auto;border-collapse:collapse;font-size:13px;width:100%;margin:20px 0}th,td{border:1px solid #d5ddcf;padding:8px 10px;vertical-align:top}th{background:#e8eedf;text-align:left}tr:nth-child(even){background:#faf9f1}a{color:#266442}code,pre{background:#eaf0e5}pre{padding:16px;overflow:auto}nav{font-size:14px}strong{color:#234b33}@media(max-width:700px){main{margin:0;padding:18px}}'
 for number,name in [(1,'Report-1-Pipeline-中英文'),(2,'Report-2-Validation-中英文')]:
  body=markdown.markdown((OUT/f'{name}.md').read_text(),extensions=['tables','fenced_code']);(OUT/f'report{number}.html').write_text(f'<!doctype html><html lang="zh"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>current · Report {number}</title><style>{css}</style><main><nav><a href="/">← current</a> · <a href="/reports/report1.html">Report 1</a> · <a href="/reports/report2.html">Report 2</a></nav>{body}</main></html>')
 print('Two bilingual Markdown and HTML reports generated from actual evidence.')
if __name__=='__main__':main()
