"""Document-linked prototype audit. No invented accuracy, score, or completion %.
The PDFs/XLSX are evidence for comparison, not instructions to submit externally.
"""
from pathlib import Path
import json,html
import markdown
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'reports/final'
def main():
 results=json.loads((OUT/'customer-live-tests.json').read_text());home=next(r for r in results if r.get('customer')=='P-094125');other=next(r for r in results if r.get('customer')=='P-020015')
 text=f'''# current 最终需求与评分核对 / Final requirement and rubric audit

## 结论 / Conclusion

**三个新增功能已实现；AEP 五类核心功能均有可运行的原型实现。不能声称“完美”、真实预测已准确、生产可用、提交已完成或评委会给满分。**

The three requested additions are implemented, and all five AEP capability areas have working prototype implementations. This is not validated prediction accuracy, production readiness, completed submission, or a guaranteed judging score.

## 本次新增 / Implemented in this change

1. 默认进入 Weather；Risk 的连续区域栅格保留，进入 Risk 才适配全区。Default view is Weather; continuous regional Risk remains available.
2. 点选匿名客户，在 Power grid 查看其 recorded upstream path。顺序是源数据的上游设备到该户，设备有坐标才绘图。设备位置约100m概化，虚线连接表达依赖，不冒充实测电缆路径。没有坐标的设备仍在列表里，绝不跨过未知节点补造连接。
3. 新增 `customerRisk`，逐户读取既有拓扑风险计算结果，与线路影响比例明确分开。`calibratedOutageProbability` 仍为 null；百分比是工程情景估计，不是经过本地校准的单户概率。缺失支持覆盖显示 unavailable，不能借用线路平均值或显示0%。
4. 补上明确的预警情景政策、通知时间、升级条件、四阶段简明消息和可达的个性化需求入口。No actual SMS/email delivery. Local in-app opt-in previews remain explicit simulations.
5. 默认示例改为有建模支持、且邻近 Roanoke 中心的真实匿名客户 P-094125；不是虚构客户，也不是把风险调高。未匹配客户的不可用分支照常保留。

## 实测证据 / Actual evidence

- 83 Python unit/regression tests passed; log: `reports/final/customer-regression-tests.txt`.
- Four documented historical-weather demo integration checks passed; they remain current-grid scenario replays, NOT true historical outage backtests.
- Live HTTP: P-094125 at 81 mph, direction280°, 2012-06-29 has **home scenario {home['homeScenarioPercentage']:.5f}%**, **circuit affected share {home['circuitExpectedAffectedPercentage']:.5f}%**. They are different estimands, not two interchangeable probabilities.
- Source path for that customer has {home['totalUpstreamDevices']} devices, {home['mappedDevices']} map positions, {home['missingLocations']} missing location. All output device order matches the original customer path exactly in reverse display order.
- P-020015 has no supported overhead support exposure; its individual estimate is **unavailable**, despite a circuit-wide estimate being available. This is an intentional reliability safeguard.
- Four stage-message and opt-in preview policies exercised through HTTP. No outbound communication was sent.
- Local Ollama was offline during the audit, restarted on loopback and tested using installed mistral:latest. The actual response distinguishes ~3.4% for the selected home from ~1.32% for the circuit and states lack of local calibration. Cold-start generation took about37s; do not claim all AI responses are instantaneous. Log: `customer-ollama-test.txt`.
- Browser checks cover default Weather, individual selection, Power grid recorded-path display, household percent separate from circuit share, and notification/personalization access. Screenshots provide UI evidence; tests do not establish predictive accuracy.

## AEP 挑战要求逐条核对 / Requirement-by-requirement

Source: [AEP brief](</Users/tony/Downloads/aep_challenge.pdf>), pp.2–5. “Implemented” below means a credible prototype, not a verified utility operational forecast.

|要求 / Requirement|原型状态 / Status|代码与演示证据 / Evidence|边界 / Remaining limitation|
|---|---|---|---|
|1.1 premise/circuit/map contexts|已实现 / Implemented|匿名客户点、P-/C- 搜索、任意地图点|47个客户无上游匹配，明确缺失|
|1.2 risk estimate or defined band|已实现 / Implemented|逐户情景百分比、线路影响比例、连续区域图、定义的影响分级|非本地校准概率；展示分级不等于官方危险标准|
|1.3 relevant historical/asset/topology/spatial/weather signals|已实现，部分为上下文 / Active with context-only inputs|实际上游路径、设备等级/相数、阵风/风向、LiDAR几何、先前损坏记录、地形解释|历史记录不能直接当完整标签；雨土、覆冰、地形风放大未定量|
|1.4 factors and uncertainty|已实现 / Implemented|单户详情有阵风、风向、依赖数、支持组件数；标注uncalibrated；显示缺失覆盖|线路主导模式与单户因素不混称；不是SHAP或已验证因果归因|
|2.1 restoration range|已实现 / Implemented|现有范围输出，个人窗口在ert.perCustomer，区域工作量单独命名|没有小时级客户真值，无法计算ERT误差|
|2.2 damage/dependencies/stages/labor/travel/nonproductive time|已实现工程情景 / Engineering scenario|AEP精确工时行、ILM4.5、部件、上游路径、CP-SAT和SimPy|ILM为参考非实际路线；材料、换班与交通封闭未知|
|2.3 updates after scenario changes|已实现 / Implemented|队伍、访问延迟、部件/数量等响应测试|变量是情景假设，不是调度命令|
|2.4 distinguish model vs utility confirmation|已实现 / Implemented|页面、详情、聊天与消息预览有明确模型/演示语义|没有接入实际AEP停电确认或官方ERT|
|3.1 actions adapted to risk/duration|已实现演示政策 / Demo policy|危险风/冬季/较高影响或声明需求触发，长时中断增加准备项；低风险不主动堆准备项|未做独立住户有效性研究|
|3.2 safety and practical guidance|已实现 / Implemented|落线、照明、充电、备用电；紧急情况明确升级|不是现场应急判断或医疗建议|
|3.3 declared needs without inference|已实现 / Implemented|铃铛→Personal needs；医疗/无障碍/关键需求自主声明；准备清单可更新|医院供电映射未核验，不用空间最近邻冒充|
|4.1 documented alert eligibility|已实现演示规则 / Documented demo policy|声明需求、阶段、阵风>=58mph/冬季、线路>=5%产品规划阈值|不是AEP官方告警阈值；不影响概率计算|
|4.2 timing/channel/escalation|已实现预览 / Preview implemented|消息窗口显示时机、渠道选项、紧急/医疗备电/信息缺失升级条件|SMS/Email仅预览，不发送；不是持续监测服务|
|4.3 four stages of plain-language messages|已实现 / Implemented|pre/outage/update/restored四阶段API实测，清楚标为demo|不会把模拟状态写成真实停电或真实复电|
|5.1 plain explanations|已实现 / Implemented|单户与线路区分、供电链、风险/维修解释、Ollama|生成式模型仍可能表达错误，固定计算不由LLM生成|
|5.2 confidence/assumptions/gaps|已实现 / Implemented|单户Uncalibrated提示，详情和数据缺口清单|真实准确率和置信区间覆盖率未知|
|5.3 privacy|已实现原型控制 / Prototype controls|匿名ID，不返回账户/地址/员工信息/关键设施精确属性；设备位置概化；仅loopback|不是面向公网的登录、权限、渗透测试完成证明|
|5.4 reliable fallback|已实现 / Implemented|未知不是0；天气未加载时不显示默认0风险；Ollama离线提示；官方渠道升级|数据缺失不能被界面或PINN补造|

## Minimum Viable Demonstration / 最低演示链

按挑战文件p.5：
1. 选匿名住户：地图绿色客户点或精确P-搜索。
2. 返回风险和置信提示：**该户情景估计**＋Uncalibrated；信息按钮看因素。区域比例另有标题。
3. 维修情景：改变队伍或访问延迟，展示范围变化；部件假设单独展开。
4. 准备与资格：严重风暴或自主需求触发准备项；铃铛显示资格、时机、渠道、升级规则。
5. 主动沟通：勾选演示通知，再改变估计或阶段，可见本地in-app预览提示；四个消息模板均能生成。
6. 责任使用：展示一个无覆盖客户、灰色区域、缺坐标路径、冬季模型局限；不宣称真实准确率。

这个流程能满足“可解释的聚焦原型”的实现目标。全部演示必须由视频/现场操作实际展示，代码存在不自动等于评委已看见。

## 评分表对应 / Rubric evidence, not predicted scores

Source: [OHIO Judging Rubric](</Users/tony/Downloads/OHIO Judging Rubric.xlsx>), `Judging Rubric!A4:K10`. 主表六项、每项五级，另有草案/替代量表；不擅自认定AEP专属权重、不预测满分。

|维度|现有优点|展示还需要什么|
|---|---|---|
|Innovation|把传统区域地图推进到逐户依赖解释、可改维修因素与家庭备电决策；有已发表模型和v2对照|讲清相对现有方案的具体改进；不要把采用现成算法说成发明新算法|
|Curiosity|追问地理覆盖、概率含义、PINN适用性、线路两端信息；有真实数据审查和代码修复|由团队讲出“问了什么、如何查证、因此改变什么”；不杜撰访谈或导师反馈|
|Communication|可操作地图、住户/区域区别、路径列表、四个可溯源历史事件、双语报告|3分钟视频必须让评委看到闭环，避免只展示漂亮地图|
|Project Breadth and Complexity|GIS+空间索引+物理模型+图依赖+相关失效模拟+约束排程+本地LLM|准备10倍规模的架构解释；现有单机测试不等于已经验证10倍并发|
|Impact|居民知道可能影响、依赖、准备和备用供电时间；自主医疗/无障碍需求|尚无独立住户用户研究、采用率或量化社会收益，不伪造数据|
|Navigating challenges|放弃任意加权；严查Roanoke与Ohio地域差异；未知不充0；补真实kVA/两端迎风角；测试后改UI|展示一项失败、修改、实际验证的证据链，准确率改善不能编造|

## 真正还缺什么 / Genuine remaining gaps

### 提交与讲解（最紧迫） / Submission and presentation

依据 [Opening Keynote](</Users/tony/Downloads/2026 HackOHI_O Opening Keynote.pdf>) p.7：**3分钟视频、通过Discord公布的Google表单提交，文件写明周日10:00 AM截止**；p.8还有评审波次/Zoom安排。这是材料中的规定，尚未在Discord实时复核。

- 在当前项目中未找到最终3分钟视频，也未见提交回执；不能替团队声明已提交。视频可能在项目外已制作，仍需团队核实。
- 仍需实际录制端到端流程，确认提交、视频播放与评审场次。
- 尚无独立住户用户研究或量化真实收益。

### 科学与运行边界（不能靠换模型消失） / Scientific and operational limits

- 0组真实客户停复电结果回测，准确率/概率校准/ERT MAE都未知。83项软件测试不是预测准确率。
- 缺完整设备×风暴暴露表、可靠未损坏样本、小时级客户结果、完整树木健康/种属与覆冰土壤参数。
- 供电链有缺失/未可靠匹配的坐标；没有发电厂级完整来电路径；虚线不是实测电缆路线。
- 没有真实AEP停电确认、实际队伍/道路/库存、完整备用线路容量与保护核验；不能实际执行切换。
- 风险栅格是区域统一天气向量下的平滑模型，不是观测风暴路径，不是全灾种完整概率。
- Ollama依赖本机服务与已安装模型；已恢复并测试，但需录制时保持运行。

### 不应误当成必需缺项 / Not required by the supplied AEP brief

- 不强制PINN、GNN、手机App或AEP公司端；文件允许自选架构、网页或手机原型。
- 不要求复制生产级OMS；p.5明确偏好聚焦且假设透明的可信原型。
- 消息必须能生成并展示沟通流程；没有明确要求比赛原型发送真实SMS/邮件。
- 并非每个字段都要进入一个概率公式；不相关或缺参数的字段可以作为上下文/缺失审计，不强行加权。

## 超出最低要求但有价值的优势 / Useful extras

连续区域风险图；真实逐户上游依赖；四个有来源的历史天气回放；LiDAR/DEM与物理特征；精确工时行与部件加项；相关失效不确定性；按客户依赖恢复；家庭电池运行时长；免费矢量底图；本地Ollama；源文件哈希、重复副本审查、双语可复现报告与实测记录。

**这些是原型的优点，不是已经赢奖或最精准的证据。**
'''
 (OUT/'Submission-Audit-中英文.md').write_text(text)
 body=markdown.markdown(text,extensions=['tables','fenced_code'])
 for original,url in [('/Users/tony/Downloads/aep_challenge.pdf','/references/challenge.pdf'),('/Users/tony/Downloads/OHIO Judging Rubric.xlsx','/references/rubric.xlsx'),('/Users/tony/Downloads/2026 HackOHI_O Opening Keynote.pdf','/references/keynote.pdf')]:body=body.replace(original,url)
 css='body{margin:0;background:#f4f1e8;color:#203e2d;font:16px/1.7 system-ui,sans-serif}main{max-width:1100px;margin:30px auto;padding:30px;background:#fffdf7;border:1px solid #b7c4a7;border-radius:14px}table{border-collapse:collapse;width:100%;font-size:14px}th,td{padding:12px;border:1px solid #becbb4;vertical-align:top;text-align:left}th{background:#e6edcf}a{color:#246346}h1,h2,h3{line-height:1.4}code{overflow-wrap:anywhere}'
 (ROOT/'reports/final-audit.html').write_text(f'<!doctype html><html lang="zh"><meta charset="UTF-8"><meta name="viewport" content="width=device-width"><title>current · Final audit</title><style>{css}</style><main><a href="/">← current</a>{body}</main></html>')
 print('Written final requirement and rubric audit.')
if __name__=='__main__':main()
