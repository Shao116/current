"""Physical descriptors, never uncalibrated probabilities. All distances are UTM metres."""
import json,math
from pathlib import Path
import numpy as np
from scipy.spatial import cKDTree
from pyproj import Transformer
from shapely.geometry import shape,Point,LineString
from shapely.strtree import STRtree
ROOT=Path(__file__).resolve().parents[1]
class Features:
 def __init__(self):
  self.project=Transformer.from_crs(4326,26917,always_xy=True)
  f=json.loads((ROOT/'public/data/lidar-trees.geojson').read_text())['features'];ll=np.array([v['geometry']['coordinates'][:2] for v in f]);self.ll=ll
  self.tree_xy=np.column_stack(self.project.transform(ll[:,0],ll[:,1]));self.heights=np.array([v['properties'].get('height',np.nan) for v in f]);self.tree=cKDTree(self.tree_xy);self.bounds=[*ll.min(axis=0),*ll.max(axis=0)]
  from shapely.ops import transform
  self.woods=[transform(self.project.transform,shape(f['geometry'])) for f in json.loads((ROOT/'public/data/woodland.geojson').read_text())['features']];self.wood_index=STRtree(self.woods)
  self.dem=None
  try:
   import rasterio
   with rasterio.open(ROOT/'private/algorithm/dem.tif') as d:
    arr=d.read(1).astype(float);arr[(arr==d.nodata)|(~np.isfinite(arr))]=np.nan
    self.dem=arr;self.affine=d.transform;self.res=abs(d.transform.a);self.dy,self.dx=np.gradient(arr,abs(d.transform.e),self.res);self.demmeta={'crs':str(d.crs),'resolutionM':[abs(d.transform.a),abs(d.transform.e)],'bounds':list(d.bounds),'shape':list(arr.shape),'source':'USGS 3DEP resampled regional grid; not full native resolution'}
  except Exception as e:self.demmeta={'status':'missing','reason':str(e)}
  self.weather={}
  for p in (ROOT/'private/algorithm').glob('weather-20*.json'):
   d=json.loads(p.read_text());self.weather[p.stem[-4:]]=d if isinstance(d,list) else [d]
 def terrain(self,x,y,direction):
  if self.dem is None:return {'available':False}
  col,row=(~self.affine) @ (x,y);r,c=int(row),int(col);a=self.dem
  if not(0<=r<a.shape[0] and 0<=c<a.shape[1]) or not np.isfinite(a[r,c]):return {'available':False}
  # DEM row increases southward; dx east gradient, north gradient = -dy.
  east,north=self.dx[r,c],-self.dy[r,c];slope=math.degrees(math.atan(math.hypot(east,north)));angles=[]
  for bearing in range(0,360,45):
   h=[]
   for distance in [100,250,500,1000,2000]:
    rr=int(r-math.cos(math.radians(bearing))*distance/abs(self.affine.e));cc=int(c+math.sin(math.radians(bearing))*distance/self.res)
    if 0<=rr<a.shape[0] and 0<=cc<a.shape[1] and np.isfinite(a[rr,cc]):h.append(math.degrees(math.atan2(a[rr,cc]-a[r,c],distance)))
   angles.append(max(h) if h else None)
  b=int((direction%360+22.5)//45)%8;window=a[max(0,r-4):r+5,max(0,c-4):c+5]
  flow=np.array([-math.sin(math.radians(direction)),-math.cos(math.radians(direction))]);rise=east*flow[0]+north*flow[1]
  return {'available':True,'elevationM':float(a[r,c]),'slopeDeg':slope,'terrainStdM':float(np.nanstd(window)),'flatnessGradient':float(math.hypot(east,north)),'horizonAnglesDeg':angles,'upwindHorizonDeg':angles[b],'opennessDeg':90-float(np.mean([v for v in angles if v is not None])),'windFacing':'windward' if rise>0.01 else 'leeward' if rise<-.01 else 'near-flat','alongWindRise':float(rise),'resolutionM':self.res}
 def at(self,lng,lat,weather,asset=None):
  x,y=self.project.transform(lng,lat);direction=float(weather.get('windDirection',0));gust=float(weather.get('gustMph',weather.get('wind',0)));v=gust*.44704
  d,j=self.tree.query([x,y]);bounds=self.bounds;inside=bool(bounds[0]<=lng<=bounds[2] and bounds[1]<=lat<=bounds[3])
  ids=self.tree.query_ball_point([x,y],100);hits=[];flow=np.array([-math.sin(math.radians(direction)),-math.cos(math.radians(direction))])
  for k in ids:
   delta=np.array([x,y])-self.tree_xy[k];dist=np.linalg.norm(delta);h=self.heights[k]
   if dist<=h and dist>0 and float(np.dot(delta/dist,flow))>=math.cos(math.radians(45)):hits.append(k)
  # 45° fall cone is a scenario geometric screen, not a fall likelihood.
  geom=Point(x,y);line_bearing=None;line_clearance=None
  if asset is not None and asset['kind'] in ['wire','secondary']:
   g=np.array(asset['geometry']);px,py=self.project.transform(g[:,0],g[:,1]);geom=LineString(zip(px,py));line_clearance=float('inf')
   for k in self.tree.query_ball_point([x,y],max(100,geom.length+100)):
    line_clearance=min(line_clearance,geom.distance(Point(*self.tree_xy[k]))-self.heights[k])
   line_bearing=math.degrees(math.atan2(px[-1]-px[0],py[-1]-py[0]))%360
  q=geom.buffer(100);wood=sum(self.woods[i].intersection(q).area for i in self.wood_index.query(q,predicate='intersects'))
  cross=v*abs(math.sin(math.radians(direction-line_bearing))) if line_bearing is not None else None
  seasonal=self.prevailing(lng,lat,weather.get('date','2024-09-27')[:7])
  return {'weather':weather,'dynamicPressurePa':.5*1.225*v*v,'airDensityAssumptionKgM3':1.225,'lineBearingDeg':line_bearing,'crosswindMps':cross,'lidar':{'sourceRegion':'Roanoke VA','withinSourceBounds':inside,'coverageComplete':False,'nearestTreeM':float(d) if inside else None,'nearestTreeHeightM':float(self.heights[j]) if inside else None,'pointsWithin100m':len(ids) if inside else None,'geometricDownwindReachCandidates':len(hits) if inside else None,'fallConeAssumptionDeg':45,'minimumLineClearanceMinusHeightM':line_clearance if line_clearance is not None and math.isfinite(line_clearance) else None,'crownDiameterM':None,'health':None},'woodlandAreaFraction100m':min(1,wood/q.area),'canopy':{'availablePolygons':95,'individualCrownData':False,'densityValue':None,'reason':'TreeCanopy field units not verified; excluded from numerical features'},'terrain':self.terrain(x,y,direction),'seasonalWind':seasonal,'stormTrack':{'available':False,'reason':'No observed local storm-track dataset supplied; wind vectors are weather context only'}}
 def prevailing(self,lng,lat,month):
  available=sorted(y for y in self.weather if y<month[:4])
  if not available:return {'available':False,'reason':'No cached preceding-year reference; same-year future weather excluded'}
  year=available[-1];reference_month=year+month[4:];datasets=self.weather[year]
  d=min(datasets,key=lambda a:(a['latitude']-lat)**2+(a['longitude']-lng)**2);h=d['hourly'];ids=[i for i,t in enumerate(h['time']) if t.startswith(reference_month)]
  v=np.array([h['wind_speed_10m'][i] or 0 for i in ids]);ang=np.radians([h['wind_direction_10m'][i] or 0 for i in ids]);xx=np.sum(v*np.sin(ang));yy=np.sum(v*np.cos(ang))
  return {'available':True,'requestedMonth':month,'referenceMonth':reference_month,'prevailingFromDeg':float(np.degrees(np.arctan2(xx,yy))%360),'directionalConcentration':float(math.hypot(xx,yy)/max(v.sum(),1e-9)),'source':'Open-Meteo preceding-year reanalysis month, speed-weighted circular mean; short reference, not measured long-term local climatology','sampleHours':len(ids)}
 def historical(self,date,lng,lat):
  datasets=self.weather.get(date[:4])
  if not datasets:return None
  d=min(datasets,key=lambda a:(a['latitude']-lat)**2+(a['longitude']-lng)**2);h=d['hourly'];ids=[i for i,t in enumerate(h['time']) if t.startswith(date)]
  if not ids:return None
  j=max(ids,key=lambda i:h['wind_gusts_10m'][i] or 0)
  return {'date':date,'gustMph':(h['wind_gusts_10m'][j] or 0)/1.609344,'windDirection':h['wind_direction_10m'][j],'windSpeedMph':(h['wind_speed_10m'][j] or 0)/1.609344,'rainMm':sum(h['rain'][i] or 0 for i in ids),'precipitationMm':sum(h['precipitation'][i] or 0 for i in ids),'snowfallCm':sum(h['snowfall'][i] or 0 for i in ids),'snowDepthM':max(h['snow_depth'][i] or 0 for i in ids),'freezingRainIndicator':any(h['weather_code'][i] in [56,57,66,67] for i in ids),'iceAccretionMm':None,'source':'Open-Meteo reanalysis daily maximum gust hour; actual incident hour unknown','gridLatitude':d['latitude'],'gridLongitude':d['longitude']}
