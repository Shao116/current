"""Presentation adapter: same workbook + CP-SAT + SimPy, explicit support contingencies.
Existing public APIs/algorithms remain unchanged. No dispatch or switching command.
"""
import math,collections
import numpy as np
from .vulnerability import PhysicsModel
from .restoration_ensemble import repair_work,dependency_groups
from .restoration import schedule

def plan(service,s,raw):
 if s['contextType']!='premise':raise ValueError('Select an anonymous customer')
 i=int(s['contextId'][2:])-1
 if not 0<=i<len(service.d['customers']):raise ValueError('Unknown customer')
 with service.lock:
  if not hasattr(service,'physics'):service.physics=PhysicsModel(service.d,service.features)
 physics=service.physics;c=service.d['customers'][i];scope=service.circuits[c['circuit']];counts=collections.Counter(n for j in scope for n in physics.by_customer[j]);selected=set(physics.by_customer[i]);first=raw.get('priority')=='critical'
 chosen=sorted(counts,key=lambda n:(int(first and n in selected),counts[n]),reverse=True)[:s['quantity']]
 cv=float(raw.get('repairCV',.5));hold=float(raw.get('hazardHoldHours',0))
 if not math.isfinite(cv) or not 0<=cv<=2 or not math.isfinite(hold) or not 0<=hold<=168:raise ValueError('Invalid repair uncertainty or safety hold')
 work=repair_work(s['asset'],s['size'],raw);release=s['accessDelay']+hold
 if not work['available']:raise ValueError('Missing task labor rate')
 groups=dependency_groups(chosen,physics.nodes,service.d['customers'],scope,set())
 tasks=[{'node':n,'hours':work['taskHours'],'release':release,'weight':counts[n]+1} for n in chosen]
 for g in groups:
  for j in g['tasks']:tasks[j]['weight']+=g['weight']
 if first:
  for t in tasks:
   if t['node'] in selected:t['weight']+=10_000_000
  # Selected-connection priority is explicit; source critical customers also remain prioritized.
  for g in groups:
   if any(j in g['customers'] for j in [list(scope).index(i)]):g['weight']+=10_000_000
 scheduled=schedule(tasks,s['crews'],time_limit=.12,customer_groups=groups);finish={chosen[e['task']]:e['end'] for e in scheduled['events']};times=[]
 for j in scope:times.append(max([finish.get(n,0) for n in physics.by_customer[j]],default=0))
 positive=[v for v in times if v>0];counter=collections.Counter(positive);restored=0;stages=[]
 for hour,count in sorted(counter.items()):
  restored+=count;stages.append({'hour':hour,'restored':restored,'remaining':len(positive)-restored})
 end=scheduled['makespan'];sigma=math.sqrt(math.log1p(cv*cv));lo=release+(end-release)*math.exp(-.5*sigma*sigma-1.2815515655446*sigma) if end else 0;hi=release+(end-release)*math.exp(-.5*sigma*sigma+1.2815515655446*sigma) if end else 0
 return {'low':lo,'high':hi,'makespan':end,'affected':len(positive),'stages':stages,'events':[{k:v for k,v in e.items() if k in ['task','crew','start','end']} for e in scheduled['events']],'actualJobs':len(chosen),'requestedJobs':s['quantity'],'rate':work['taskHours'],'workload':work,'homeHours':max([finish.get(n,0) for n in physics.by_customer[i]],default=0),'solverStatus':scheduled['solverStatus'],'cpSatObjective':scheduled['objective'],'fifoObjective':scheduled.get('fifoObjective'),'sourceCriticalPriority':True,'basis':'Explicit damage on actual shared-location support groups; workbook labor; CP-SAT or feasible fallback with SimPy replay. Common duration-factor sensitivity, not calibrated confidence coverage. No actual repair dispatch.'}
