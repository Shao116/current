"""Evidence-gated outage impact and restoration algorithms."""
