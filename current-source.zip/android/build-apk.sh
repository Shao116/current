#!/bin/sh
set -eu
cd "$(dirname "$0")"
SDK=/Users/tony/Library/Android/sdk
BT="$SDK/build-tools/35.0.0"
JDK='/Applications/Android Studio.app/Contents/jbr/Contents/Home'
mkdir -p build/classes app/src/main/assets
# Package only the new public presentation, anonymized replay, map engine and style.
python3 - <<'PY'
from pathlib import Path
import shutil
root=Path('..');dest=Path('app/src/main/assets')
for directory in ['mobile','workspace','vendor']:
 shutil.copytree(root/'public'/directory,dest/directory,dirs_exist_ok=True)
(dest/'data').mkdir(exist_ok=True)
shutil.copy2(root/'public/data/map-natural.json',dest/'data/map-natural.json')
shutil.copy2(root/'public/favicon.svg',dest/'favicon.svg')
PY
"$BT/aapt2" compile --dir res -o build/resources.zip
"$BT/aapt2" link -o build/base.apk -I "$SDK/platforms/android-35/android.jar" --manifest AndroidManifest.xml -A app/src/main/assets build/resources.zip
"$JDK/bin/javac" -source 8 -target 8 -classpath "$SDK/platforms/android-35/android.jar" -d build/classes app/src/main/java/com/current/storm/*.java
find build/classes -name '*.class' > build/classes-list.txt
"$BT/d8" --lib "$SDK/platforms/android-35/android.jar" --min-api 26 --output build @build/classes-list.txt
cp build/base.apk build/unsigned.apk
(cd build && zip -q unsigned.apk classes.dex)
"$BT/zipalign" -f 4 build/unsigned.apk build/aligned.apk
if [ ! -f build/current-test.keystore ];then
 "$JDK/bin/keytool" -genkeypair -keystore build/current-test.keystore -storepass android -keypass android -alias current -keyalg RSA -keysize 2048 -validity 3650 -dname 'CN=current presentation, O=HackOHIO' >/dev/null 2>&1
fi
"$BT/apksigner" sign --ks build/current-test.keystore --ks-pass pass:android --out ../deliverables/current-android.apk build/aligned.apk
"$BT/apksigner" verify --verbose ../deliverables/current-android.apk
