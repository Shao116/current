"""Anonymized offline replay; reuse existing physics and exact source paths."""
from pathlib import Path
import json,sys,math
from pyproj import Transformer
from numpy.polynomial.hermite import hermgauss
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from algorithms.service import get_service
from algorithms.vulnerability import PhysicsModel,REFERENCE
from algorithms.restoration_ensemble import repair_work
ROOT=Path(__file__).resolve().parents[1];s=get_service();p=PhysicsModel(s.d,s.features);ids=p.ids;index={n:i for i,n in enumerate(ids)};inv=Transformer.from_crs(26917,4326,always_xy=True)
supports=[]
for n,c in zip(ids,p.context(ids)):
 g=c['group'];a=s.d['assets'][g['asset']];x,y=a['xy'];lng,lat=inv.transform(round(x/100)*100,round(y/100)*100)
 supports.append([g['poleClass'],g['phase'],g['bearings'],g['heightM'],[[float(h),float(delta[0]),float(delta[1]),float(d)] for h,delta,d in c['pairs']],round(lng,5),round(lat,5),len(g['customers'])])
customers=[];circuits={}
for i,c in enumerate(s.d['customers']):
 lng,lat=inv.transform(*c['xy']);ci=c['circuit'];customers.append([round(lng,5),round(lat,5),ci,[index[n] for n in p.by_customer[i]],bool(c['path'])]);circuits[ci]=circuits.get(ci,0)+1
z,w=hermgauss(32)
data={'version':'2.1-offline-reference','event':json.loads((ROOT/'public/data/demo-events.json').read_text())[0],'reference':REFERENCE,'supports':supports,'customers':customers,'circuits':circuits,'quadrature':{'z':(z*math.sqrt(2)).tolist(),'w':(w/math.sqrt(math.pi)).tolist()},'repairHours':{k:repair_work(k)['taskHours'] for k in ['pole','wire','transformer','fuse','switch']},'basis':'Present-day organizer Roanoke GIS under uniform 2012 weather replay. Transferred fragility, not calibrated AEP probabilities. Offline restoration: explicit-damage feasible list schedule. Full service: CP-SAT/SimPy.','counts':{'customers':len(customers),'supports':len(supports),'covered':sum(bool(c[3]) for c in customers)}}
(ROOT/'public/workspace/replay.json').write_text(json.dumps(data,separators=(',',':'),allow_nan=False));old=json.loads((ROOT/'private/data.json').read_text());(ROOT/'public/workspace/lines.json').write_text(json.dumps(old['lines'],separators=(',',':')))
from algorithms.risk_surface import surface
from engine import normalize
raw={'date':'2012-06-29','wind':81,'windDirection':297,'rainMm':.6,'predictionMode':'weather'}
(ROOT/'public/workspace/surface.json').write_text(json.dumps(surface(s,normalize(raw),raw),separators=(',',':')))
print(data['counts'],'bytes',(ROOT/'public/workspace/replay.json').stat().st_size,flush=True)

# Keep the bundled exact-dependency display reproducible after every rebuild.
import runpy
runpy.run_path(str(ROOT/'algorithms/export_mobile_paths.py'))
