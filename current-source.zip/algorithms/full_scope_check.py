import sys,json,time,gzip
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from engine import evaluate
from algorithms.service import get_service
R=Path(__file__).resolve().parents[1];d=json.loads((R/'private/data.json').read_text());d['premiseIndex']={p['id']:p for p in d['premises']};d['circuitIndex']={p['id']:p for p in d['circuits']};svc=get_service();n=next(n for n,v in svc.d['nodes'].items() if v['asset'] is not None and svc.d['assets'][v['asset']]['kind']=='transformer');t=time.perf_counter();r=evaluate({'scope':'all','asset':'transformer','failedNodes':[n],'quantity':1,'upstream':0},d);elapsed=time.perf_counter()-t
assert len(r['impact']['perCustomer'])==117642
assert len(r['ert']['perCustomer'])==117642
ref=len(svc.d['nodes'][n]['customers'])/117642*100
assert abs(ref-r['impact']['expectedAffectedPercentage'])<1e-12
with gzip.open(R/'private/algorithm/all-customers-example.json.gz','wt') as f:json.dump(r,f,allow_nan=False)
summary={'scenario':'One explicitly assumed real transformer failure, full supplied extract','customers':len(r['impact']['perCustomer']),'ertCustomerRows':len(r['ert']['perCustomer']),'runtimeSeconds':elapsed,'conditionalImpactPct':r['impact']['expectedAffectedPercentage'],'referencePct':ref,'unconditionalProbability':None,'unknownTopologyCustomers':47,'status':'PASS','output':'private/algorithm/all-customers-example.json.gz'}
(R/'reports/full-scope-check.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
