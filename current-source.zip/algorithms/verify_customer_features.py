"""Live HTTP evidence for customer risk, supplied dependencies and alert previews."""
from pathlib import Path
import json,urllib.request,time
ROOT=Path(__file__).resolve().parents[1];BASE='http://127.0.0.1:8765'
def post(s):
 req=urllib.request.Request(BASE+'/api/evaluate',data=json.dumps({'scenario':s}).encode(),headers={'Content-Type':'application/json'});t=time.perf_counter()
 with urllib.request.urlopen(req,timeout=60) as r:d=json.load(r)
 return d,(time.perf_counter()-t)*1000
if __name__=='__main__':
 out=[]
 for id in ['P-094125','P-000001','P-020015']:
  s={'contextType':'premise','contextId':id,'predictionMode':'weather','date':'2012-06-29','wind':81,'windDirection':280,'crews':3}
  d,ms=post(s)
  with urllib.request.urlopen(BASE+'/api/customer-supply?id='+id) as r:path=json.load(r)
  c=d['customerRisk'];original=next(p for p in d['impact']['perCustomer'] if p['id']==id);prob=original.get('scenarioOutageProbability');assert c['scenarioOutagePercentage']==(None if prob is None else prob*100)
  assert path['steps'][-1]['id']==id;assert [p['id'] for p in path['steps'][:-1]]==list(reversed([p['id'] for p in d['location']['path']]))
  row={'customer':id,'homeScenarioPercentage':c['scenarioOutagePercentage'],'circuitExpectedAffectedPercentage':d['impact']['expectedAffectedPercentage'],'available':c['available'],'totalUpstreamDevices':path['totalDevices'],'mappedDevices':path['mappedDevices'],'missingLocations':path['missingDeviceLocations'],'displayEdges':sum(f['geometry']['type']=='LineString' for f in path['geojson']['features']),'seconds':ms/1000,'calibratedOutageProbability':c['calibratedOutageProbability']};out.append(row);print(row,flush=True)
 assert out[0]['available'];assert out[0]['homeScenarioPercentage']!=out[0]['circuitExpectedAffectedPercentage'];assert not out[2]['available']
 for stage in ['pre','outage','update','restored']:
  d,ms=post({'contextType':'premise','contextId':'P-094125','predictionMode':'weather','wind':81,'windDirection':280,'stage':stage,'optIn':True});assert d['alerts']['eligible'];assert d['alerts']['subscribed'];assert d['alerts']['escalation'];assert d['alerts']['timing'];assert d['message']==d['messages'][stage];out.append({'stage':stage,'message':d['message'],'alert':d['alerts'],'delivery':'Preview only; no real SMS/email'})
 (ROOT/'reports/final/customer-live-tests.json').write_text(json.dumps(out,indent=2));print('Live customer-specific percentages, topology order and four-stage preview policies verified.')
