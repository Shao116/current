"""Frozen v2 baseline, only used for measured regression comparison."""
