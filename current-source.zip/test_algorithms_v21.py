"""Regression/invariant tests. No synthetic fixture score is real accuracy."""
import unittest,math,json
import numpy as np
from scipy.special import expit
from test_algorithms_v2 import D
from engine import evaluate
from algorithms.service import get_service
from algorithms.impact import scenario_impact
from algorithms.vulnerability import pole_probability,tree_probability
from algorithms.restoration import schedule,feasible_backup
from algorithms.restoration_ensemble import repair_work
class V21Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.service=get_service();cls.r=evaluate({'predictionMode':'weather','contextType':'circuit','contextId':'C-001','wind':55,'windDirection':225},D)
 def run_weather(self,**kw):return evaluate({'predictionMode':'weather','contextType':'circuit','contextId':'C-001','wind':55,'windDirection':225,**kw},D)
 def test_published_coefficient_and_unit_reference(self):
  expected=(expit(-11.383+(.0645+.0650)*40)-expit(-11.383))/(1-expit(-11.383));self.assertAlmostEqual(float(pole_probability(40,'4','1',1)),expected);self.assertEqual(float(pole_probability(0)),0)
 def test_tree_positive_capacity_truncation(self):
  self.assertEqual(float(tree_probability(20,0)),0);self.assertGreater(float(tree_probability(20,40)),float(tree_probability(20,20)))
 def test_shared_identifier_support_mapping(self):
  svc=self.service;self.assertGreater(len(svc.physics.nodes),25000)
  for g in svc.physics.nodes.values():
   a=svc.d['assets'][g['asset']];self.assertLessEqual(g['maxOffsetM'],10)
   union=np.unique(np.concatenate([svc.d['nodes'][n]['customers'] for n in g['linkedNodes']]))
   np.testing.assert_array_equal(union,g['customers'])
   for n in g['linkedNodes']:
    b=svc.d['assets'][svc.d['nodes'][n]['asset']];self.assertEqual(a['attributes']['location_n'],b['attributes']['location_n'])
 def test_weather_now_works_and_is_monotone(self):
  a=self.run_weather(wind=20);b=self.run_weather(wind=95);self.assertGreater(b['impact']['expectedAffectedPercentage'],a['impact']['expectedAffectedPercentage']);self.assertGreater(a['impact']['expectedAffectedPercentage'],0);self.assertIsNone(b['impact']['outageProbability']);self.assertIsNone(b['risk']['score'])
 def test_zero_wind_no_fabricated_background_damage(self):
  r=self.run_weather(wind=0);self.assertAlmostEqual(r['impact']['expectedAffectedPercentage'],0);self.assertEqual(r['ert']['high'],0)
 def test_direction_changes_exposure(self):
  a=self.run_weather(windDirection=45);b=self.run_weather(windDirection=135);self.assertNotEqual(a['impact']['expectedAffectedPercentage'],b['impact']['expectedAffectedPercentage'])
  terrain=a['equipmentPredictions'][0]['terrain']
  if terrain['available']:self.assertEqual(terrain['upwindHorizonDeg'],terrain['horizonAnglesDeg'][1])
 def test_sparse_gaussian_integration_reference(self):
  ns={'a':{'customers':np.array([0,1])},'b':{'customers':np.array([1,2])}};cs=[{'id':str(i),'path':['x']} for i in range(3)];r=scenario_impact(ns,cs,[0,1,2],['a','b'],[.2,.3],trials=1000,correlation=0)
  np.testing.assert_allclose([v['scenarioOutageProbability'] for v in r['perCustomer']],[.2,.44,.3],atol=1e-12)
 def test_rare_event_mean_not_rounded_to_zero(self):
  ns={'a':{'customers':np.array([0])}};cs=[{'id':'1','path':['x']}];r=scenario_impact(ns,cs,[0],['a'],[1e-7],trials=16);self.assertGreater(r['expectedAffectedPercentage'],0);self.assertGreater(r['monteCarloMeanCI95Percentage'][1],0);self.assertAlmostEqual(r['expectedAffectedPercentage'],1e-5,delta=1e-7)
 def test_correlated_quadrature_mc_agree(self):
  ns={'a':{'customers':np.array([0])},'b':{'customers':np.array([0])}};cs=[{'id':'1','path':['x']}];r=scenario_impact(ns,cs,[0],['a','b'],[.2,.3],trials=20000,correlation=.7);self.assertAlmostEqual(r['expectedAffectedPercentage'],r['monteCarloMeanAffectedPercentage'],delta=1.5)
 def test_sensitivity_brackets_reference_mean(self):
  i=self.r['impact'];self.assertLessEqual(i['modelSensitivityRangePercentage'][0],i['expectedAffectedPercentage']);self.assertGreaterEqual(i['modelSensitivityRangePercentage'][1],i['expectedAffectedPercentage'])
 def test_winter_hazard_is_partial_not_low_risk(self):
  r=self.run_weather(wind=10,freezingRain=True,snowfallCm=20);self.assertEqual(r['riskAssessment']['status'],'partial_winter_hazard');self.assertEqual(r['impact']['totalHazardBoundPercentage'][1],100);self.assertIn('partial',r['risk']['band'])
 def test_no_future_damage_or_seasonal_leakage(self):
  r=self.run_weather(date='2024-01-01');self.assertFalse(r['physicsFeatures']['seasonalWind']['available']);self.assertEqual(r['riskAssessment']['historicalDamage']['dateFilter'],'Strictly before scenario date; no future damage leakage')
 def test_published_conductor_reference_separate_from_workbook(self):
  w=repair_work('wire');self.assertEqual(w['taskHours'],4);self.assertIsNone(w['indirectMultiplier']);self.assertIn('published',w['basis'])
 def test_zero_variance_and_staged_known_dependencies(self):
  svc=self.service;cs=next(p for p in svc.d['customers'] if len(p['path'])>=3 and all(svc.d['nodes'][n]['asset'] is not None for n in p['path'][:2]));nodes=cs['path'][:2]
  r=evaluate({'contextType':'premise','contextId':cs['id'],'failedNodes':nodes,'asset':'transformer','crews':1,'repairCV':0},D);self.assertGreater(len(r['ert']['stages']),0);self.assertLessEqual(r['ert']['low'],r['ert']['high']);self.assertEqual(r['ert']['uncertainty']['coefficientOfVariation'],0)
 def test_customer_objective_not_double_counting_tasks(self):
  tasks=[{'hours':1,'weight':1},{'hours':5,'weight':1},{'hours':2,'weight':1}];groups=[{'tasks':[0,1],'weight':100},{'tasks':[2],'weight':1}];s=schedule(tasks,1,customer_groups=groups);finish={e['task']:e['end'] for e in s['events']};self.assertAlmostEqual(s['objective'],max(finish[0],finish[1])*100+finish[2]);self.assertLessEqual(s['objective'],s['fifoObjective'])
 def test_backup_invalid_capacity_rejected(self):
  a=dict.fromkeys(['verifiedTopology','voltageCompatible','protectionApproved','isolationVerified','radialityVerified'],True);a.update(spareCapacityKW=float('nan'),loadKW=2);self.assertFalse(feasible_backup(a)['feasible'])
 def test_reproducible_cached_result_and_privacy(self):
  a=self.run_weather(seed=991);b=self.run_weather(seed=991);self.assertEqual(a['impact'],b['impact']);self.assertEqual(a['ert'],b['ert']);self.assertTrue(b['performance']['cacheHit']);s=json.dumps(a,allow_nan=False);self.assertNotIn('premise_nu',s)
  def check_keys(v):
   if isinstance(v,dict):
    self.assertTrue(not {'location_n','address','premise_nu'}.intersection(v))
    for value in v.values():check_keys(value)
   elif isinstance(v,list):
    for value in v:check_keys(value)
  check_keys(a)
 def test_missing_assembly_coverage_not_zero_risk(self):
  from unittest.mock import patch
  with patch.object(self.service.physics,'by_customer',[[] for _ in self.service.d['customers']]):
   r=self.run_weather(seed=701701)
  self.assertIsNone(r['impact']['expectedAffectedPercentage']);self.assertIsNone(r['ert']['high']);self.assertEqual(r['riskAssessment']['status'],'no_model_coverage')
 def test_invalid_new_inputs(self):
  for kw in [{'repairCV':-1},{'hazardHoldHours':-1},{'predictionMode':'bad'},{'fallCorridorM':-1},{'facilityLinks':[{'verified':False}]},{'trials':16.2}]:
   with self.subTest(kw=kw),self.assertRaises((ValueError,TypeError)):self.run_weather(**kw)
if __name__=='__main__':unittest.main(verbosity=2)
